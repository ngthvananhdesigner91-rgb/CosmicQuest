/* ===== 5. Màn hình chấm bài (cốt lõi) ===== */
let G = null, gradeEl = null, rTab = 'score', bTab = 'list', listAll = false, dirty = false, claudeCtl = null, pendingUploads = [];
const V = { pages: [], cur: 0, zoom: 1, tx: 0, ty: 0, tool: 'pan', color: '#E0352B', width: 4, grid: 0, cmp: null, cmpPos: 50, pick: [], drawing: null };
const GRIDS = ['Tắt lưới', 'Quy tắc 1/3', 'Lưới 12 cột', 'Lưới vuông', 'Đường chéo'];
const PEN_COLORS = ['#E0352B', '#1F6FEB', '#F2B705', '#12A150', '#111111', '#FFFFFF'];
window.G = null;

function lessonSetup(classId, courseId, lessonId) {
  const a = findAssignment(classId, lessonId), l = lesson(courseId, lessonId);
  return { objective: a?.objective || l.objective, criteria: (a?.criteria || l.criteria).map(k => ({ name: k.name, max: k.max, levels: k.levels || '', claude: null, reason: '', score: null, edited: false })), policy: a?.aiLevel || 2 };
}
function blankG(keep) {
  const classId = keep?.classId || '524TKD', courseId = keep?.courseId || 'ps', lessonId = keep?.lessonId || course(courseId).lessons[1].id;
  const ls = lessonSetup(classId, courseId, lessonId);
  const g = { id: null, classId, className: klass(classId)?.name || classId, courseId, lessonId, mssv: '', name: '', title: '',
    objective: keep?.objective ?? ls.objective, criteria: keep?.criteria ? keep.criteria.map(k => ({ name: k.name, max: k.max, levels: k.levels || '', claude: null, reason: '', score: null, edited: false })) : ls.criteria,
    good: [], fix: [], flags: [], flagNotes: [], comment: '', ultimatum: '', ultEdited: false, note: '',
    ai: { policy: ls.policy, declaration: '', reflection: '', level: '', percent: null, reason: '', observations: [], assessment: '', manual: {} }, viva: { items: [], outcome: '', note: '', date: '' },
    files: [], ann: {}, status: 'cho', claudeTotal: null };
  const st = nextStudent(g); if (st) { g.mssv = st.mssv; g.name = st.name; }
  return g;
}
function nextStudent(g) {
  const k = klass(g.classId); if (!k?.students?.length) return null;
  const done = new Set(subsArr().filter(s => s.classId === g.classId && s.lessonId === g.lessonId).map(s => s.mssv));
  return k.students.find(s => !done.has(s.mssv)) || null;
}
const gTotal = () => round2(sum(G.criteria.map(k => k.score ?? 0)));
const gHasScores = () => G.criteria.some(k => k.score != null);
const gMax = () => round2(sum(G.criteria.map(k => k.max || 0)));

ROUTES.grade = (v) => {
  if (!gradeEl) buildGrade();
  if (v.firstChild !== gradeEl) v.replaceChildren(gradeEl);
  if (!G) { G = blankG(); window.G = G; renderAll(); }
  requestAnimationFrame(() => { if (V.pages.length && !V.fitted) fit(); });
};

function buildGrade() {
  gradeEl = document.createElement('div'); gradeEl.className = 'gw';
  gradeEl.innerHTML = `<div class="gl">
    <div class="vt" id="vt" role="toolbar" aria-label="Công cụ xem và chú thích">
      <button class="tb" data-tool="pan" title="Di chuyển (V)">${icon('hand')}</button>
      <button class="tb" data-tool="pen" title="Bút vẽ tự do (B)">${icon('brush')}</button>
      <button class="tb" data-tool="arrow" title="Mũi tên (A)">${icon('arrow')}</button>
      <button class="tb" data-tool="rect" title="Khung chữ nhật (R)">${icon('rect')}</button>
      <button class="tb" data-tool="ellipse" title="Khoanh elip (E)">${icon('ellipse')}</button>
      <button class="tb" data-tool="text" title="Ghi chú chữ (T)">${icon('text')}</button>
      <button class="tb" data-tool="pick" title="Đo tương phản WCAG (C) — bấm 2 điểm màu">${icon('drop')}</button>
      <span class="gap"></span>
      ${PEN_COLORS.map(c => `<button class="sw-c" data-color="${c}" style="background:${c}" aria-label="Màu ${c}"></button>`).join('')}
      <select class="inp" id="penW" style="width:64px;height:30px;font-size:.76rem" aria-label="Độ dày nét">${[2, 4, 7, 12].map(w => `<option value="${w}" ${w === 4 ? 'selected' : ''}>${w}px</option>`).join('')}</select>
      <button class="tb" id="undo" title="Hoàn tác (Ctrl+Z)">${icon('undo')}</button>
      <button class="tb" id="redo" title="Làm lại">${icon('redo')}</button>
      <button class="tb" id="clearAnn" title="Xoá chú thích trang này">${icon('trash')}</button>
      <span class="gap"></span>
      <button class="tb" id="zOut" title="Thu nhỏ (−)">${icon('minus')}</button><span class="zoomv" id="zoomv">100%</span><button class="tb" id="zIn" title="Phóng to (+)">${icon('plus')}</button>
      <button class="tb" id="zFit" title="Vừa khung (0)">${icon('fit')}</button>
      <select class="inp" id="zPreset" style="width:74px;height:30px;font-size:.76rem" aria-label="Mức phóng"><option value="">Soi…</option><option value="1">100%</option><option value="2">200%</option><option value="3">300%</option></select>
      <span class="gap"></span>
      <button class="tb" id="gridBtn" title="Lưới phủ (G)">${icon('grid')}</button>
      <button class="tb" id="cmpBtn" title="So sánh 2 phiên bản">${icon('compare')}</button>
      <span id="cmpCtl" hidden style="display:inline-flex;gap:6px;align-items:center"><select class="inp" id="cmpSel" style="width:150px;height:30px;font-size:.74rem" aria-label="Bản so sánh"></select><input type="range" id="cmpRange" min="0" max="100" value="50" style="width:90px" aria-label="Thanh kéo so sánh"></span>
      <span style="flex:1"></span>
      <button class="btn sm" id="addFile">${icon('upload')}Tải bài lên</button>
    </div>
    <div class="viewer pan" id="vw">
      <div class="stage" id="stage" hidden><canvas class="base" id="cvBase"></canvas><canvas id="cvCmp"></canvas><canvas id="cvAnn"></canvas><canvas id="cvOvl" style="pointer-events:none"></canvas><div class="cmp-line" id="cmpLine" hidden></div></div>
      <div class="drop" id="drop"><svg class="ico" style="width:40px;height:40px;stroke:#fff"><use href="#i-upload"/></svg><b>Thả bài làm của sinh viên vào đây</b><p>Ảnh JPG/PNG/WebP, PDF nhiều trang, PSD (đọc cấu trúc layer) hoặc AI (đếm điểm neo) — tối đa 20 MB mỗi file. Có thể thả nhiều file: bản cuối, file gốc, bản trung gian, phác thảo.</p><button class="btn pri" id="dropPick">${icon('upload')}Chọn file</button></div>
      <div class="viewer-badges" id="vBadges"></div>
      <div class="contrast-pop" id="cPop" hidden></div>
    </div>
    <div class="gb"><div class="tabs" id="bTabs"></div><div class="gb-body" id="gbBody"></div></div>
  </div>
  <div class="gr">
    <div class="tabs" id="rTabs" role="tablist"></div>
    <div class="gr-body" id="grBody"></div>
    <div class="scorebar" id="scorebar"></div>
  </div>`;
  bindViewer();
}
function renderAll() { renderRTabs(); renderRight(); renderBottom(); renderScorebar(); paintTools(); showPage(Math.min(V.cur, Math.max(0, V.pages.length - 1))); paintHdr(); }
function setDirty() { dirty = true; }

/* ---------- panel phải ---------- */
function renderRTabs() {
  const nq = (G.viva.items || []).length;
  $('#rTabs').innerHTML = [['score', 'Chấm điểm'], ['ai', 'Minh bạch AI' + (G.ai.percent != null ? ' · ' + G.ai.percent + '%' : '')]].map(([k, t]) => `<button role="tab" aria-selected="${rTab === k}" data-t="${k}">${t}</button>`).join('');
  $$('#rTabs button').forEach(b => b.onclick = () => { rTab = b.dataset.t; renderRTabs(); renderRight(); });
}
function renderRight() { const b = $('#grBody'); if (rTab === 'viva') rTab = 'score'; if (rTab === 'score') renderScoreTab(b); else renderAiTab(b); }

function pctClass(p) { return p == null ? '' : p >= 65 ? 'bad' : p >= 30 ? 'warn' : 'ok'; }
function bullets(key, cls) {
  const arr = G[key];
  return `<ul class="bl ${cls}" data-bl="${key}">${arr.map((t, i) => `<li><span>–</span><textarea rows="1" data-i="${i}" aria-label="Ý ${i + 1}" placeholder="Nhập một ý…">${esc(t)}</textarea><button class="btn ghost sm" data-rm="${i}" aria-label="Xoá ý" style="padding:0 4px;height:26px">${icon('x')}</button></li>`).join('')}</ul>
  <button class="btn ghost sm" data-addb="${key}" style="align-self:flex-start">${icon('plus')}Thêm ý</button>`;
}
function allNotes() {
  const out = [], seen = new Set(); let n = 0;
  const push = (key, page, label) => { (G.ann[key] || []).forEach((s, idx) => { if (s.t === 'text') return; out.push({ n: ++n, s, key, idx, page, label }); }); seen.add(key); };
  V.pages.forEach((p, i) => push(annKey(p), i, p.label));
  Object.keys(G.ann || {}).forEach(k => { if (!seen.has(k)) push(k, -1, 'Trang chưa mở'); });
  return out;
}
function renderScoreTab(b) {
  const c = course(G.courseId), k = klass(G.classId);
  const flags = flagsFor(G.courseId), notes = allNotes(), pct = G.ai.percent;
  b.innerHTML = `
  <section class="sec"><div class="sec-h"><h3><span class="k">01</span>Thông tin bài nộp</h3>${G.id ? `<span class="chip ${STATUS[G.status]?.[1] || ''}">${STATUS[G.status]?.[0] || ''}</span>` : '<span class="chip">Bài mới</span>'}</div>
    <div class="grid2">
      <label class="field"><span>Lớp</span><select class="inp" id="gCls">${classes().map(x => `<option value="${esc(x.id)}" ${x.id === G.classId ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}<option value="__new">＋ Lớp mới…</option></select></label>
      <label class="field"><span>Môn học</span><select class="inp" id="gCourse">${courses().map(x => `<option value="${x.id}" ${x.id === G.courseId ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>
      <label class="field" style="grid-column:1/-1"><span>Bài học</span><select class="inp" id="gLesson">${c.lessons.map(x => `<option value="${x.id}" ${x.id === G.lessonId ? 'selected' : ''}>Bài ${x.no}: ${esc(x.name)}</option>`).join('')}</select></label>
      <label class="field"><span>Mã sinh viên</span><input class="inp num" id="gMssv" list="dlStu" value="${esc(G.mssv)}" placeholder="VD: 2251010001" autocomplete="off"></label>
      <label class="field"><span>Họ tên sinh viên</span><input class="inp" id="gName" value="${esc(G.name)}" placeholder="Họ và tên"></label>
      <label class="field" style="grid-column:1/-1"><span>Tên bài nộp</span><input class="inp" id="gTitle" value="${esc(G.title)}" placeholder="VD: Poster “Mùa thu Hà Nội”"></label>
    </div><datalist id="dlStu">${(k?.students || []).map(s => `<option value="${esc(s.mssv)}">${esc(s.name)}</option>`).join('')}</datalist>
  </section>
  <section class="sec"><div class="sec-h"><h3><span class="k">02</span>Mục tiêu</h3></div>
    <textarea class="inp" id="gObj" rows="2">${esc(G.objective)}</textarea></section>
  <section class="sec"><div class="sec-h"><h3><span class="k">03</span>Tiêu chí đánh giá</h3><span id="gradeHint" class="muted" style="font-size:.74rem"></span></div>
    <div class="crit hd"><span>Tiêu chí</span><span style="text-align:center">Tối đa</span><span style="text-align:center">Điểm</span></div>
    <div id="critRows">${G.criteria.map((x, i) => `<div class="crit" data-i="${i}">
      <span class="nm-t">${esc(x.name)}</span><span class="mx-t num">${fmt(x.max)}</span>
      <input class="inp sc" data-f="score" inputmode="decimal" value="${x.score == null ? '' : fmt(x.score)}" placeholder="–" aria-label="Điểm: ${esc(x.name)}">
      ${x.reason ? `<div class="why">${esc(x.reason)}</div>` : ''}</div>`).join('')}</div>
    <div class="crit-sum" id="critSum"></div>
  </section>
  <section class="sec"><div class="sec-h"><h3><span class="k">04</span>Nhận xét chung</h3></div>
    <div class="eyebrow" style="color:var(--ok)">Tốt</div>${bullets('good', 'g')}
    <div class="eyebrow" style="color:var(--bad);margin-top:6px">Khắc phục</div>${bullets('fix', 'f')}
  </section>
  <section class="sec"><div class="sec-h"><h3><span class="k">05</span>Ghi chú lỗi trên bài</h3><span class="chip">${notes.length}</span></div>
    ${notes.length ? `<div class="notes">${notes.map(o => `<div class="it" data-key="${esc(o.key)}" data-idx="${o.idx}" data-page="${o.page}"><span class="no" style="background:${o.s.c === '#FFFFFF' || o.s.c === '#F2B705' ? '#9A6A00' : o.s.c}">${o.n}</span><div style="flex:1;min-width:0"><div>${o.s.note ? esc(o.s.note) : '<span class="faint">Chưa có ghi chú — bấm để thêm</span>'}</div><div class="faint" style="font-size:.72rem">${esc(o.label)}</div></div><button class="btn ghost sm" data-del="1" aria-label="Xoá nét và ghi chú" style="padding:0 4px;height:24px">${icon('x')}</button></div>`).join('')}</div>`
      : `<p class="muted" style="margin:0;font-size:.84rem">Chọn bút, mũi tên, khung hoặc elip rồi vẽ lên bài. Sau mỗi nét vẽ, ô ghi chú lỗi tự hiện ra; sinh viên di chuột vào vùng vẽ sẽ thấy ghi chú.</p>`}
  </section>
  <section class="sec aiflag"><div class="sec-h"><h3><span class="k">06</span>Nghi vấn lạm dụng AI</h3><span id="aiBusy" class="auto" ${aiTimer || aiCtl ? '' : 'hidden'}><i></i>Claude đang tính…</span></div>
    <div class="row" style="align-items:flex-end;gap:14px;flex-wrap:nowrap"><div class="pct ${pctClass(pct)}" id="aiPct">${pct == null ? '–' : pct + '%'}</div>
      <div style="flex:1;min-width:0"><div class="eyebrow">Chỉ số nghi vấn do Claude tính</div><div class="meter"><i id="aiNeedle" style="left:${pct ?? 0}%;${pct == null ? 'display:none' : ''}"></i></div>
      <div class="row" style="justify-content:space-between;font-size:.68rem;color:var(--faint)"><span>Thấp</span><span>Cần xem xét</span><span>Cao</span></div></div></div>
    <p class="muted" id="aiReason" style="margin:0;font-size:.8rem">${esc(G.ai.reason || G.ai.assessment || 'Claude tính chỉ số khi chấm bài và tính lại mỗi khi bạn tick dấu hiệu bên dưới.')}</p>
    <div>${flags.map((f, i) => `<label class="chk"><input type="checkbox" data-flag="${f.id}" ${G.flags.includes(f.id) ? 'checked' : ''}>${esc(f.label)}</label>${i === 2 && flags.length > 3 ? `<div class="eyebrow" style="margin:8px 0 2px">Dấu hiệu riêng của ${esc(c.soft)}</div>` : ''}`).join('')}</div>
    ${G.flagNotes?.length ? `<div style="font-size:.78rem;color:var(--bad)"><b>Tín hiệu đọc từ file:</b> ${esc(G.flagNotes.join(' · '))}</div>` : ''}
  </section>
  <section class="sec"><div class="sec-h"><h3><span class="k">07</span>Nhận xét gửi sinh viên</h3></div>
    <textarea class="inp" id="gComment" rows="5" placeholder="Nhận xét chung (Claude soạn sẵn sau khi chấm, bạn có thể sửa)">${esc(G.comment)}</textarea>
    <div id="ultBox" ${G.flags.length || G.ultimatum ? '' : 'hidden'}><div class="eyebrow" style="color:var(--bad);margin-bottom:4px">Tối hậu thư (chèn cuối nhận xét)</div><textarea class="inp" id="gUlt" rows="5" style="border-color:color-mix(in srgb,var(--bad) 45%,var(--line))">${esc(G.ultimatum)}</textarea></div>
    <label class="field"><span>Ghi chú riêng của giảng viên (không gửi sinh viên, Claude đọc khi chấm)</span><input class="inp" id="gNote" value="${esc(G.note)}" placeholder="VD: chú ý vùng nền bên trái, bóng đổ chân nhân vật"></label>
  </section>`;
  $('#gCls').onchange = e => { if (e.target.value === '__new') { editClass(null); e.target.value = G.classId; return; } G.classId = e.target.value; G.className = klass(G.classId)?.name || G.classId; reloadLesson(false); };
  $('#gCourse').onchange = e => { G.courseId = e.target.value; if (!(klass(G.classId)?.courseIds || []).includes(G.courseId)) { const k2 = classes().find(k => (k.courseIds || []).includes(G.courseId)); if (k2) { G.classId = k2.id; G.className = k2.name; G.mssv = ''; G.name = ''; } } G.lessonId = course(G.courseId).lessons[0].id; G.flags = G.flags.filter(id => flagsFor(G.courseId).some(f => f.id === id)); reloadLesson(true); };
  $('#gLesson').onchange = e => { G.lessonId = e.target.value; reloadLesson(true); };
  $('#gMssv').oninput = e => { G.mssv = e.target.value.trim(); const st = klass(G.classId)?.students?.find(s => s.mssv === G.mssv); if (st) { G.name = st.name; $('#gName').value = st.name; } setDirty(); renderBottom(); };
  $('#gName').oninput = e => { G.name = e.target.value; setDirty(); };
  $('#gTitle').oninput = e => { G.title = e.target.value; setDirty(); };
  $('#gObj').oninput = e => { G.objective = e.target.value; setDirty(); };
  $$('#critRows .crit').forEach(row => {
    const i = +row.dataset.i, x = G.criteria[i], sc = $('[data-f=score]', row);
    sc.oninput = () => { x.score = parseNum(sc.value); x.edited = true; updateTotals(); setDirty(); };
    sc.onblur = () => { if (x.score != null) sc.value = fmt(x.score); };
    sc.onkeydown = e => { if (e.key === 'Enter' || e.key === 'ArrowDown') { e.preventDefault(); $(`#critRows .crit[data-i="${i + 1}"] [data-f=score]`)?.focus(); } if (e.key === 'ArrowUp') { e.preventDefault(); $(`#critRows .crit[data-i="${i - 1}"] [data-f=score]`)?.focus(); } };
  });
  $$('[data-bl]', b).forEach(ul => {
    const key = ul.dataset.bl;
    $$('textarea', ul).forEach(t => { const grow = () => { t.style.height = 'auto'; t.style.height = t.scrollHeight + 'px'; }; grow(); t.oninput = () => { G[key][+t.dataset.i] = t.value; G[key + 'Edited'] = true; grow(); setDirty(); }; t.onkeydown = e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); G[key].splice(+t.dataset.i + 1, 0, ''); G[key + 'Edited'] = true; rerenderKeep(); setTimeout(() => $$(`[data-bl="${key}"] textarea`)[+t.dataset.i + 1]?.focus(), 0); } }; });
    $$('[data-rm]', ul).forEach(x => x.onclick = () => { G[key].splice(+x.dataset.rm, 1); G[key + 'Edited'] = true; setDirty(); rerenderKeep(); });
  });
  $$('[data-addb]', b).forEach(x => x.onclick = () => { const key = x.dataset.addb; G[key].push(''); G[key + 'Edited'] = true; setDirty(); rerenderKeep(); setTimeout(() => { const ts = $$(`[data-bl="${key}"] textarea`); ts[ts.length - 1]?.focus(); }, 0); });
  $$('.notes .it', b).forEach(it => it.onclick = e => {
    const arr = G.ann[it.dataset.key] || [], s = arr[+it.dataset.idx]; if (!s) return;
    if (e.target.closest('[data-del]')) { arr.splice(+it.dataset.idx, 1); setDirty(); drawAnn(); rerenderKeep(); return; }
    const pg = +it.dataset.page; if (pg >= 0 && pg !== V.cur) showPage(pg);
    openNotePop(s, false);
  });
  $$('[data-flag]', b).forEach(cb => cb.onchange = () => {
    const id = cb.dataset.flag; if (cb.checked) { if (!G.flags.includes(id)) G.flags.push(id); } else G.flags = G.flags.filter(x => x !== id);
    if (!G.ultEdited) G.ultimatum = G.flags.length ? buildUltimatum(G.flags, G.courseId) : '';
    setDirty(); paintAi(); scheduleAiIndex();
    if (cb.checked) $('#ultBox')?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  });
  $('#gComment').oninput = e => { G.comment = e.target.value; G.commentEdited = true; setDirty(); };
  const u = $('#gUlt'); if (u) u.oninput = () => { G.ultimatum = u.value; G.ultEdited = true; setDirty(); };
  $('#gNote').oninput = e => { G.note = e.target.value; setDirty(); };
  updateTotals(); paintGradeHint();
}
function rerenderKeep() { const y = window.scrollY; renderRight(); window.scrollTo(0, y); }
function paintGradeHint() {
  const h = $('#gradeHint'); if (!h) return;
  h.innerHTML = claudeCtl ? '<span class="auto"><i></i>Claude đang chấm theo tiêu chí…</span>' : G.criteria.some(x => x.claude != null) ? 'Claude đã chấm theo tiêu chí — sửa trực tiếp ô điểm nếu cần' : V.pages.length ? 'Nhập điểm vào từng ô' : 'Claude chấm tự động khi tải bài lên';
}
function paintAi() {
  const p = G.ai.percent, el = $('#aiPct');
  if (el) { el.textContent = p == null ? '–' : p + '%'; el.className = 'pct ' + pctClass(p); const nd = $('#aiNeedle'); nd.style.left = (p ?? 0) + '%'; nd.style.display = p == null ? 'none' : ''; $('#aiReason').textContent = G.ai.reason || G.ai.assessment || ''; $('#aiBusy').hidden = !(aiTimer || aiCtl); }
  const ub = $('#ultBox'); if (ub) { ub.hidden = !(G.flags.length || G.ultimatum); const t = $('#gUlt'); if (t && document.activeElement !== t) t.value = G.ultimatum; }
  renderRTabs();
}
let aiTimer = null, aiCtl = null;
function scheduleAiIndex() {
  clearTimeout(aiTimer); aiCtl?.abort(); aiCtl = null;
  aiTimer = setTimeout(async () => {
    aiTimer = null;
    if (!CAP.sample) { G.ai.percent = localAiIndex(G); G.ai.level = G.ai.percent >= 65 ? 'do' : G.ai.percent >= 30 ? 'vang' : 'xanh'; G.ai.reason = 'Ước tính trên máy từ dấu hiệu đã tick và tín hiệu file (Claude chưa sẵn sàng ở chế độ xem này).'; paintAi(); return; }
    const ctl = aiCtl = new AbortController(); paintAi();
    try { const r = await claudeAiIndex(G, ctl.signal); if (ctl.signal.aborted) return; Object.assign(G.ai, { percent: r.percent, level: r.level, reason: r.reason }); if (!G.ultEdited) G.ultimatum = r.ultimatum; setDirty(); }
    catch (e) { if (e.code === 'cancelled') return; G.ai.percent = localAiIndex(G); G.ai.reason = 'Ước tính trên máy (' + claudeErr(e) + ')'; }
    finally { if (aiCtl === ctl) aiCtl = null; }
    paintAi();
  }, 1100);
  paintAi();
}
function reloadLesson(resetCriteria) {
  const ls = lessonSetup(G.classId, G.courseId, G.lessonId);
  if (resetCriteria || !G.criteria.length) { G.objective = ls.objective; G.criteria = ls.criteria; }
  G.ai.policy = ls.policy;
  if (!G.mssv) { const st = nextStudent(G); if (st) { G.mssv = st.mssv; G.name = st.name; } }
  setDirty(); renderAll();
  if (resetCriteria && V.pages.length) autoGrade();
}
function updateTotals() {
  const mx = gMax(), over = G.criteria.some(x => x.score != null && x.score > x.max);
  $$('#critRows .crit').forEach(row => { const x = G.criteria[+row.dataset.i]; $('[data-f=score]', row)?.classList.toggle('err', !!x && x.score != null && (x.score > x.max || x.score < 0)); });
  const s = $('#critSum'); if (s) {
    s.className = 'crit-sum' + (over ? ' err' : '');
    s.innerHTML = `<span>${over ? 'Có ô nhập vượt điểm tối đa của tiêu chí' : 'Thang điểm ' + fmt(mx, 1)}</span><span class="num">Tổng: <b>${gHasScores() ? fmt(gTotal()) : '–'}</b></span>`;
  }
  renderScorebar();
}
function renderScorebar() {
  const t = gTotal(), has = gHasScores(), over = G.criteria.some(x => x.score != null && x.score > x.max);
  $('#scorebar').innerHTML = `<div class="tot ${has ? (over ? 'bad' : scoreClass(t)) : ''}"><b class="num">${has ? fmt(t) : '–'}</b><small>/ ${fmt(gMax(), 1)}</small></div>
    <span class="auto" ${claudeCtl ? '' : 'hidden'}><i></i><span id="autoTxt">Claude đang chấm tự động…</span></span>
    <span class="sp"></span>
    <button class="btn" id="copyBtn" title="Sao chép nhận xét">${icon('copy')}<span>Copy</span></button>
    <button class="btn" id="dlBtn">${icon('down')}<span>Tải nhận xét về máy</span></button>
    <button class="btn pri" id="saveBtn" title="Ctrl+S">${icon('save')}<span>Lưu &amp; duyệt</span></button>`;
  $('#copyBtn').onclick = copyComment; $('#dlBtn').onclick = downloadMenu; $('#saveBtn').onclick = () => saveG('duyet');
  if (curRoute === 'grade') renderHero();
}

/* ---------- tab Minh bạch AI ---------- */
function renderAiTab(b) {
  const a = findAssignment(G.classId, G.lessonId), L = AI_LEVELS[(G.ai.policy || 2) - 1];
  const auto = evidenceHave({ files: G.files, ai: G.ai }); const req = a?.evidence || ['source', 'versions', 'declare'];
  const ev = EVIDENCE.map(e => { const m = G.ai.manual?.[e.id]; const have = m != null ? m : auto[e.id]; return { ...e, have, req: req.includes(e.id), manual: m != null }; });
  const psdTree = G.files.map(f => f.signals?.psd?.tree).filter(Boolean)[0];
  b.innerHTML = `
  <section class="sec"><div class="sec-h"><h3><span class="k">1</span>Chính sách của bài</h3></div>
    <select class="inp" id="aPol">${AI_LEVELS.map(x => `<option value="${x.n}" ${x.n === L.n ? 'selected' : ''}>Mức ${x.n}: ${x.name}</option>`).join('')}</select><p class="muted" style="margin:0;font-size:.8rem">${esc(L.desc)}${a ? '' : ' (Chưa có bài tập công bố cho lớp/bài này — đang dùng mức mặc định.)'}</p></section>
  <section class="sec"><div class="sec-h"><h3><span class="k">2</span>Bản khai báo của sinh viên</h3></div>
    <textarea class="inp" id="aDec" rows="3" placeholder="Dán nguyên văn bản khai báo sử dụng AI của sinh viên">${esc(G.ai.declaration)}</textarea>
    <textarea class="inp" id="aRef" rows="2" placeholder="Bài viết phản tư ngắn (nếu có)">${esc(G.ai.reflection || '')}</textarea></section>
  <section class="sec"><div class="sec-h"><h3><span class="k">3</span>Checklist bằng chứng</h3><span class="muted" style="font-size:.74rem">bấm để sửa thủ công</span></div>
    <div class="ev">${ev.map(e => `<div><button class="btn ghost sm" data-ev="${e.id}" style="width:28px;padding:0" aria-label="Đổi trạng thái"><span class="${e.have ? 'y' : 'n'}">${e.have ? '✓' : '✗'}</span></button><span>${e.label}${e.req ? '' : ' <span class="faint">(không bắt buộc)</span>'}${e.manual ? ' <span class="chip">GV xác nhận</span>' : ''}</span></div>`).join('')}
    ${G.files.map(f => f.signals?.psd ? `<div><span class="y">·</span><span>${esc(f.name)}: <b>${f.signals.psd.layers}</b> layer, ${f.signals.psd.groups} group — ${f.signals.psd.layers > 8 && f.signals.psd.groups ? 'tổ chức có cấu trúc' : f.signals.psd.layers <= 1 ? 'gần như phẳng' : 'tổ chức đơn giản'}</span></div>` : '').join('')}</div></section>
  <section class="sec"><div class="sec-h"><h3><span class="k">4</span>Tín hiệu kỹ thuật</h3></div>
    ${G.files.length ? G.files.map(f => `<div><div style="font-weight:600;font-size:.84rem;margin-bottom:4px">${esc(f.name)} <span class="chip">${KINDS.find(k => k[0] === f.kind)?.[1] || ''}</span></div><dl class="sig">${signalLines(f.signals).map(([k, v]) => `<dt>${k}</dt><dd>${esc(v)}</dd>`).join('')}</dl></div>`).join('') : '<p class="muted" style="margin:0;font-size:.84rem">Chưa có file. Tải lên file gốc (PSD/AI) để đọc cấu trúc layer, điểm neo, metadata và nhãn Content Credentials.</p>'}
    ${(() => { const fin = G.files.find(f => f.kind === 'final' && f.signals?.w), src = G.files.find(f => f.kind === 'source' && f.signals?.w); if (!fin || !src) return ''; const r1 = fin.signals.w / fin.signals.h, r2 = src.signals.w / src.signals.h; const ok = Math.abs(r1 - r2) < .02; return `<div style="font-size:.82rem"><b>Độ khớp file gốc – file final:</b> <span class="chip ${ok ? 'ok' : 'warn'}">${ok ? 'Cùng tỉ lệ khung' : 'Khác tỉ lệ khung'}</span> ${fin.signals.w}×${fin.signals.h} so với ${src.signals.w}×${src.signals.h}</div>`; })()}
    ${psdTree ? `<details><summary style="cursor:pointer;font-size:.82rem;font-weight:600">Cấu trúc layer PSD</summary><div class="tree">${esc(psdTree)}</div></details>` : ''}</section>
  <section class="sec"><div class="sec-h"><h3><span class="k">5</span>Nhận định của Claude</h3></div>
    ${G.ai.assessment || G.ai.observations?.length ? `<p style="margin:0;font-size:.86rem">${esc(G.ai.assessment)}</p>${G.ai.observations?.length ? `<ul style="margin:0;padding-left:18px;font-size:.82rem">${G.ai.observations.map(o => `<li>${esc(o)}</li>`).join('')}</ul>` : ''}` : '<p class="muted" style="margin:0;font-size:.84rem">Chưa có. Bấm “Claude phân tích” — Claude sẽ đối chiếu bản khai báo, chính sách và tín hiệu kỹ thuật.</p>'}</section>
  <section class="sec"><div class="sec-h"><h3><span class="k">6</span>Mức cần xem xét</h3></div>
    <div class="row" style="align-items:flex-end;gap:14px;flex-wrap:nowrap"><div class="pct ${pctClass(G.ai.percent)}">${G.ai.percent == null ? '–' : G.ai.percent + '%'}</div><div style="flex:1;min-width:0"><div class="eyebrow">Chỉ số nghi vấn lạm dụng AI (Claude tính)</div><div class="meter"><i style="left:${G.ai.percent ?? 0}%;${G.ai.percent == null ? 'display:none' : ''}"></i></div></div></div>
    <div class="light"><button class="g" data-lv="xanh" aria-pressed="${G.ai.level === 'xanh'}">Xanh</button><button class="y" data-lv="vang" aria-pressed="${G.ai.level === 'vang'}">Vàng</button><button class="r" data-lv="do" aria-pressed="${G.ai.level === 'do'}">Đỏ</button></div>
    <input class="inp" id="aWhy" value="${esc(G.ai.why || '')}" placeholder="Lý do (VD: bản khai báo nói không dùng AI nhưng file có nhãn Generative Fill)">
    <p class="disclaim">Đây là gợi ý, không phải kết luận.</p></section>`;
  $('#aPol').onchange = e => { G.ai.policy = +e.target.value; setDirty(); renderAiTab(b); };
  $('#aDec').oninput = e => { G.ai.declaration = e.target.value; setDirty(); };
  $('#aRef').oninput = e => { G.ai.reflection = e.target.value; setDirty(); };
  $$('[data-ev]', b).forEach(x => x.onclick = () => { const id = x.dataset.ev; G.ai.manual ||= {}; const cur = G.ai.manual[id] ?? auto[id]; G.ai.manual[id] = !cur; setDirty(); renderAiTab(b); });
  $$('[data-lv]', b).forEach(x => x.onclick = () => { G.ai.level = G.ai.level === x.dataset.lv ? '' : x.dataset.lv; setDirty(); renderAiTab(b); renderRTabs(); });
  $('#aWhy').oninput = e => { G.ai.why = e.target.value; setDirty(); };
}

/* ---------- tab Vấn đáp ---------- */
function renderVivaTab(b) {
  const vv = G.viva; const fl = flagsFor(G.courseId).filter(f => G.flags.includes(f.id));
  b.innerHTML = `<section class="sec"><div class="sec-h"><h3>Buổi vấn đáp</h3></div>
    <div class="grid2"><label class="field"><span>Thời gian hẹn</span><input class="inp" type="datetime-local" id="vDate" value="${esc(vv.date || '')}"></label>
    <label class="field"><span>Kết luận</span><select class="inp" id="vOut">${[['', 'Chưa vấn đáp'], ['ok', 'Xác nhận sinh viên tự làm'], ['more', 'Cần nộp bổ sung bằng chứng'], ['board', 'Chuyển hội đồng xem xét']].map(([k, t]) => `<option value="${k}" ${vv.outcome === k ? 'selected' : ''}>${t}</option>`).join('')}</select></label></div></section>
  ${fl.length ? `<section class="sec"><div class="sec-h"><h3>Thao tác kiểm tra trực tiếp</h3></div><ul style="margin:0;padding-left:18px;font-size:.84rem">${fl.map(f => `<li>Yêu cầu sinh viên ${esc(f.proof)}.</li>`).join('')}</ul>
    <button class="btn sm" id="vFromFlags" style="align-self:flex-start">${icon('plus')}Đưa vào danh sách câu hỏi</button></section>` : ''}
  <section class="sec"><div class="sec-h"><h3>Câu hỏi vấn đáp</h3><span class="muted" style="font-size:.74rem">${vv.items.length ? 'Claude soạn từ bài và cờ nghi vấn' : ''}</span></div>
    ${vv.items.length ? vv.items.map((it, i) => `<div class="viva-q"><div class="row" style="flex-wrap:nowrap;align-items:flex-start"><span class="num faint">${i + 1}.</span><textarea class="inp" data-q="${i}" rows="2" style="flex:1">${esc(it.q)}</textarea><button class="btn ghost sm" data-rmq="${i}" aria-label="Xoá câu hỏi">${icon('x')}</button></div>
      <div class="row" style="align-items:center"><div class="seg">${[['ok', 'Trả lời được'], ['no', 'Không chứng minh được'], ['', 'Chưa hỏi']].map(([k, t]) => `<button data-res="${i}" data-v="${k}" aria-pressed="${(it.res || '') === k}">${t}</button>`).join('')}</div></div>
      <input class="inp" data-note="${i}" value="${esc(it.note || '')}" placeholder="Ghi chú câu trả lời"></div>`).join('') : '<p class="muted" style="margin:0;font-size:.84rem">Chưa có câu hỏi. Claude sẽ soạn 3–5 câu khi phân tích bài; hoặc thêm thủ công.</p>'}
    <div class="row"><button class="btn sm" id="vAdd">${icon('plus')}Thêm câu hỏi</button></div></section>
  <section class="sec"><label class="field"><span>Biên bản / ghi chú chung</span><textarea class="inp" id="vNote" rows="3">${esc(vv.note || '')}</textarea></label></section>`;
  $('#vDate').onchange = e => { vv.date = e.target.value; setDirty(); };
  $('#vOut').onchange = e => { vv.outcome = e.target.value; setDirty(); };
  $('#vNote').oninput = e => { vv.note = e.target.value; setDirty(); };
  $$('[data-q]', b).forEach(t => t.oninput = () => { vv.items[+t.dataset.q].q = t.value; setDirty(); });
  $$('[data-note]', b).forEach(t => t.oninput = () => { vv.items[+t.dataset.note].note = t.value; setDirty(); });
  $$('[data-res]', b).forEach(x => x.onclick = () => { vv.items[+x.dataset.res].res = x.dataset.v; setDirty(); renderVivaTab(b); });
  $$('[data-rmq]', b).forEach(x => x.onclick = () => { vv.items.splice(+x.dataset.rmq, 1); setDirty(); renderVivaTab(b); renderRTabs(); });
  $('#vAdd').onclick = () => { vv.items.push({ q: '', res: '', note: '' }); setDirty(); renderVivaTab(b); renderRTabs(); };
  const ff = $('#vFromFlags'); if (ff) ff.onclick = () => { fl.forEach(f => vv.items.push({ q: 'Em hãy ' + f.proof + '.', res: '', note: '' })); setDirty(); renderVivaTab(b); renderRTabs(); };
}

/* ---------- khu dưới: danh sách điểm lớp + trang ---------- */
function renderBottom() {
  const k = klass(G.classId);
  $('#bTabs').innerHTML = `<button aria-selected="${bTab === 'list'}" data-b="list">Danh sách điểm lớp ${esc(k?.name || G.className || '')}</button><button aria-selected="${bTab === 'pages'}" data-b="pages">Trang &amp; phiên bản (${V.pages.length})</button>`;
  $$('#bTabs button').forEach(x => x.onclick = () => { bTab = x.dataset.b; renderBottom(); });
  const body = $('#gbBody');
  if (bTab === 'pages') {
    body.innerHTML = V.pages.length ? `<div class="strip" id="strip"></div>` : `<div class="empty">Chưa có trang nào. Tải bài lên để xem dòng thời gian các phiên bản.</div>`;
    const strip = $('#strip');
    if (strip) V.pages.forEach((p, i) => {
      const rec = G.files.find(f => f.id === p.fileId);
      const el = document.createElement('div'); el.className = 'thumb'; el.setAttribute('aria-current', i === V.cur);
      const tc = document.createElement('canvas'); const t = fitCanvas(p.canvas, p.canvas.width, p.canvas.height, 192); tc.width = t.width; tc.height = t.height; tc.getContext('2d').drawImage(t, 0, 0); tc.onclick = () => showPage(i); tc.style.cursor = 'pointer';
      el.appendChild(tc);
      el.insertAdjacentHTML('beforeend', `<small title="${esc(p.label)}">${esc(p.label)}</small>${p.pageNo === 1 && rec ? `<div class="row" style="gap:4px;flex-wrap:nowrap"><select data-kind="${rec.id}" aria-label="Loại file">${KINDS.map(([kk, tt]) => `<option value="${kk}" ${rec.kind === kk ? 'selected' : ''}>${tt}</option>`).join('')}</select><button class="btn ghost sm" data-rmf="${rec.id}" style="padding:0 4px;height:22px" aria-label="Gỡ file">${icon('x')}</button></div>` : ''}`);
      strip.appendChild(el);
    });
    $$('[data-kind]', body).forEach(s => s.onchange = () => { const r = G.files.find(f => f.id === s.dataset.kind); r.kind = s.value; V.pages.forEach(p => { if (p.fileId === r.id) p.kind = s.value; }); setDirty(); });
    $$('[data-rmf]', body).forEach(x => x.onclick = () => { const id = x.dataset.rmf; G.files = G.files.filter(f => f.id !== id); V.pages = V.pages.filter(p => p.fileId !== id); V.cur = 0; setDirty(); renderAll(); });
    return;
  }
  const roster = [...(k?.students || [])].sort((a, b) => String(a.mssv).localeCompare(String(b.mssv)));
  const mine = subsArr().filter(s => s.classId === G.classId && s.courseId === G.courseId);
  const latest = (mssv, lid) => mine.filter(s => String(s.mssv).trim() === String(mssv).trim() && s.lessonId === lid).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0))[0];
  const extra = [...new Set(mine.filter(s => !roster.some(r => String(r.mssv) === String(s.mssv))).map(s => s.mssv))].map(m => ({ mssv: m, name: mine.find(s => s.mssv === m)?.name || '' }));
  const people = roster.concat(extra);
  const ST = s => !s ? ['Chưa chấm', ''] : STATUS[s.status] || STATUS.cho;
  let html = '';
  if (!listAll) {
    const rows = people.map(p => ({ p, s: latest(p.mssv, G.lessonId) }));
    const appr = rows.filter(r => r.s?.status === 'duyet'), tots = appr.map(r => subTotal(r.s)).filter(x => x != null);
    html = `<div class="row" style="padding:8px 12px;align-items:center;justify-content:space-between"><span class="muted" style="font-size:.8rem">Bài ${lesson(G.courseId, G.lessonId).no} · đã duyệt <b class="num">${appr.length}/${people.length}</b> · TB <b class="num">${fmt(mean(tots))}</b>${tots.length ? ` · cao nhất <b class="num">${fmt(Math.max(...tots))}</b> · thấp nhất <b class="num">${fmt(Math.min(...tots))}</b>` : ''}</span>
      <label class="chk" style="font-size:.78rem"><input type="checkbox" id="lAll" ${listAll ? 'checked' : ''}>Bảng điểm cả môn</label></div>
      ${people.length ? `<table class="tbl"><thead><tr><th>#</th><th>MSSV</th><th>Họ tên</th><th>Điểm</th><th>AI</th><th>Trạng thái</th></tr></thead><tbody>${rows.map(({ p, s }, i) => { const st = ST(s), cur = String(p.mssv) === String(G.mssv); const t = s ? subTotal(s) : null;
        return `<tr class="click ${cur ? 'cur' : ''}" ${s ? `data-open="${s.id}"` : `data-new="${esc(p.mssv)}"`}><td class="num faint">${i + 1}</td><td class="num">${esc(p.mssv)}</td><td>${esc(p.name)}${cur ? ' <span class="chip acc">đang chấm</span>' : ''}</td>
        <td class="num"><b style="color:var(--${s?.status === 'duyet' ? scoreClass(t) || 'fg' : 'faint'})">${s ? fmt(t) : '–'}</b></td><td>${s?.ai?.percent != null ? `<span class="chip ${pctClass(s.ai.percent)}">${s.ai.percent}%</span>` : ''}${(s?.flags || []).length ? ' ⚑' : ''}</td><td><span class="chip ${st[1]}">${st[0]}</span></td></tr>`; }).join('')}</tbody></table>`
        : `<div class="empty"><b>Lớp ${esc(k?.name || G.classId)} chưa có danh sách sinh viên</b>Thêm danh sách ở Môn học &amp; Lớp — mọi sinh viên và điểm của từng bạn sẽ hiện ở đây.</div>`}`;
  } else {
    const ls = course(G.courseId).lessons.filter(l => mine.some(s => s.lessonId === l.id) || l.id === G.lessonId);
    html = `<div class="row" style="padding:8px 12px;align-items:center;justify-content:space-between"><span class="muted" style="font-size:.8rem">Bảng điểm ${esc(course(G.courseId).soft)} · lớp ${esc(k?.name || G.classId)} · ${people.length} SV</span>
      <label class="chk" style="font-size:.78rem"><input type="checkbox" id="lAll" checked>Bảng điểm cả môn</label></div>
      <div style="overflow-x:auto"><table class="tbl"><thead><tr><th>MSSV</th><th>Họ tên</th>${ls.map(l => `<th style="text-align:center">B${l.no}</th>`).join('')}<th style="text-align:center">TB</th></tr></thead><tbody>${people.map(p => { const sc = ls.map(l => { const s = latest(p.mssv, l.id); return s?.status === 'duyet' ? subTotal(s) : null; }); const v = sc.filter(x => x != null);
        return `<tr class="${String(p.mssv) === String(G.mssv) ? 'cur' : ''}"><td class="num">${esc(p.mssv)}</td><td style="white-space:nowrap">${esc(p.name)}</td>${sc.map((x, j) => { const s = latest(p.mssv, ls[j].id); return `<td class="num ${s ? 'click' : ''}" style="text-align:center;cursor:${s ? 'pointer' : 'default'}" ${s ? `data-open="${s.id}"` : ''}>${x == null ? (s ? '<span class="faint">nháp</span>' : '<span class="faint">–</span>') : fmt(x)}</td>`; }).join('')}<td class="num" style="text-align:center"><b>${v.length ? fmt(mean(v)) : '–'}</b></td></tr>`; }).join('')}</tbody></table></div>`;
  }
  body.innerHTML = html;
  $('#lAll').onchange = e => { listAll = e.target.checked; renderBottom(); };
  $$('[data-open]', body).forEach(tr => tr.onclick = () => openSub(tr.dataset.open));
  $$('[data-new]', body).forEach(tr => tr.onclick = () => startStudent(tr.dataset.new));
}
function startStudent(mssv) {
  const st = klass(G.classId)?.students?.find(s => String(s.mssv) === String(mssv));
  const apply = () => { if (G.id || V.pages.length) { const keep = { classId: G.classId, courseId: G.courseId, lessonId: G.lessonId, objective: G.objective, criteria: G.criteria }; G = blankG(keep); window.G = G; V.pages = []; V.cur = 0; V.cmp = null; dirty = false; }
    G.mssv = String(mssv); G.name = st?.name || ''; renderAll(); toast('Chấm bài của ' + (G.name || G.mssv) + ' — thả bài làm vào khung bên trái'); };
  if (dirty && (gHasScores() || V.pages.length) && !G.id) confirmBox('Bài của ' + (G.name || 'sinh viên hiện tại') + ' chưa lưu. Chuyển sang sinh viên khác?', 'Chuyển sinh viên', apply); else apply();
}
window.onGradeStoreChange = col => { if (col === 'subs' || col === 'all') renderBottom(); if (col === 'classes' || col === 'all') { const d = $('#dlStu'); if (d) d.innerHTML = (klass(G.classId)?.students || []).map(s => `<option value="${esc(s.mssv)}">${esc(s.name)}</option>`).join(''); } };

/* ---------- khung xem: zoom, pan, chú thích, lưới, so sánh ---------- */
function annKey(p) { return p.fileId + ':' + (p.pageNo || 1); }
function curAnn() { const p = V.pages[V.cur]; if (!p) return []; return (G.ann[annKey(p)] ||= []); }
function showPage(i) {
  const st = $('#stage'), drop = $('#drop');
  if (!V.pages.length) { st.hidden = true; drop.hidden = false; $('#vBadges').innerHTML = ''; $('#cmpCtl').hidden = true; $('#cmpBtn').setAttribute('aria-pressed', false); $('#cPop').hidden = true; return; }
  V.cur = clamp(i, 0, V.pages.length - 1); const p = V.pages[V.cur];
  drop.hidden = true; st.hidden = false;
  const b = $('#cvBase'); b.width = p.canvas.width; b.height = p.canvas.height; b.getContext('2d').drawImage(p.canvas, 0, 0);
  ['#cvAnn', '#cvOvl', '#cvCmp'].forEach(s => { const c = $(s); c.width = p.canvas.width; c.height = p.canvas.height; c.style.width = c.width + 'px'; c.style.height = c.height + 'px'; });
  V.redo = []; drawAnn(); drawGrid(); drawCmp(); fit(); V.fitted = true;
  const rec = G.files.find(f => f.id === p.fileId);
  $('#vBadges').innerHTML = `<span class="chip">${V.cur + 1}/${V.pages.length} · ${esc(p.label)}</span>${rec ? `<span class="chip">${KINDS.find(k => k[0] === rec.kind)?.[1] || ''}</span>` : ''}${GRIDS[V.grid] && V.grid ? `<span class="chip">${GRIDS[V.grid]}</span>` : ''}`;
  if (bTab === 'pages') $$('.thumb').forEach((t, k) => t.setAttribute('aria-current', k === V.cur));
  $('#cPop').hidden = true; V.pick = [];
  fillCmpSel();
}
function fit() {
  const vw = $('#vw'), p = V.pages[V.cur]; if (!p) return;
  const W = vw.clientWidth, H = vw.clientHeight; if (!W || !H) return;
  V.zoom = Math.min(W / p.canvas.width, H / p.canvas.height) * .94; V.tx = (W - p.canvas.width * V.zoom) / 2; V.ty = (H - p.canvas.height * V.zoom) / 2; applyT();
}
function applyT() { $('#stage').style.transform = `translate(${V.tx}px,${V.ty}px) scale(${V.zoom})`; $('#zoomv').textContent = Math.round(V.zoom * 100) + '%'; $('#cmpLine').style.width = (2 / V.zoom) + 'px'; }
function zoomAt(f, cx, cy) {
  const vw = $('#vw').getBoundingClientRect(); cx ??= vw.width / 2; cy ??= vw.height / 2;
  const nz = clamp(V.zoom * f, .05, 8); V.tx = cx - (cx - V.tx) * nz / V.zoom; V.ty = cy - (cy - V.ty) * nz / V.zoom; V.zoom = nz; applyT();
}
function zoomTo(z) { zoomAt(z / V.zoom); }
function toImg(e) { const r = $('#vw').getBoundingClientRect(); return [(e.clientX - r.left - V.tx) / V.zoom, (e.clientY - r.top - V.ty) / V.zoom]; }
function anchorOf(s) {
  if (s.t === 'pen') return s.pts[0];
  if (s.t === 'arrow') return s.a;
  if (s.t === 'text') return s.p;
  return [Math.min(s.a[0], s.b[0]), Math.min(s.a[1], s.b[1])];
}
function bboxOf(s) {
  const ps = s.t === 'pen' ? s.pts : s.t === 'text' ? [s.p, s.p] : [s.a, s.b];
  const xs = ps.map(p => p[0]), ys = ps.map(p => p[1]);
  return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
}
const badgeR = W => Math.max(12, W / 80);
function inkOf(c) { return c === '#FFFFFF' || c === '#F2B705' ? '#9A6A00' : c; }
function drawShape(x, s, W, H) {
  const P = q => [q[0] * W, q[1] * H]; const lw = Math.max(1, s.w * W);
  x.strokeStyle = s.c; x.fillStyle = s.c; x.lineWidth = lw; x.lineCap = 'round'; x.lineJoin = 'round';
  if (s.t === 'pen') { x.beginPath(); s.pts.forEach((q, i) => { const [a, b] = P(q); i ? x.lineTo(a, b) : x.moveTo(a, b); }); x.stroke(); }
  if (s.t === 'rect') { const [a, b] = P(s.a), [c, d] = P(s.b); x.strokeRect(Math.min(a, c), Math.min(b, d), Math.abs(c - a), Math.abs(d - b)); }
  if (s.t === 'ellipse') { const [a, b] = P(s.a), [c, d] = P(s.b); x.beginPath(); x.ellipse((a + c) / 2, (b + d) / 2, Math.abs(c - a) / 2 || 1, Math.abs(d - b) / 2 || 1, 0, 0, Math.PI * 2); x.stroke(); }
  if (s.t === 'arrow') { const [a, b] = P(s.a), [c, d] = P(s.b); x.beginPath(); x.moveTo(a, b); x.lineTo(c, d); x.stroke(); const ang = Math.atan2(d - b, c - a), hl = Math.max(12, lw * 4); x.beginPath(); x.moveTo(c, d); x.lineTo(c - hl * Math.cos(ang - .45), d - hl * Math.sin(ang - .45)); x.lineTo(c - hl * Math.cos(ang + .45), d - hl * Math.sin(ang + .45)); x.closePath(); x.fill(); }
  if (s.t === 'text') { const [a, b] = P(s.p); const fs = Math.max(14, s.size * W); x.font = `600 ${fs}px "Be Vietnam Pro",sans-serif`; x.textBaseline = 'top'; const m = x.measureText(s.s); x.fillStyle = 'rgba(255,255,255,.85)'; x.fillRect(a - 4, b - 3, m.width + 8, fs * 1.3 + 4); x.fillStyle = s.c === '#FFFFFF' ? '#111' : s.c; x.fillText(s.s, a, b); }
}
function drawBadge(x, s, n, W, H) {
  const [ax, ay] = anchorOf(s), r = badgeR(W), cx = ax * W, cy = ay * H;
  x.beginPath(); x.arc(cx, cy, r, 0, Math.PI * 2); x.fillStyle = inkOf(s.c); x.fill(); x.lineWidth = Math.max(2, r / 5); x.strokeStyle = '#fff'; x.stroke();
  x.fillStyle = '#fff'; x.font = `700 ${Math.round(r * 1.05)}px "JetBrains Mono",monospace`; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(String(n), cx, cy + 1); x.textAlign = 'start';
  if (!s.note) { x.beginPath(); x.arc(cx + r * .8, cy - r * .8, r * .32, 0, 7); x.fillStyle = '#F2B705'; x.fill(); }
}
function drawAnnTo(x, key, W, H, nums) {
  (G.ann[key] || []).forEach(s => drawShape(x, s, W, H));
  (G.ann[key] || []).forEach(s => { const n = nums.get(s); if (n) drawBadge(x, s, n, W, H); });
}
function noteNums() { const m = new Map(); allNotes().forEach(o => m.set(o.s, o.n)); return m; }
function drawAnn() {
  const c = $('#cvAnn'), x = c.getContext('2d'); x.clearRect(0, 0, c.width, c.height);
  const p = V.pages[V.cur];
  if (p) drawAnnTo(x, annKey(p), c.width, c.height, noteNums());
  if (V.drawing) drawShape(x, V.drawing, c.width, c.height);
  if (V.hot) { const [a, b, cc, d] = bboxOf(V.hot), pad = 6; x.save(); x.setLineDash([8, 6]); x.strokeStyle = 'rgba(0,0,0,.55)'; x.lineWidth = 2; x.strokeRect(a * c.width - pad, b * c.height - pad, (cc - a) * c.width + 2 * pad, (d - b) * c.height + 2 * pad); x.restore(); }
  V.pick.forEach((p, i) => { x.strokeStyle = '#000'; x.lineWidth = 3; x.beginPath(); x.arc(p[0], p[1], 9, 0, 7); x.stroke(); x.strokeStyle = '#fff'; x.lineWidth = 1.5; x.stroke(); x.fillStyle = '#fff'; x.font = '700 12px sans-serif'; x.fillText(i ? 'B' : 'A', p[0] + 12, p[1] - 12); });
}
function segDist(px, py, ax, ay, bx, by) { const dx = bx - ax, dy = by - ay, L = dx * dx + dy * dy; let t = L ? ((px - ax) * dx + (py - ay) * dy) / L : 0; t = clamp(t, 0, 1); return Math.hypot(px - (ax + t * dx), py - (ay + t * dy)); }
function hitShape(px, py) {
  const p = V.pages[V.cur]; if (!p) return null; const arr = G.ann[annKey(p)] || [];
  const W = $('#cvBase').width, H = $('#cvBase').height, tol = 10 / V.zoom, r = badgeR(W);
  for (let i = arr.length - 1; i >= 0; i--) {
    const s = arr[i]; if (s.t === 'text') continue;
    const [ax, ay] = anchorOf(s); if (Math.hypot(px - ax * W, py - ay * H) <= r + tol) return s;
    const [x0, y0, x1, y1] = bboxOf(s).map((v, k) => v * (k % 2 ? H : W));
    if (s.t === 'rect' && px >= x0 - tol && px <= x1 + tol && py >= y0 - tol && py <= y1 + tol) return s;
    if (s.t === 'ellipse') { const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, rx = (x1 - x0) / 2 + tol, ry = (y1 - y0) / 2 + tol; if (((px - cx) / rx) ** 2 + ((py - cy) / ry) ** 2 <= 1) return s; }
    if (s.t === 'arrow' && segDist(px, py, s.a[0] * W, s.a[1] * H, s.b[0] * W, s.b[1] * H) <= tol + s.w * W) return s;
    if (s.t === 'pen') { for (let k = 1; k < s.pts.length; k++) if (segDist(px, py, s.pts[k - 1][0] * W, s.pts[k - 1][1] * H, s.pts[k][0] * W, s.pts[k][1] * H) <= tol + s.w * W) return s; }
  }
  return null;
}
function openNotePop(s, isNew) {
  $('#notePop')?.remove();
  const vw = $('#vw'), W = $('#cvBase').width, H = $('#cvBase').height, [ax, ay] = anchorOf(s);
  const n = noteNums().get(s) || '';
  let left = V.tx + ax * W * V.zoom + 18, top = V.ty + ay * H * V.zoom + 18;
  left = clamp(left, 10, vw.clientWidth - 290); top = clamp(top, 10, vw.clientHeight - 230);
  const sug = [...new Set([...(G.fix || []).filter(Boolean).slice(0, 3), ...course(G.courseId).fix.slice(0, 4)])].slice(0, 5);
  const pop = document.createElement('div'); pop.className = 'note-pop'; pop.id = 'notePop'; pop.style.left = left + 'px'; pop.style.top = top + 'px';
  pop.innerHTML = `<b>Ghi chú lỗi #${n}</b><textarea class="inp" rows="3" placeholder="Mô tả lỗi cho sinh viên, VD: Biên tóc còn viền trắng (halo), cần tinh chỉnh mask">${esc(s.note || '')}</textarea>
    <div class="tags">${sug.map(t => `<button class="tag" type="button" data-sug="${esc(t)}" style="height:24px;font-size:.72rem">${esc(t.length > 34 ? t.slice(0, 33) + '…' : t)}</button>`).join('')}</div>
    <div class="row" style="justify-content:space-between"><button class="btn ghost sm danger" data-x="del">Xoá nét</button><div class="row"><button class="btn sm" data-x="skip">${isNew ? 'Bỏ qua' : 'Đóng'}</button><button class="btn sm pri" data-x="ok">Lưu ghi chú</button></div></div>`;
  vw.appendChild(pop);
  const ta = $('textarea', pop); setTimeout(() => ta.focus(), 0);
  const close = () => { pop.remove(); V.hot = null; drawAnn(); if (rTab === 'score') rerenderKeep(); };
  const save = () => { s.note = ta.value.trim(); setDirty(); close(); };
  $$('[data-sug]', pop).forEach(b => b.onclick = () => { ta.value = (ta.value ? ta.value.trim() + '. ' : '') + b.dataset.sug; ta.focus(); });
  pop.querySelector('[data-x=ok]').onclick = save;
  pop.querySelector('[data-x=skip]').onclick = close;
  pop.querySelector('[data-x=del]').onclick = () => { for (const k in G.ann) { const i = G.ann[k].indexOf(s); if (i >= 0) G.ann[k].splice(i, 1); } setDirty(); close(); };
  ta.onkeydown = e => { e.stopPropagation(); if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); save(); } if (e.key === 'Escape') close(); };
  pop.addEventListener('pointerdown', e => e.stopPropagation());
  V.hot = s; drawAnn();
}
function showNoteTip(e, s) {
  const tip = $('#tip'); if (!s) { if (!tip.dataset.lock) tip.hidden = true; return; }
  const n = noteNums().get(s);
  tip.textContent = `Lỗi ${n}: ${s.note || '(chưa có ghi chú — bấm số để thêm)'}`; tip.hidden = false; tip.style.maxWidth = '320px'; tip.style.whiteSpace = 'normal'; tip.style.fontFamily = 'var(--f-body)';
  tip.style.left = Math.min(e.clientX + 14, innerWidth - tip.offsetWidth - 8) + 'px'; tip.style.top = (e.clientY + 16) + 'px';
}
function drawGrid() {
  const c = $('#cvOvl'), x = c.getContext('2d'), W = c.width, H = c.height; x.clearRect(0, 0, W, H); if (!V.grid) return;
  x.strokeStyle = 'rgba(0,200,255,.85)'; x.lineWidth = Math.max(1, W / 900); x.beginPath();
  if (V.grid === 1) { [1, 2].forEach(k => { x.moveTo(W * k / 3, 0); x.lineTo(W * k / 3, H); x.moveTo(0, H * k / 3); x.lineTo(W, H * k / 3); }); x.stroke(); x.fillStyle = 'rgba(0,200,255,.9)'; [1, 2].forEach(i => [1, 2].forEach(j => { x.beginPath(); x.arc(W * i / 3, H * j / 3, Math.max(4, W / 200), 0, 7); x.fill(); })); return; }
  if (V.grid === 2) { const m = W * .05, gut = W * .015, cw = (W - 2 * m - 11 * gut) / 12; x.fillStyle = 'rgba(255,0,140,.10)'; for (let i = 0; i < 12; i++) x.fillRect(m + i * (cw + gut), 0, cw, H); x.strokeStyle = 'rgba(255,0,140,.5)'; x.strokeRect(m, m, W - 2 * m, H - 2 * m); return; }
  if (V.grid === 3) { const s = Math.min(W, H) / 8; for (let a = s; a < W; a += s) { x.moveTo(a, 0); x.lineTo(a, H); } for (let b = s; b < H; b += s) { x.moveTo(0, b); x.lineTo(W, b); } x.stroke(); return; }
  if (V.grid === 4) { x.moveTo(0, 0); x.lineTo(W, H); x.moveTo(W, 0); x.lineTo(0, H); x.moveTo(W / 2, 0); x.lineTo(W / 2, H); x.moveTo(0, H / 2); x.lineTo(W, H / 2); x.stroke(); }
}
function fillCmpSel() {
  const s = $('#cmpSel'); s.innerHTML = V.pages.map((p, i) => i === V.cur ? '' : `<option value="${i}" ${V.cmp === i ? 'selected' : ''}>${esc(p.label)}</option>`).join('');
  if (V.cmp != null && (V.cmp === V.cur || V.cmp >= V.pages.length)) { V.cmp = V.pages.length > 1 ? (V.cur ? 0 : 1) : null; drawCmp(); }
}
function drawCmp() {
  const c = $('#cvCmp'), line = $('#cmpLine'), on = V.cmp != null && V.pages[V.cmp] && V.cmp !== V.cur;
  $('#cmpCtl').hidden = V.cmp == null; $('#cmpBtn').setAttribute('aria-pressed', V.cmp != null);
  if (!on) { c.hidden = true; line.hidden = true; return; }
  c.hidden = false; line.hidden = false; const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(V.pages[V.cmp].canvas, 0, 0, c.width, c.height);
  c.style.clipPath = `inset(0 0 0 ${V.cmpPos}%)`; line.style.left = V.cmpPos + '%';
}
function contrastRatio(a, b) {
  const L = ([r, g, b2]) => { const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }; return .2126 * f(r) + .7152 * f(g) + .0722 * f(b2); };
  const l1 = L(a), l2 = L(b); return (Math.max(l1, l2) + .05) / (Math.min(l1, l2) + .05);
}
function sampleAt(px, py) {
  const c = $('#cvBase'), x = c.getContext('2d'); const sx = clamp(Math.round(px) - 2, 0, c.width - 5), sy = clamp(Math.round(py) - 2, 0, c.height - 5);
  const d = x.getImageData(sx, sy, 5, 5).data; let r = 0, g = 0, b = 0; for (let i = 0; i < d.length; i += 4) { r += d[i]; g += d[i + 1]; b += d[i + 2]; } const n = d.length / 4; return [r / n, g / n, b / n].map(Math.round);
}
const hex = c => '#' + c.map(v => v.toString(16).padStart(2, '0')).join('').toUpperCase();
function showContrast() {
  const pop = $('#cPop'); if (V.pick.length < 2) { pop.hidden = false; pop.innerHTML = `<b>Đo tương phản WCAG</b><span class="muted">Bấm điểm màu ${V.pick.length ? 'thứ hai (nền)' : 'thứ nhất (chữ)'}</span>`; return; }
  const a = sampleAt(...V.pick[0]), b = sampleAt(...V.pick[1]), r = contrastRatio(a, b);
  const badge = (ok, t) => `<span class="chip ${ok ? 'ok' : 'bad'}">${ok ? '✓' : '✗'} ${t}</span>`;
  pop.hidden = false; pop.innerHTML = `<div class="row" style="justify-content:space-between;align-items:center"><b>Tương phản</b><button class="btn ghost sm" id="cpX" aria-label="Đóng" style="padding:0 4px">${icon('x')}</button></div>
    <div class="sws"><i style="background:${hex(a)}"></i><span class="mono">${hex(a)}</span><i style="background:${hex(b)}"></i><span class="mono">${hex(b)}</span></div>
    <div class="ratio num">${r.toFixed(2)} : 1</div><div class="row" style="gap:4px">${badge(r >= 4.5, 'AA chữ thường')}${badge(r >= 3, 'AA chữ lớn')}${badge(r >= 7, 'AAA')}</div>
    <button class="btn sm" id="cpAdd">Ghi vào ghi chú GV</button>`;
  $('#cpX').onclick = () => { pop.hidden = true; V.pick = []; drawAnn(); };
  $('#cpAdd').onclick = () => { G.note = (G.note ? G.note + '; ' : '') + `Tương phản ${hex(a)}/${hex(b)} = ${r.toFixed(2)}:1 (${r >= 4.5 ? 'đạt' : 'chưa đạt'} WCAG AA)`; setDirty(); toast('Đã ghi vào ghi chú giảng viên'); if (rTab === 'score') { const n = $('#gNote'); if (n) n.value = G.note; } };
}
function setTool(t) { V.tool = t; paintTools(); const vw = $('#vw'); vw.className = 'viewer ' + (t === 'pan' ? 'pan' : t === 'pick' ? 'pick' : 'draw'); if (t === 'pick') { V.pick = []; showContrast(); } else { $('#cPop').hidden = true; V.pick = []; drawAnn(); } }
function paintTools() { $$('[data-tool]').forEach(b => b.setAttribute('aria-pressed', b.dataset.tool === V.tool)); $$('[data-color]').forEach(b => b.setAttribute('aria-pressed', b.dataset.color === V.color)); $('#gridBtn').setAttribute('aria-pressed', !!V.grid); $('#gridBtn').title = 'Lưới phủ (G): ' + GRIDS[V.grid]; }
function bindViewer() {
  const vw = $('#vw', gradeEl);
  $$('[data-tool]', gradeEl).forEach(b => b.onclick = () => setTool(b.dataset.tool));
  $$('[data-color]', gradeEl).forEach(b => b.onclick = () => { V.color = b.dataset.color; paintTools(); if (V.tool === 'pan' || V.tool === 'pick') setTool('pen'); });
  $('#penW', gradeEl).onchange = e => V.width = +e.target.value;
  $('#undo', gradeEl).onclick = undo; $('#redo', gradeEl).onclick = redo;
  $('#clearAnn', gradeEl).onclick = () => { const a = curAnn(); if (!a.length) return; V.redo = a.splice(0); annChanged(); toast('Đã xoá chú thích trang này (Làm lại để khôi phục)'); };
  $('#zIn', gradeEl).onclick = () => zoomAt(1.25); $('#zOut', gradeEl).onclick = () => zoomAt(.8); $('#zFit', gradeEl).onclick = fit;
  $('#zPreset', gradeEl).onchange = e => { if (e.target.value) zoomTo(+e.target.value); e.target.value = ''; };
  $('#gridBtn', gradeEl).onclick = () => { V.grid = (V.grid + 1) % GRIDS.length; drawGrid(); paintTools(); toast(GRIDS[V.grid]); };
  $('#cmpBtn', gradeEl).onclick = () => { if (V.pages.length < 2) { toast('Cần ít nhất 2 trang/phiên bản để so sánh.'); return; } V.cmp = V.cmp == null ? (V.cur ? 0 : 1) : null; fillCmpSel(); drawCmp(); };
  $('#cmpSel', gradeEl).onchange = e => { V.cmp = +e.target.value; drawCmp(); };
  $('#cmpRange', gradeEl).oninput = e => { V.cmpPos = +e.target.value; drawCmp(); };
  const pick = () => $('#filePick').click();
  $('#addFile', gradeEl).onclick = pick; $('#dropPick', gradeEl).onclick = pick;
  $('#filePick').onchange = e => { if (curRoute === 'grade') addFiles([...e.target.files]); e.target.value = ''; };
  ['dragenter', 'dragover'].forEach(ev => vw.addEventListener(ev, e => { e.preventDefault(); $('#drop').classList.add('hot'); }));
  ['dragleave', 'drop'].forEach(ev => vw.addEventListener(ev, e => { e.preventDefault(); $('#drop').classList.remove('hot'); }));
  vw.addEventListener('drop', e => { const fs = [...(e.dataTransfer?.files || [])]; if (fs.length) addFiles(fs); });
  vw.addEventListener('wheel', e => { if (!V.pages.length) return; e.preventDefault(); const r = vw.getBoundingClientRect(); if (e.ctrlKey || e.metaKey || Math.abs(e.deltaY) > Math.abs(e.deltaX)) zoomAt(Math.exp(-e.deltaY * .0015), e.clientX - r.left, e.clientY - r.top); else { V.tx -= e.deltaX; applyT(); } }, { passive: false });
  let drag = null, spaceDown = false;
  window.addEventListener('keydown', e => { if (e.code === 'Space' && curRoute === 'grade' && !isTyping(e)) { spaceDown = true; vw.classList.add('pan'); e.preventDefault(); } });
  window.addEventListener('keyup', e => { if (e.code === 'Space') { spaceDown = false; setTool(V.tool); } });
  vw.addEventListener('pointerdown', e => {
    if (!V.pages.length || e.target.closest('.contrast-pop,.text-entry,.note-pop')) return;
    if ($('#notePop')) { $('#notePop').remove(); V.hot = null; drawAnn(); }
    vw.setPointerCapture(e.pointerId); $('#tip').hidden = true;
    const [x, y] = toImg(e), c = $('#cvBase'), W = c.width, H = c.height, n = [x / W, y / H];
    if (V.tool === 'pan' || spaceDown || e.button === 1) { drag = { sx: e.clientX, sy: e.clientY, tx: V.tx, ty: V.ty, hit: V.tool === 'pan' ? hitShape(x, y) : null }; vw.classList.add('drag'); return; }
    if (V.tool === 'pick') { if (V.pick.length >= 2) V.pick = []; V.pick.push([clamp(x, 0, W - 1), clamp(y, 0, H - 1)]); drawAnn(); showContrast(); return; }
    if (V.tool === 'text') { placeText(e, n); return; }
    V.drawing = V.tool === 'pen' ? { t: 'pen', pts: [n], c: V.color, w: V.width / W * Math.max(1, W / 1000) } : { t: V.tool, a: n, b: n, c: V.color, w: V.width / W * Math.max(1, W / 1000) };
  });
  vw.addEventListener('pointermove', e => {
    if (drag) { V.tx = drag.tx + e.clientX - drag.sx; V.ty = drag.ty + e.clientY - drag.sy; applyT(); return; }
    if (!V.drawing) { if (!V.pages.length || e.target.closest('.note-pop,.contrast-pop')) { $('#tip').hidden = true; return; } const [hx, hy] = toImg(e), h = hitShape(hx, hy); showNoteTip(e, h); vw.style.cursor = h && V.tool === 'pan' ? 'pointer' : ''; return; }
    const [x, y] = toImg(e), c = $('#cvBase'), n = [x / c.width, y / c.height];
    if (V.drawing.t === 'pen') { const last = V.drawing.pts[V.drawing.pts.length - 1]; if (Math.hypot((n[0] - last[0]) * c.width, (n[1] - last[1]) * c.height) > 2.5 / V.zoom) V.drawing.pts.push(n); } else V.drawing.b = n;
    drawAnn();
  });
  const end = e => {
    if (drag) { const h = drag.hit, moved = Math.hypot(e.clientX - drag.sx, e.clientY - drag.sy); drag = null; vw.classList.remove('drag'); if (h && moved < 5 && e.type === 'pointerup') openNotePop(h, false); return; }
    if (!V.drawing) return; const d = V.drawing; V.drawing = null;
    const tiny = d.t === 'pen' ? d.pts.length < 2 : Math.hypot(d.a[0] - d.b[0], d.a[1] - d.b[1]) < .004;
    if (!tiny) { if (d.t === 'pen') d.pts = d.pts.map(p => [round4(p[0]), round4(p[1])]); curAnn().push(d); V.redo = []; setDirty(); }
    drawAnn(); if (!tiny) openNotePop(d, true);
  };
  vw.addEventListener('pointerup', end); vw.addEventListener('pointercancel', end); vw.addEventListener('pointerleave', () => { $('#tip').hidden = true; });
  new ResizeObserver(() => { if (curRoute === 'grade' && V.pages.length) fit(); }).observe(vw);
}
const round4 = v => Math.round(v * 10000) / 10000;
function placeText(e, n) {
  const vw = $('#vw'), r = vw.getBoundingClientRect();
  const inp = document.createElement('input'); inp.className = 'text-entry'; inp.placeholder = 'Ghi chú, Enter để đặt';
  inp.style.left = (e.clientX - r.left) + 'px'; inp.style.top = (e.clientY - r.top) + 'px'; inp.style.color = V.color === '#FFFFFF' ? '#111' : V.color;
  vw.appendChild(inp); setTimeout(() => inp.focus(), 0);
  const done = ok => { if (ok && inp.value.trim()) { const W = $('#cvBase').width; curAnn().push({ t: 'text', p: n, s: inp.value.trim(), c: V.color, size: 22 / W * Math.max(1, W / 1200) }); setDirty(); drawAnn(); } inp.remove(); };
  inp.onkeydown = ev => { ev.stopPropagation(); if (ev.key === 'Enter') done(true); if (ev.key === 'Escape') done(false); };
  inp.onblur = () => done(true);
}
function annChanged() { setDirty(); drawAnn(); if (rTab === 'score') rerenderKeep(); }
function undo() { const a = curAnn(); if (a.length) { (V.redo ||= []).push(a.pop()); annChanged(); } }
function redo() { if (V.redo?.length) { curAnn().push(V.redo.pop()); annChanged(); } }
function isTyping(e) { const t = e.target; return t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable); }

/* ---------- thêm file, mở bài, Claude chấm tự động ---------- */
async function addFiles(fs) {
  let added = 0;
  for (const f of fs) {
    if (f.size > 20 * 1048576) { toast(f.name + ' lớn hơn 20 MB — chưa nhận.', true); continue; }
    const rec = { id: uid('F'), name: f.name, type: f.type, size: f.size, kind: /\.(psd|psb|ai)$/i.test(f.name) ? 'source' : /sketch|phac/i.test(f.name) ? 'sketch' : G.files.some(x => x.kind === 'final') ? 'version' : 'final' };
    FILE_CACHE[rec.id] = f;
    toast('Đang mở ' + f.name + '…');
    try {
      const pr = await processFile(f);
      rec.signals = pr.signals; G.files.push(rec);
      const start = V.pages.length;
      pr.pages.forEach((p, i) => V.pages.push({ ...p, fileId: rec.id, kind: rec.kind, pageNo: i + 1 }));
      G.flagNotes = [...new Set([...(G.flagNotes || []), ...autoFlagNotes([pr.signals])])];
      if (!G.title) G.title = f.name.replace(/\.[^.]+$/, '').replace(/[_-]+/g, ' ');
      if (!G.mssv) { const m = f.name.match(/\d{6,}/); if (m) { G.mssv = m[0]; const st = klass(G.classId)?.students?.find(s => s.mssv === m[0]); if (st) G.name = st.name; } }
      pendingUploads.push(uploadAsset(rec, f));
      setDirty(); showPage(start); renderBottom(); added++;
    } catch (e) { console.warn(e); toast(f.name + ': ' + (e.message || 'không mở được file'), true); }
  }
  if (added) { rerenderKeep(); autoGrade(); }
}
async function openSub(id, tab) {
  const s = S.subs[id]; if (!s) return;
  const doOpen = async () => {
    if (!gradeEl) buildGrade();
    claudeCtl?.abort(); claudeCtl = null;
    G = JSON.parse(JSON.stringify(s)); window.G = G;
    G.ai ||= {}; G.ai.manual ||= {}; G.viva ||= { items: [] }; G.viva.items ||= []; G.ann ||= {}; G.good ||= []; G.fix ||= []; G.flags ||= []; G.files ||= [];
    const ls = lessonSetup(G.classId, G.courseId, G.lessonId);
    if (!G.criteria?.length) G.criteria = ls.criteria; G.criteria.forEach(k => { if (k.score == null && k.claude != null) k.score = k.claude; });
    G.objective ||= ls.objective; G.ai.policy ||= ls.policy;
    V.pages = []; V.cur = 0; V.cmp = null; dirty = false; rTab = tab || 'score';
    if (location.hash !== '#grade') history.replaceState(null, '', '#grade');
    route(); renderAll();
    for (const rec of G.files) {
      const f = await fileFromRec(rec);
      if (!f) continue;
      try { const pr = await processFile(f, { silent: true }); rec.signals ||= pr.signals; pr.pages.forEach((p, i) => V.pages.push({ ...p, fileId: rec.id, kind: rec.kind, pageNo: i + 1 })); if (G !== window.G) return; showPage(0); renderBottom(); }
      catch (e) { console.warn(e); }
    }
    if (G.files.length && !V.pages.length) toast('Không tải lại được file gốc của bài này — hãy thả lại file để xem.', true);
    else if (G.status === 'cho' && !G.criteria.some(k => k.claude != null)) autoGrade();
    else rerenderKeep();
  };
  if (dirty && G && G.id !== id && (gHasScores() || V.pages.length)) confirmBox('Bài của ' + (G.name || 'sinh viên hiện tại') + ' chưa lưu. Bỏ thay đổi để mở bài khác?', 'Mở bài khác', doOpen);
  else doOpen();
}
let autoWarned = false;
async function autoGrade() {
  if (!V.pages.length) return;
  if (!CAP.sample) { if (!autoWarned) { autoWarned = true; toast(window.claude ? 'Claude chưa sẵn sàng ở chế độ xem này — bạn vẫn nhập điểm thủ công được.' : 'Bản ngoại tuyến: nhập khoá API Claude ở Cài đặt chung để Claude chấm tự động. Bạn vẫn nhập điểm thủ công được.', true); } return; }
  claudeCtl?.abort();
  const ctl = claudeCtl = new AbortController(), g = G;
  renderScorebar(); paintGradeHint();
  const finals = V.pages.filter(p => p.kind === 'final'), rest = V.pages.filter(p => p.kind !== 'final');
  const pages = [...finals, ...rest];
  try {
    const ctx = { id: g.id, courseId: g.courseId, lessonId: g.lessonId, classId: g.classId, objective: g.objective, criteria: g.criteria, flags: g.flags, files: g.files, declaration: g.ai.declaration, policy: g.ai.policy, note: g.note, title: g.title };
    const res = await claudeGrade(ctx, pages, ctl.signal, ({ text }) => { const t = $('#autoTxt'); if (t) t.textContent = 'Claude đang chấm… ' + Math.min(99, Math.round(text.length / 25)) + '%'; });
    if (ctl.signal.aborted || g !== G) return;
    g.criteria.forEach((k, i) => { k.claude = res.scores[i].score; k.reason = res.scores[i].reason; if (!k.edited) k.score = k.claude; });
    g.claudeTotal = round2(sum(res.scores.map(x => x.score)));
    if (!g.goodEdited) g.good = res.good; if (!g.fixEdited) g.fix = res.fix;
    if (!g.commentEdited) g.comment = res.comment || g.comment;
    Object.assign(g.ai, { percent: res.ai.percent, level: res.ai.level, observations: res.ai.observations || [], assessment: res.ai.assessment || '', reason: res.ai.assessment || '' });
    if (g.flags.length && !g.ultEdited) g.ultimatum = res.ultimatum || buildUltimatum(g.flags, g.courseId);
    const qs = (res.ai.questions || []).map(q => ({ q: String(q), res: '', note: '' })); if (qs.length) g.viva.items = [...g.viva.items.filter(x => x.res || x.note), ...qs];
    if (g.status === 'cho') g.status = 'nhap';
    setDirty(); toast('Claude đã chấm xong: ' + fmt(g.claudeTotal) + ' điểm — kiểm tra và sửa nếu cần');
  } catch (e) { if (e.code !== 'cancelled' && !ctl.signal.aborted) toast(claudeErr(e), true); }
  finally { if (claudeCtl === ctl) claudeCtl = null; }
  if (!ctl.signal.aborted && g === G) { renderRTabs(); rerenderKeep(); renderScorebar(); }
}

/* ---------- lưu, chấm tiếp ---------- */
async function saveG(status) {
  const missing = G.criteria.findIndex(k => k.score == null);
  if (!G.mssv && !G.name) { toast('Nhập mã hoặc tên sinh viên trước khi lưu.', true); rTab = 'score'; renderRight(); $('#gMssv')?.focus(); return; }
  if (status === 'duyet' && missing >= 0) { toast('Còn tiêu chí chưa có điểm: “' + G.criteria[missing].name + '”.', true); rTab = 'score'; renderRight(); $$('#critRows [data-f=score]')[missing]?.focus(); return; }
  if (G.criteria.some(k => k.score != null && (k.score > k.max || k.score < 0))) { toast('Có điểm vượt mức tối đa của tiêu chí — kiểm tra ô viền đỏ.', true); return; }
  const btn = $('#saveBtn'); if (btn) btn.disabled = true;
  try {
    await Promise.allSettled(pendingUploads); pendingUploads = [];
    const id = G.id || uid('S'); const p = V.pages.find(x => x.kind === 'final') || V.pages[0];
    const doc = JSON.parse(JSON.stringify({ ...G, id, className: klass(G.classId)?.name || G.classId, total: gTotal(), status, createdAt: G.createdAt || Date.now(), thumb: p ? canvasThumb(p.canvas, 200) : (G.thumb || '') }));
    doc.files = doc.files.map(f => { if (f.signals?.psd?.tree && f.signals.psd.tree.length > 6000) f.signals.psd.tree = f.signals.psd.tree.slice(0, 6000) + '\n…'; return f; });
    const prev = S.subs[id];
    await Store.put('subs', id, doc);
    const ev = gradeDiff(prev, doc); if (ev) logHistory(ev);
    G.id = id; G.status = status; G.createdAt = doc.createdAt; dirty = false;
    toast(status === 'duyet' ? `Đã duyệt ${fmt(doc.total)} điểm cho ${G.name || G.mssv}` : 'Đã lưu nháp'); renderRight(); renderBottom();
  } catch (e) { toast('Chưa lưu được: ' + (e.code === 'too_big' ? 'bản ghi quá lớn — hãy bớt nét vẽ tự do.' : (e.message || e.code)), true); }
  if (btn) btn.disabled = false;
}
function nextG() {
  const go2 = () => {
    G = blankG({ classId: G.classId, courseId: G.courseId, lessonId: G.lessonId, objective: G.objective, criteria: G.criteria }); window.G = G;
    V.pages = []; V.cur = 0; V.cmp = null; V.pick = []; dirty = false; rTab = 'score'; bTab = 'list';
    if (curRoute !== 'grade') go('grade');
    renderAll(); toast(G.name ? 'Bài tiếp theo: ' + G.name : 'Sẵn sàng chấm bài tiếp theo');
    setTimeout(() => (G.mssv ? $('#addFile') : $('#gMssv'))?.focus(), 50);
  };
  if (!G) { go('grade'); return; }
  if (dirty && (gHasScores() || V.pages.length)) confirmBox('Bài của ' + (G.name || 'sinh viên hiện tại') + ' chưa được lưu. Bỏ qua và chấm bài tiếp theo?', 'Chấm bài tiếp theo', go2);
  else go2();
}
$('#btnNextHdr').onclick = nextG;
document.addEventListener('keydown', e => {
  if (curRoute !== 'grade' || $('#modalRoot').firstChild) return;
  const mod = e.ctrlKey || e.metaKey;
  if (mod && (e.key === 's' || e.key === 'S')) { e.preventDefault(); saveG('duyet'); return; }
  if (e.altKey && (e.key === 'n' || e.key === 'N' || e.code === 'KeyN')) { e.preventDefault(); nextG(); return; }
  if (isTyping(e)) return;
  if (mod && (e.key === 'z' || e.key === 'Z')) { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
  if (mod) return;
  const k = e.key.toLowerCase(), map = { v: 'pan', b: 'pen', a: 'arrow', r: 'rect', e: 'ellipse', t: 'text', c: 'pick' };
  if (map[k]) { setTool(map[k]); return; }
  if (k === 'g') { $('#gridBtn').click(); return; }
  if (k === '+' || k === '=') zoomAt(1.25); else if (k === '-') zoomAt(.8); else if (k === '0') fit();
  else if (k === 'arrowright' || k === 'pagedown') showPage(V.cur + 1); else if (k === 'arrowleft' || k === 'pageup') showPage(V.cur - 1);
});

/* ---------- copy & tải nhận xét về máy ---------- */
const lines = a => (a || []).map(x => String(x).trim()).filter(Boolean);
function commentText() {
  const c = course(G.courseId), l = lesson(G.courseId, G.lessonId);
  const L = [`NHẬN XÉT BÀI THỰC HÀNH — ${c.name}`, `Bài ${l.no}: ${l.name}${G.title ? ' — ' + G.title : ''}`, `Sinh viên: ${G.name || ''} · MSSV: ${G.mssv || ''} · Lớp: ${klass(G.classId)?.name || G.classId}`, '', G.objective, ''];
  G.criteria.forEach((k, i) => L.push(`${i + 1}. ${k.name}: ${fmt(k.score)}/${fmt(k.max)}`));
  L.push(`TỔNG ĐIỂM: ${fmt(gTotal())}/${fmt(gMax(), 1)}`, '');
  if (lines(G.good).length) L.push('Tốt:', ...lines(G.good).map(x => '- ' + x), '');
  if (lines(G.fix).length) L.push('Khắc phục:', ...lines(G.fix).map(x => '- ' + x), '');
  const notes = allNotes().filter(o => o.s.note); if (notes.length) L.push('Ghi chú lỗi trên bài:', ...notes.map(o => `(${o.n}) ${o.s.note}`), '');
  if (G.comment) L.push(G.comment);
  if (G.ultimatum) L.push('', G.ultimatum);
  return L.join('\n');
}
async function copyComment() {
  const t = commentText();
  try { await navigator.clipboard.writeText(t); toast('Đã sao chép vào bộ nhớ tạm'); }
  catch { modal(`<h2>Sao chép nhận xét</h2><textarea class="inp" id="cpT" rows="14">${esc(t)}</textarea><div class="modal-f"><button class="btn pri" data-close>Xong</button></div>`, m => { const ta = $('#cpT', m); ta.focus(); ta.select(); }); toast('Trình duyệt chặn sao chép tự động — văn bản đã được bôi đen, nhấn Ctrl+C.'); }
}
function annotatedCanvas(p, nums) {
  const c = document.createElement('canvas'); c.width = p.canvas.width; c.height = p.canvas.height; const x = c.getContext('2d'); x.drawImage(p.canvas, 0, 0);
  drawAnnTo(x, annKey(p), c.width, c.height, nums || noteNums()); return c;
}
const ascii = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').replace(/[^A-Za-z0-9]+/g, '');
function fileBase() { const l = lesson(G.courseId, G.lessonId); return ['NhanXet', ascii(G.mssv), ascii(G.name), 'Bai' + l.no].filter(Boolean).join('_'); }
function exportPages() { const withNotes = V.pages.filter(p => (G.ann[annKey(p)] || []).some(s => s.t !== 'text')); return withNotes.length ? withNotes : [V.pages.find(x => x.kind === 'final') || V.pages[0]].filter(Boolean); }
function downloadMenu() {
  if (!CAP.downloads && window.claude) { toast('Chế độ xem này chưa cho phép tải file về máy.', true); return; }
  modal(`<h2>Tải nhận xét về máy</h2><p class="muted" style="margin:0">Chọn định dạng để gửi cho sinh viên <b>${esc(G.name || G.mssv || '')}</b>.</p>
    <button class="dl-opt" id="dlHtml">${icon('down')}<div><b>Trang web (.html) — có ghi chú khi di chuột</b><span class="muted" style="font-size:.82rem">Sinh viên mở bằng trình duyệt, chỉ chuột vào vùng khoanh trên ảnh để đọc ghi chú lỗi. Kèm điểm từng tiêu chí và nhận xét.</span></div></button>
    <button class="dl-opt" id="dlDocx">${icon('down')}<div><b>Word (.docx) — phiếu nhận xét để in/lưu</b><span class="muted" style="font-size:.82rem">Ảnh bài có đánh số lỗi, danh sách ghi chú, bảng điểm, nhận xét Tốt / Khắc phục.</span></div></button>
    <div class="modal-f"><button class="btn" data-close>Đóng</button></div>`, (m, close) => {
    $('#dlHtml', m).onclick = () => { close(); downloadHtml(); };
    $('#dlDocx', m).onclick = () => { close(); downloadDocx(); };
  });
}
async function downloadHtml() {
  try {
    const c = course(G.courseId), l = lesson(G.courseId, G.lessonId), nums = noteNums(), notes = allNotes();
    let figs = '';
    for (const p of exportPages()) {
      const ac = fitCanvas(annotatedCanvas(p, nums), p.canvas.width, p.canvas.height, 1800), url = ac.toDataURL('image/jpeg', .86);
      const spots = (G.ann[annKey(p)] || []).filter(s => s.t !== 'text').map(s => {
        const [x0, y0, x1, y1] = bboxOf(s), pad = .008, n = nums.get(s), [ax, ay] = anchorOf(s);
        const area = `<span class="area" tabindex="0" style="left:${((x0 - pad) * 100).toFixed(2)}%;top:${((y0 - pad) * 100).toFixed(2)}%;width:${((x1 - x0 + 2 * pad) * 100).toFixed(2)}%;height:${((y1 - y0 + 2 * pad) * 100).toFixed(2)}%"><span class="tipx"><b>Lỗi ${n}</b> ${esc(s.note || '')}</span></span>`;
        const dot = `<span class="dot" tabindex="0" style="left:${(ax * 100).toFixed(2)}%;top:${(ay * 100).toFixed(2)}%"><span class="tipx"><b>Lỗi ${n}</b> ${esc(s.note || '')}</span></span>`;
        return area + dot;
      }).join('');
      figs += `<figure><div class="ann"><img src="${url}" alt="${esc(p.label)}">${spots}</div><figcaption>${esc(p.label)}</figcaption></figure>`;
    }
    const li = a => lines(a).map(x => `<li>${esc(x)}</li>`).join('');
    const html = `<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Nhận xét – ${esc(G.name || G.mssv)} – Bài ${l.no}</title>
<style>:root{--fg:#1A1D19;--mut:#5A6056;--line:#D5D8CF;--acc:#2C43C4;--ok:#1D7A4B;--bad:#BE2F27;--bg:#F2F3EF}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:15px/1.55 "Be Vietnam Pro","Segoe UI",system-ui,sans-serif}main{max-width:980px;margin:0 auto;padding:24px 16px 48px}header{border-bottom:2px solid var(--fg);padding-bottom:12px;margin-bottom:16px}header small{color:var(--mut);letter-spacing:.06em;text-transform:uppercase;font-size:.72rem}h1{margin:4px 0;font-size:1.6rem}h2{font-size:1.1rem;margin:24px 0 8px}section{background:#fff;border:1px solid var(--line);border-radius:10px;padding:16px;margin-top:14px}table{width:100%;border-collapse:collapse;font-size:.92rem}td,th{border-bottom:1px solid var(--line);padding:8px;text-align:left;vertical-align:top}th{background:#EEF0F6;font-size:.76rem;text-transform:uppercase;letter-spacing:.05em}td.n{text-align:center;font-variant-numeric:tabular-nums;white-space:nowrap}.tot td{font-weight:700;background:#DDF0E4}.info td:first-child{color:var(--mut);width:30%}.hint{color:var(--mut);font-size:.88rem;margin:0 0 10px}figure{margin:0 0 16px}.ann{position:relative;display:inline-block;max-width:100%;line-height:0}.ann img{max-width:100%;height:auto;border-radius:6px;display:block}.area{position:absolute;border-radius:6px;cursor:help;outline:none}.area:hover,.area:focus{background:rgba(224,53,43,.10);box-shadow:0 0 0 2px rgba(224,53,43,.7)}.dot{position:absolute;width:30px;height:30px;margin:-15px 0 0 -15px;border-radius:50%;cursor:help}.tipx{display:none;position:absolute;left:0;top:calc(100% + 6px);z-index:5;width:max-content;max-width:300px;background:#1A1D19;color:#fff;padding:8px 10px;border-radius:8px;font-size:.86rem;line-height:1.45;box-shadow:0 6px 20px rgba(0,0,0,.25)}.tipx b{color:#FFB4AC;margin-right:4px}.area:hover .tipx,.area:focus .tipx,.dot:hover .tipx,.dot:focus .tipx{display:block}figcaption{font-size:.8rem;color:var(--mut);margin-top:6px;line-height:1.4}ul{margin:4px 0 0;padding-left:20px}.ok{color:var(--ok)}.bad{color:var(--bad)}.ult{border-left:4px solid var(--bad);background:#F9E0DD;padding:12px 14px;border-radius:0 8px 8px 0;white-space:pre-wrap}ol.notes{padding-left:22px}.sig{margin-top:28px;text-align:right;color:var(--mut)}</style></head><body><main>
<header><small>${esc(S.settings.unit)}</small><h1>Phiếu nhận xét bài thực hành</h1><div>${esc(c.name)} · Bài ${l.no}: ${esc(l.name)}</div></header>
<section><table class="info"><tr><td>Sinh viên</td><td><b>${esc(G.name)}</b></td></tr><tr><td>MSSV</td><td>${esc(G.mssv)}</td></tr><tr><td>Lớp</td><td>${esc(klass(G.classId)?.name || G.classId)}</td></tr><tr><td>Tên bài nộp</td><td>${esc(G.title)}</td></tr><tr><td>Giảng viên</td><td>${esc(S.settings.teacher)}</td></tr><tr><td>Ngày chấm</td><td>${fmtDate(Date.now())}</td></tr><tr><td>Tổng điểm</td><td><b style="font-size:1.3rem">${fmt(gTotal())} / ${fmt(gMax(), 1)}</b></td></tr></table></section>
${figs ? `<section><h2 style="margin-top:0">Bài làm và ghi chú của giảng viên</h2><p class="hint">Di chuột (hoặc chạm) vào vùng được khoanh hay các số trên ảnh để đọc ghi chú lỗi.</p>${figs}${notes.some(o => o.s.note) ? `<ol class="notes">${notes.filter(o => o.s.note).map(o => `<li value="${o.n}">${esc(o.s.note)}</li>`).join('')}</ol>` : ''}</section>` : ''}
<section><h2 style="margin-top:0">Điểm theo tiêu chí</h2><p class="hint">${esc(G.objective)}</p><table><tr><th>#</th><th>Tiêu chí</th><th>Tối đa</th><th>Điểm</th></tr>${G.criteria.map((k, i) => `<tr><td class="n">${i + 1}</td><td>${esc(k.name)}</td><td class="n">${fmt(k.max)}</td><td class="n"><b>${fmt(k.score)}</b></td></tr>`).join('')}<tr class="tot"><td></td><td>Tổng điểm</td><td class="n">${fmt(gMax(), 1)}</td><td class="n">${fmt(gTotal())}</td></tr></table></section>
<section><h2 style="margin-top:0">Nhận xét chung</h2>${lines(G.good).length ? `<b class="ok">Tốt</b><ul>${li(G.good)}</ul>` : ''}${lines(G.fix).length ? `<p style="margin:12px 0 0"><b class="bad">Khắc phục</b></p><ul>${li(G.fix)}</ul>` : ''}${G.comment ? `<p style="white-space:pre-wrap">${esc(G.comment)}</p>` : ''}${G.ultimatum ? `<h2>Lưu ý về tính xác thực</h2><div class="ult">${esc(G.ultimatum)}</div>` : ''}</section>
<p class="sig">Giảng viên: <b>${esc(S.settings.teacher)}</b></p></main></body></html>`;
    await saveFile(fileBase() + '.html', html);
  } catch (e) { console.error(e); toast('Không tạo được file .html: ' + (e.message || e), true); }
}
async function downloadDocx() {
  const btn = $('#dlBtn'); if (btn) btn.disabled = true;
  try {
    await loadScript(LIB.docx);
    const D = window.docx; const c = course(G.courseId), l = lesson(G.courseId, G.lessonId), nums = noteNums(), notes = allNotes();
    const P = (t, o = {}) => new D.Paragraph({ spacing: { after: 100 }, ...o, children: [new D.TextRun({ text: t, ...(o.run || {}) })] });
    const H = t => new D.Paragraph({ spacing: { before: 240, after: 100 }, children: [new D.TextRun({ text: t, bold: true, size: 26, color: '22349A' })] });
    const cell = (t, o = {}) => new D.TableCell({ width: o.w ? { size: o.w, type: D.WidthType.PERCENTAGE } : undefined, shading: o.fill ? { fill: o.fill, type: D.ShadingType.CLEAR, color: 'auto' } : undefined, margins: { top: 60, bottom: 60, left: 100, right: 100 }, children: [new D.Paragraph({ alignment: o.center ? D.AlignmentType.CENTER : undefined, children: [new D.TextRun({ text: String(t ?? ''), bold: !!o.bold, size: 21 })] })] });
    const bullet = (t, color) => new D.Paragraph({ spacing: { after: 60 }, indent: { left: 360, hanging: 240 }, children: [new D.TextRun({ text: '– ', bold: true, color }), new D.TextRun(t)] });
    const kids = [];
    kids.push(P(S.settings.unit.toUpperCase(), { alignment: D.AlignmentType.CENTER, run: { size: 20, color: '555555' } }));
    kids.push(new D.Paragraph({ alignment: D.AlignmentType.CENTER, spacing: { before: 120, after: 200 }, children: [new D.TextRun({ text: 'PHIẾU NHẬN XÉT BÀI THỰC HÀNH', bold: true, size: 34 })] }));
    const info = [['Sinh viên', G.name], ['MSSV', G.mssv], ['Lớp', klass(G.classId)?.name || G.classId], ['Môn học', c.name], ['Bài học', 'Bài ' + l.no + ': ' + l.name], ['Tên bài nộp', G.title], ['Giảng viên', S.settings.teacher], ['Ngày chấm', fmtDate(Date.now())]];
    kids.push(new D.Table({ width: { size: 100, type: D.WidthType.PERCENTAGE }, rows: info.map(([a, b]) => new D.TableRow({ children: [cell(a, { bold: true, w: 28, fill: 'EEF0F6' }), cell(b, { w: 72 })] })) }));
    const pgs = exportPages();
    if (pgs.length) kids.push(H('Bài làm và ghi chú lỗi của giảng viên'));
    for (const pg of pgs) {
      const ac = fitCanvas(annotatedCanvas(pg, nums), pg.canvas.width, pg.canvas.height, 1400); const blob = await new Promise(r => ac.toBlob(r, 'image/jpeg', .85));
      const w = 560, h = Math.round(w * ac.height / ac.width);
      kids.push(new D.Paragraph({ alignment: D.AlignmentType.CENTER, children: [new D.ImageRun({ data: await blob.arrayBuffer(), transformation: { width: Math.round(w * Math.min(1, 760 / h)), height: Math.min(h, 760) } })] }));
    }
    const nn = notes.filter(o => o.s.note);
    nn.forEach(o => kids.push(new D.Paragraph({ spacing: { after: 60 }, children: [new D.TextRun({ text: `(${o.n}) `, bold: true, color: 'BE2F27' }), new D.TextRun(o.s.note)] })));
    kids.push(H('Mục tiêu')); kids.push(P(G.objective));
    kids.push(H('Điểm theo tiêu chí'));
    const rows = [new D.TableRow({ tableHeader: true, children: [cell('#', { bold: true, fill: 'E2E6FA', center: true, w: 6 }), cell('Tiêu chí', { bold: true, fill: 'E2E6FA', w: 64 }), cell('Tối đa', { bold: true, fill: 'E2E6FA', center: true, w: 15 }), cell('Điểm', { bold: true, fill: 'E2E6FA', center: true, w: 15 })] })];
    G.criteria.forEach((k, i) => rows.push(new D.TableRow({ children: [cell(i + 1, { center: true }), cell(k.name), cell(fmt(k.max), { center: true }), cell(fmt(k.score), { center: true, bold: true })] })));
    rows.push(new D.TableRow({ children: [cell(''), cell('TỔNG ĐIỂM', { bold: true }), cell(fmt(gMax(), 1), { center: true }), cell(fmt(gTotal()), { center: true, bold: true, fill: 'DDF0E4' })] }));
    kids.push(new D.Table({ width: { size: 100, type: D.WidthType.PERCENTAGE }, rows }));
    kids.push(H('Nhận xét chung'));
    if (lines(G.good).length) { kids.push(new D.Paragraph({ spacing: { after: 60 }, children: [new D.TextRun({ text: 'Tốt', bold: true, color: '1D7A4B' })] })); lines(G.good).forEach(t => kids.push(bullet(t, '1D7A4B'))); }
    if (lines(G.fix).length) { kids.push(new D.Paragraph({ spacing: { before: 120, after: 60 }, children: [new D.TextRun({ text: 'Khắc phục', bold: true, color: 'BE2F27' })] })); lines(G.fix).forEach(t => kids.push(bullet(t, 'BE2F27'))); }
    if (G.comment) G.comment.split('\n').filter(Boolean).forEach(t => kids.push(P(t, { spacing: { before: 120, after: 80 } })));
    if (G.ultimatum) { kids.push(H('Lưu ý về tính xác thực')); kids.push(new D.Paragraph({ shading: { fill: 'F9E0DD', type: D.ShadingType.CLEAR, color: 'auto' }, border: { left: { style: D.BorderStyle.SINGLE, size: 18, color: 'BE2F27' } }, spacing: { after: 160 }, children: [new D.TextRun({ text: G.ultimatum })] })); }
    kids.push(new D.Paragraph({ alignment: D.AlignmentType.RIGHT, spacing: { before: 400 }, children: [new D.TextRun({ text: 'Giảng viên', bold: true })] }));
    kids.push(new D.Paragraph({ alignment: D.AlignmentType.RIGHT, spacing: { before: 600 }, children: [new D.TextRun(S.settings.teacher)] }));
    const doc = new D.Document({ styles: { default: { document: { run: { font: 'Times New Roman', size: 24 } } } }, sections: [{ properties: { page: { margin: { top: 1000, bottom: 1000, left: 1100, right: 1000 } } }, children: kids }] });
    await saveFile(fileBase() + '.docx', await D.Packer.toBlob(doc));
  } catch (e) { console.error(e); toast('Không tạo được file .docx: ' + (e.message || e), true); }
  if (btn) btn.disabled = false;
}

function gradeDiff(prev, doc) {
  const l = lesson(doc.courseId, doc.lessonId), who = (doc.name || doc.mssv || 'sinh viên') + (doc.mssv && doc.name ? ' (' + doc.mssv + ')' : '');
  const ch = [];
  if (!prev) ch.push(['Tổng điểm', '', fmt(doc.total)]);
  else {
    if (prev.total !== doc.total) ch.push(['Tổng điểm', fmt(prev.total ?? subTotal(prev)), fmt(doc.total)]);
    doc.criteria.forEach((k, i) => { const o = prev.criteria?.[i]?.score; if (o != null && o !== k.score) ch.push(['TC' + (i + 1), fmt(o), fmt(k.score)]); });
    if (prev.status !== doc.status) ch.push(['Trạng thái', STATUS[prev.status]?.[0] || '', STATUS[doc.status]?.[0] || '']);
    if (JSON.stringify(prev.good) !== JSON.stringify(doc.good) || JSON.stringify(prev.fix) !== JSON.stringify(doc.fix) || prev.comment !== doc.comment) ch.push(['Nhận xét', '', 'đã sửa']);
    if (JSON.stringify(prev.flags || []) !== JSON.stringify(doc.flags || [])) ch.push(['Cờ nghi vấn AI', String((prev.flags || []).length), String((doc.flags || []).length)]);
    const nn = o => Object.values(o.ann || {}).flat().filter(s => s.t !== 'text').length; if (nn(prev) !== nn(doc)) ch.push(['Ghi chú lỗi', String(nn(prev)), String(nn(doc))]);
  }
  if (prev && !ch.length) return null;
  return { type: 'grade', title: (prev ? 'Sửa điểm ' : 'Duyệt điểm ') + who + ' — Bài ' + l.no, subId: doc.id, changes: ch };
}
