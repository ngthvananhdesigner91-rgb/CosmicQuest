$$('#nav a').forEach(a => a.title = ($('.lb', a)?.textContent || '').trim());
$('#ftrHelp').onclick = e => { e.preventDefault(); $('#btnHelp').click(); };
$('#ftrArt').innerHTML = blockArt('foot');
initCaps(); route();
