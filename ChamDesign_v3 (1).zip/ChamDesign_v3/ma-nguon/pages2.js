/* ===== Cài đặt chung ===== */
const themeGet = () => { try { return localStorage.getItem('cd.theme') || ''; } catch { return ''; } };
function applyTheme(t) { if (t) document.documentElement.dataset.theme = t; else delete document.documentElement.dataset.theme; try { t ? localStorage.setItem('cd.theme', t) : localStorage.removeItem('cd.theme'); } catch { } }
applyTheme(themeGet());
ROUTES.settings = (v, refresh) => {
  if (refresh && v.querySelector('[data-dirty]')) return;
  const st = S.settings, th = themeGet();
  v.innerHTML = `<div class="page" data-editing>
    <div class="page-head"><button class="btn pri" id="stSave">${icon('save')}Lưu cài đặt</button></div>
    <div class="set-grid">
      <section class="card"><div class="card-h"><h2>Giảng viên &amp; đơn vị</h2></div><div style="display:grid;gap:12px">
        <label class="field"><span>Tên giảng viên (hiện trên phiếu nhận xét)</span><input class="inp" id="sT" value="${esc(st.teacher)}"></label>
        <label class="field"><span>Đơn vị (khoa, trường)</span><input class="inp" id="sU" value="${esc(st.unit)}"></label></div></section>
      <section class="card"><div class="card-h"><h2>Claude chấm bài</h2></div><div style="display:grid;gap:12px">
        <label class="field"><span>Mức Claude khi chấm</span><select class="inp" id="sM">${[['quick', 'Nhanh — trả kết quả trong vài giây'], ['default', 'Cân bằng — khuyên dùng'], ['complex', 'Kỹ nhất — chậm hơn, nhận xét sâu hơn']].map(([k, t]) => `<option value="${k}" ${st.tier === k ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
        <p class="muted" style="margin:0;font-size:.84rem">Claude chấm tự động ngay khi bạn thả bài vào màn hình Chấm bài, dựa đúng các tiêu chí trong Thư viện rubric. Mỗi lần chấm dùng lượt Claude của tài khoản đang mở trang.</p></div></section>
      <section class="card" style="grid-column:1/-1"><div class="card-h"><h2>Mẫu “tối hậu thư”</h2></div>
        <label class="field"><span>Dùng khi Claude chưa sẵn sàng — {flags}: các dấu hiệu đã tick, {proof}: thao tác sinh viên phải chứng minh</span><textarea class="inp" id="sX" rows="5">${esc(st.ultimatum)}</textarea></label></section>
      ${window.claude ? '' : `<section class="card" style="grid-column:1/-1"><div class="card-h"><h2>Claude cho bản ngoại tuyến</h2><span class="chip ${apiKeyGet() && apiModelGet() ? 'ok' : 'warn'}">${apiKeyGet() && apiModelGet() ? 'Đã bật chấm tự động' : 'Chưa bật'}</span></div>
        <p class="muted" style="margin:0 0 12px;font-size:.86rem;max-width:90ch">Bạn đang mở file Chấm.Design trực tiếp trên trình duyệt (Cốc Cốc, Chrome, Edge…), không qua link Claude. Để Claude chấm tự động ở đây, nhập <b>khoá API Claude</b> (tạo tại console.anthropic.com → API Keys; tính phí theo lượt dùng, tách riêng với gói Claude Pro). Khoá chỉ lưu trong trình duyệt của máy này, không gửi đi đâu ngoài máy chủ Claude — đừng dùng trên máy công cộng.</p>
        <div class="grid3"><label class="field" style="grid-column:span 2"><span>Khoá API (bắt đầu bằng sk-ant-)</span><input class="inp mono" id="apiK" type="password" autocomplete="off" value="${esc(apiKeyGet())}" placeholder="sk-ant-…"></label>
        <label class="field"><span>Mô hình</span><select class="inp" id="apiM">${apiModelGet() ? `<option value="${esc(apiModelGet())}">${esc(apiModelGet())}</option>` : '<option value="">Bấm “Kiểm tra khoá” để tải danh sách</option>'}</select></label></div>
        <div class="row" style="margin-top:12px"><button class="btn pri" id="apiTest">Kiểm tra khoá &amp; lưu</button>${apiKeyGet() ? '<button class="btn danger" id="apiDel">Xoá khoá khỏi máy này</button>' : ''}<span id="apiMsg" class="muted" style="font-size:.84rem"></span></div></section>`}
      <section class="card"><div class="card-h"><h2>Giao diện</h2></div>
        <div class="seg" role="group" aria-label="Chế độ màu">${[['', 'Theo máy'], ['light', 'Sáng'], ['dark', 'Tối']].map(([k, t]) => `<button type="button" data-th="${k}" aria-pressed="${th === k}">${t}</button>`).join('')}</div>
        <p class="muted" style="margin:10px 0 0;font-size:.84rem">Áp dụng ngay, chỉ trên trình duyệt này.</p></section>
      <section class="card"><div class="card-h"><h2>Dữ liệu</h2></div><div class="row">
        <button class="btn sm" id="sExp">${icon('down')}Xuất thư viện rubric (JSON)</button>
        <label class="btn sm">${icon('upload')}Nhập thư viện<input type="file" id="sImp" accept=".json" hidden></label>
        <button class="btn sm" id="sBak">${icon('down')}Sao lưu toàn bộ điểm (JSON)</button></div>
        <p class="muted" style="margin:10px 0 0;font-size:.84rem">Lưu trữ: ${S.mode === 'db' ? 'kho dữ liệu dùng chung của trang — mọi thiết bị của bạn thấy cùng dữ liệu.' : 'trình duyệt này. Hãy sao lưu định kỳ.'}</p></section>
    </div></div>`;
  const mark = () => v.querySelector('.page').setAttribute('data-dirty', '1');
  $$('input,textarea,select', v).forEach(i => i.addEventListener('input', mark));
  $$('[data-th]', v).forEach(b => b.onclick = () => { applyTheme(b.dataset.th); $$('[data-th]', v).forEach(x => x.setAttribute('aria-pressed', x === b)); });
  $('#stSave', v).onclick = async () => {
    const nv = { teacher: $('#sT').value.trim() || st.teacher, unit: $('#sU').value.trim(), tier: $('#sM').value, ultimatum: $('#sX').value };
    const L = { teacher: 'Tên giảng viên', unit: 'Đơn vị', tier: 'Mức Claude', ultimatum: 'Mẫu tối hậu thư' };
    const ch = Object.keys(nv).filter(k => nv[k] !== st[k]).map(k => [L[k], k === 'ultimatum' ? '…' : st[k], k === 'ultimatum' ? 'đã sửa' : nv[k]]);
    await Store.put('settings', 'app', nv); if (ch.length) logHistory({ type: 'settings', title: 'Sửa cài đặt chung', changes: ch });
    toast('Đã lưu cài đặt'); v.querySelector('.page').removeAttribute('data-dirty'); ROUTES.settings(v);
  };
  const at = $('#apiTest', v); if (at) at.onclick = async () => {
    const key = $('#apiK').value.trim(), msg = $('#apiMsg'); if (!key) { msg.textContent = 'Nhập khoá API trước.'; return; }
    at.disabled = true; msg.textContent = 'Đang kiểm tra…';
    try {
      const ms = await apiListModels(key); const sel = $('#apiM'), cur = sel.value || apiModelGet();
      const vision = ms.filter(m => /claude/i.test(m.id));
      const pick = cur && vision.some(m => m.id === cur) ? cur : (vision.find(m => /sonnet/i.test(m.id)) || vision[0])?.id || '';
      sel.innerHTML = vision.map(m => `<option value="${esc(m.id)}" ${m.id === pick ? 'selected' : ''}>${esc(m.name)}</option>`).join('');
      try { localStorage.setItem('cd.apiKey', key); localStorage.setItem('cd.model', sel.value); } catch { msg.textContent = 'Trình duyệt chặn lưu khoá.'; at.disabled = false; return; }
      CAP.sample = makeApiSample(); msg.textContent = 'Khoá hợp lệ — đã bật chấm tự động với ' + sel.options[sel.selectedIndex]?.text + '.'; toast('Đã bật Claude cho bản ngoại tuyến');
      sel.onchange = () => { try { localStorage.setItem('cd.model', sel.value); } catch { } };
    } catch (e) { msg.textContent = e.code === 'bad_key' ? 'Khoá không hợp lệ.' : 'Không kết nối được tới Claude (' + (e.message || '').slice(0, 80) + ').'; }
    at.disabled = false;
  };
  const ad = $('#apiDel', v); if (ad) ad.onclick = () => { try { localStorage.removeItem('cd.apiKey'); localStorage.removeItem('cd.model'); } catch { } CAP.sample = null; toast('Đã xoá khoá API khỏi máy này'); ROUTES.settings(v); };
  const am = $('#apiM', v); if (am) am.onchange = () => { try { localStorage.setItem('cd.model', am.value); } catch { } };
  $('#sExp', v).onclick = () => saveFile('ThuVienRubric_ChamDesign.json', JSON.stringify({ courses: courses(), classes: classes() }, null, 2));
  $('#sBak', v).onclick = () => saveFile('SaoLuu_ChamDesign_' + new Date().toISOString().slice(0, 10) + '.json', JSON.stringify({ exportedAt: new Date().toISOString(), classes: classes(), subs: Object.values(S.subs).map(s => ({ ...s, thumb: undefined })) }, null, 1));
  $('#sImp', v).onchange = async e => { try { const j = JSON.parse(await e.target.files[0].text()); for (const c of j.courses || []) await Store.put('courses', c.id, c); for (const k of j.classes || []) await Store.put('classes', k.id, k); logHistory({ type: 'rubric', title: 'Nhập thư viện rubric từ file ' + e.target.files[0].name }); toast('Đã nhập thư viện'); } catch { toast('File JSON không hợp lệ.', true); } };
};

/* ===== Lịch sử sửa ===== */
const HTYPE = { grade: ['Chấm & duyệt điểm', 'var(--mg)'], claude: ['Claude chấm nháp', 'var(--claude)'], rubric: ['Thư viện rubric', 'var(--cy)'], class: ['Lớp & sinh viên', 'var(--ok)'], settings: ['Cài đặt', 'var(--yl)'], sync: ['Đồng bộ điểm', 'var(--accent)'], login: ['Đăng nhập', 'var(--ink-2)'], pin: ['Mã PIN', 'var(--ink-2)'] };
const HF = { type: '', q: '' };
ROUTES.history = (v, refresh) => {
  if (refresh && document.activeElement?.id === 'hQ') return;
  let list = Object.values(S.history).sort((a, b) => b.at - a.at);
  if (HF.type) list = list.filter(h => h.type === HF.type);
  if (HF.q) { const q = HF.q.toLowerCase(); list = list.filter(h => (h.title + ' ' + (h.changes || []).flat().join(' ')).toLowerCase().includes(q)); }
  const groups = {}; list.slice(0, 300).forEach(h => (groups[new Date(h.at).toDateString()] ||= []).push(h));
  const ids = list.map(h => h.by);
  v.innerHTML = `<div class="page">
    <div class="row"><label class="field"><span>Loại thay đổi</span><select class="inp" id="hT"><option value="">Tất cả</option>${Object.entries(HTYPE).map(([k, [t]]) => `<option value="${k}" ${HF.type === k ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
    <label class="field" style="flex:1;min-width:220px"><span>Tìm theo sinh viên, MSSV, bài…</span><input class="inp" id="hQ" value="${esc(HF.q)}" placeholder="VD: 2251010001"></label></div>
    ${list.length ? Object.entries(groups).map(([d, evs]) => `<section class="card"><div class="card-h"><h2>${new Date(evs[0].at).toLocaleDateString('vi-VN', { weekday: 'long', day: '2-digit', month: '2-digit', year: 'numeric' })}</h2><span class="chip">${evs.length} thay đổi</span></div>
      <div class="tl">${evs.map(h => { const [tn, col] = HTYPE[h.type] || ['Khác', 'var(--faint)']; return `<div class="ev"${h.subId && S.subs[h.subId] ? ` style="cursor:pointer" data-sub="${h.subId}"` : ''}><time>${new Date(h.at).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}</time><span class="dotc" style="--c:${col}"></span>
        <div class="what"><div><b>${esc(h.title)}</b></div><div class="faint" style="font-size:.76rem">${tn} · <span data-who="${esc(h.by || '')}">${esc(whoName(h.by))}</span></div>
        ${(h.changes || []).length ? `<div class="diff">${h.changes.map(([k, a, b]) => `${esc(k)}: ${a !== '' && a != null ? `<s>${esc(a)}</s> → ` : ''}<ins>${esc(b)}</ins>`).join(' · ')}</div>` : ''}</div></div>`; }).join('')}</div></section>`).join('')
      : `<div class="empty card"><b>Chưa có thay đổi nào</b>Mỗi lần lưu điểm, sửa rubric, đổi cài đặt, đồng bộ điểm hay đăng nhập sẽ được ghi lại ở đây.</div>`}
  </div>`;
  $('#hT').onchange = e => { HF.type = e.target.value; ROUTES.history(v); };
  let tmo; $('#hQ').oninput = e => { clearTimeout(tmo); tmo = setTimeout(() => { HF.q = e.target.value; ROUTES.history(v); const q = $('#hQ'); q.focus(); q.setSelectionRange(q.value.length, q.value.length); }, 250); };
  $$('[data-sub]', v).forEach(x => x.onclick = () => openSub(x.dataset.sub));
  resolveNames(ids).then(() => $$('[data-who]', v).forEach(s => s.textContent = whoName(s.dataset.who)));
};

/* ===== Đăng nhập & Tài khoản ===== */
ROUTES.account = (v, refresh) => {
  if (refresh && v.querySelector('input:focus')) return;
  const has = !!S.settings.pinHash, logins = Object.values(S.history).filter(h => h.type === 'login' || h.type === 'pin').sort((a, b) => b.at - a.at).slice(0, 8);
  const name = ME.name || S.settings.teacher, init = name.split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase();
  v.innerHTML = `<div class="page" data-editing><div class="set-grid">
    <section class="card"><div class="card-h"><h2>Tài khoản đang dùng</h2></div>
      <div class="acct">${ME.avatar ? `<img src="${esc(ME.avatar)}" alt="">` : `<span class="av2">${esc(init)}</span>`}<div><div style="font-family:var(--f-display);font-weight:700;font-size:1.15rem">${esc(name)}</div>
      <div class="row" style="gap:6px;margin-top:4px"><span class="chip acc">${esc(ME.role || 'Giảng viên')}</span><span class="chip ${S.mode === 'db' ? 'ok' : 'warn'}">${S.mode === 'db' ? 'Đã đồng bộ' : 'Lưu cục bộ'}</span></div></div></div>
      <p class="muted" style="margin:14px 0 0;font-size:.84rem">Chấm.Design đăng nhập bằng tài khoản Claude của bạn — không cần mật khẩu riêng. Muốn đồng nghiệp cùng chấm, mở nút <b>Chia sẻ</b> của trang và mời họ.</p></section>
    <section class="card"><div class="card-h"><h2>Mã PIN khoá màn hình</h2><span class="chip ${has ? 'ok' : ''}">${has ? 'Đang bật' : 'Chưa đặt'}</span></div>
      <p class="muted" style="margin:0 0 12px;font-size:.84rem">Khi bật, mỗi lần mở trang sẽ hiện màn hình đăng nhập và hỏi mã PIN — hữu ích khi dùng máy chung ở phòng lab. Mã chỉ khoá màn hình, không thay thế quyền chia sẻ của trang.</p>
      <div class="grid2"><label class="field"><span>${has ? 'Mã PIN mới' : 'Đặt mã PIN'} (4–8 chữ số)</span><input class="inp pin" id="p1" type="password" inputmode="numeric" maxlength="8" autocomplete="new-password"></label>
      <label class="field"><span>Nhập lại</span><input class="inp pin" id="p2" type="password" inputmode="numeric" maxlength="8" autocomplete="new-password"></label></div>
      <div class="row" style="margin-top:12px"><button class="btn pri" id="pSet">${icon('lock')}${has ? 'Đổi mã PIN' : 'Bật mã PIN'}</button>${has ? `<button class="btn" id="pLock">Khoá ngay</button><button class="btn danger" id="pOff">Tắt mã PIN</button>` : ''}</div></section>
    <section class="card" style="grid-column:1/-1"><div class="card-h"><h2>Lịch sử đăng nhập</h2></div>
      ${logins.length ? `<div class="tl">${logins.map(h => `<div class="ev"><time>${fmtTime(h.at)}</time><span class="dotc" style="--c:var(--ink-2)"></span><div class="what"><b>${esc(h.title)}</b><div class="faint" style="font-size:.76rem" data-who="${esc(h.by || '')}">${esc(whoName(h.by))}</div></div></div>`).join('')}</div>` : '<p class="muted" style="margin:0">Chưa có lần đăng nhập bằng mã PIN nào.</p>'}</section>
  </div></div>`;
  $('#pSet').onclick = async () => {
    const a = $('#p1').value.trim(), b = $('#p2').value.trim();
    if (!/^\d{4,8}$/.test(a)) { toast('Mã PIN cần 4–8 chữ số.', true); return; }
    if (a !== b) { toast('Hai lần nhập chưa khớp.', true); return; }
    const h = await pinHash(a); ssSet('cd.unlocked', h); await Store.put('settings', 'app', { pinHash: h });
    logHistory({ type: 'pin', title: has ? 'Đổi mã PIN' : 'Bật mã PIN khoá màn hình' }); toast('Đã lưu mã PIN'); ROUTES.account(v);
  };
  const lk = $('#pLock'); if (lk) lk.onclick = () => { ssSet('cd.unlocked', null); showLock(); };
  const off = $('#pOff'); if (off) off.onclick = () => confirmBox('Tắt mã PIN? Trang sẽ không hỏi mã khi mở nữa.', 'Tắt mã PIN', async () => { await Store.put('settings', 'app', { pinHash: '' }); logHistory({ type: 'pin', title: 'Tắt mã PIN' }); ROUTES.account(v); });
  resolveNames(logins.map(h => h.by)).then(() => $$('[data-who]', v).forEach(s => s.textContent = whoName(s.dataset.who)));
};
