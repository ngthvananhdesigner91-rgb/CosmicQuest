#!/bin/sh
cd /home/claude/app
{ cat head.html; cat body.html; echo '<script>'; cat library.js core.js files.js claude.js pages.js pages2.js grade.js init.js; echo '</script>'; } > /home/claude/ban-cham-do-hoa.html
wc -c /home/claude/ban-cham-do-hoa.html
