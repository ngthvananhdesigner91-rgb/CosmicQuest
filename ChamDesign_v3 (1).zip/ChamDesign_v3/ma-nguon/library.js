/* ===== Thư viện mẫu: môn học, 15 bài/môn, tiêu chí, nhận xét nhanh, cờ nghi vấn AI ===== */
const AI_FLAGS_CORE = [
  { id: 'flat', label: 'Layer phẳng, không dùng Non-destructive (Photoshop)',
    proof: 'mở file PSD, bật/tắt từng Layer Mask, Adjustment Layer và layer ánh sáng/đổ bóng của vùng ghép ngay trước lớp' },
  { id: 'anchor', label: 'Rác điểm neo, cấu trúc Clip Group vô lý (Illustrator)',
    proof: 'bật chế độ Outline (Ctrl+Y), dùng Direct Selection (A) chỉ ra cấu trúc điểm neo và giải thích cách dựng các Clip Group' },
  { id: 'brush', label: 'Nét Brush thiếu tính động',
    proof: 'vẽ lại trực tiếp một đoạn nét tương đương bằng bảng vẽ/chuột trong 5 phút' }
];
const AI_FLAGS_EXTRA = {
  raster: [
    { id: 'nomask', label: 'Cắt ghép hoàn hảo nhưng không có Mask / Adjustment Layer', proof: 'chỉ ra mask của vùng cắt tóc/biên phức tạp và layer chỉnh màu riêng' },
    { id: 'noise', label: 'Nhiễu hạt, độ nét không đồng nhất ở vùng tiếp giáp (dấu vết Generative Fill)', proof: 'phóng 200–300% vùng tiếp giáp và giải thích cách xử lý nền' },
    { id: 'genlayer', label: 'Có layer Generative / Content Credentials nhưng không khai báo', proof: 'mở bảng Properties của layer và trình bày prompt đã dùng' }
  ],
  vector: [
    { id: 'banding', label: 'Dải màu chia thành hàng trăm mảng màu bệt thay vì Gradient/Mesh', proof: 'dựng lại vùng chuyển màu bằng Gradient hoặc Mesh Tool' },
    { id: 'ghost', label: 'Shape tàng hình No Fill/No Stroke chồng chéo', proof: 'mở bảng Layers (F7), giải thích từng nhóm và dọn mảng thừa bằng Pathfinder' },
    { id: 'noname', label: 'Path xé lẻ, không Group/đặt tên logic', proof: 'tổ chức lại Group theo cụm hình (đầu, thân, nền…)' }
  ],
  layout: [
    { id: 'nostyle', label: 'Không dùng Paragraph/Character Styles', proof: 'đổi font toàn bộ thân bài chỉ bằng một thao tác Style' },
    { id: 'outlined', label: 'Văn bản bị outline/ảnh hoá toàn bộ', proof: 'sửa trực tiếp một đoạn văn bản trong file gốc' },
    { id: 'nogrid', label: 'Không có Parent page / lưới thống nhất', proof: 'trình bày hệ lưới và Parent page đã thiết lập' }
  ],
  motion: [
    { id: 'denseKey', label: 'Keyframe dày đặc bất thường, không có easing', proof: 'mở Graph Editor và chỉnh easing một chuyển động' },
    { id: 'noproj', label: 'Chỉ có video xuất, không có project gốc', proof: 'mở project và dựng lại một cảnh ngắn' },
    { id: 'nostory', label: 'Không có storyboard/animatic', proof: 'phác nhanh storyboard 6 khung cho đoạn chính' }
  ],
  ui: [
    { id: 'noauto', label: 'Không dùng Auto Layout/Components', proof: 'thêm một item vào danh sách và cho thấy layout tự giãn' },
    { id: 'nolayer', label: 'Layer không đặt tên, frame lồng vô lý', proof: 'giải thích cấu trúc frame của một màn hình' },
    { id: 'flatui', label: 'Giao diện là ảnh phẳng (không phải layer Figma)', proof: 'chỉnh màu một nút qua biến/Style' }
  ]
};

const RASTER_GOOD = ['Masking sạch', 'Non-destructive', 'Chỉnh màu xuất sắc', 'Cắt ghép mượt', 'Ánh sáng hợp lý', 'Bố cục chặt chẽ'];
const RASTER_FIX = ['Layer gộp phẳng/nghi vấn AI', 'Lệch phối cảnh', 'Vỡ nét/Noise', 'Viền răng cưa/halo', 'Lệch màu da', 'Sai kích thước/độ phân giải'];
const VECTOR_GOOD = ['Đường Bezier tối ưu', 'Pathfinder gọn', 'Bảng màu nhất quán', 'Tổ chức Layer logic', 'Typography tốt', 'Ý tưởng độc đáo'];
const VECTOR_FIX = ['Rác điểm neo/nghi vấn AI', 'Đường cong gãy', 'Màu thiếu tương phản', 'Mảng thừa chồng chéo', 'Chữ chưa căn kerning', 'Thiếu khoảng thở'];
const LAYOUT_GOOD = ['Lưới chặt chẽ', 'Phân cấp thị giác rõ', 'Nhịp chữ đều', 'Styles chuẩn', 'Ảnh đặt hợp lý', 'File in đạt chuẩn'];
const LAYOUT_FIX = ['Lệch lưới', 'Sai lề/bleed', 'Dòng mồ côi/goá', 'Quá nhiều font', 'Ảnh thiếu độ phân giải', 'Leading chưa đều'];
const MOTION_GOOD = ['Easing mềm', 'Nhịp dựng tốt', 'Chuyển cảnh mượt', 'Âm thanh khớp', 'Kể chuyện rõ', 'Typography động đẹp'];
const MOTION_FIX = ['Chuyển động cứng', 'Nhịp rời rạc', 'Lệch âm thanh', 'Quá nhiều hiệu ứng', 'Thiếu storyboard', 'Xuất sai thông số'];
const UI_GOOD = ['Auto Layout chuẩn', 'Components tái sử dụng', 'Phân cấp thị giác rõ', 'Tương phản đạt WCAG', 'Lưới & khoảng cách đều', 'Prototype trôi chảy'];
const UI_FIX = ['Tương phản kém (WCAG)', 'Khoảng cách không đều', 'Vùng chạm quá nhỏ', 'Thiếu trạng thái', 'Layer lộn xộn', 'Lệch lưới'];

const PS_LESSONS = [
  ['Cắt ảnh, chỉnh kích thước và độ phân giải',
   'Đánh giá khả năng cắt cúp theo bố cục, thiết lập kích thước – độ phân giải đúng mục đích in/web và giữ chất lượng ảnh.',
   [['Bố cục cắt cúp hợp lý, tuân thủ quy tắc 1/3 hoặc mục đích sử dụng', 2], ['Kích thước và tỉ lệ đúng yêu cầu đề bài', 2], ['Độ phân giải (ppi) phù hợp in/web, không vỡ nét', 2], ['Cân chỉnh đường chân trời, phối cảnh thẳng', 1.5], ['Giữ chất lượng ảnh khi resample, không nhiễu', 1.5], ['File PSD và file xuất đáp ứng yêu cầu', 1]],
   ['Bố cục 1/3 chuẩn'], ['Sai ppi', 'Méo tỉ lệ']],
  ['Tách nền và ghép ảnh',
   'Đánh giá khả năng xử lý khuyết điểm, làm sạch ảnh và giữ được đặc điểm tự nhiên của đối tượng.',
   [['Loại bỏ khuyết điểm đúng yêu cầu', 2], ['Giữ cấu trúc khuôn mặt và đặc điểm nhận diện', 2], ['Bảo toàn kết cấu da, tránh làm mịn quá mức', 2], ['Xử lý sáng tối và màu da hài hòa', 1.5], ['Chất lượng tổng thể, không có dấu vết chỉnh sửa rõ rệt', 1.5], ['Tổ chức file và bàn giao', 1]],
   ['Giữ texture da'], ['Da bị nhựa hoá']],
  ['Retouch và phục hồi chi tiết',
   'Đánh giá khả năng làm sạch khuyết điểm, phục hồi chi tiết mà vẫn giữ kết cấu tự nhiên của ảnh.',
   [['Loại bỏ khuyết điểm, vết bẩn triệt để', 2], ['Giữ kết cấu bề mặt tự nhiên (da, vải, vật liệu)', 2], ['Dùng Healing/Clone/Patch đúng kỹ thuật, không lặp mẫu', 2], ['Retouch trên layer riêng, có thể chỉnh sửa', 1.5], ['Tổng thể hài hoà, không “nhựa hoá”', 1.5], ['File PSD và file xuất đáp ứng yêu cầu', 1]],
   ['Giữ texture da'], ['Lặp mẫu Clone', 'Da bị nhựa hoá']],
  ['Chỉnh màu và ánh sáng',
   'Đánh giá khả năng hiệu chỉnh tông màu, cân bằng trắng, tương phản và tạo không khí màu bằng Adjustment Layer.',
   [['Cân bằng trắng và màu trung tính chính xác', 2], ['Tương phản, vùng sáng – tối giữ được chi tiết (không cháy/bết)', 2], ['Dùng Adjustment Layer, Curves/Levels thay vì chỉnh trực tiếp', 2], ['Màu da và màu chủ thể tự nhiên', 1.5], ['Tạo được không khí/mood màu phù hợp ý đồ', 1.5], ['File PSD và file xuất đáp ứng yêu cầu', 1]],
   ['Curves tinh tế'], ['Cháy sáng', 'Ám màu']],
  ['Thiết kế hình ảnh quảng cáo đơn giản',
   'Đánh giá khả năng kết hợp ảnh, chữ và bố cục để tạo một hình ảnh quảng cáo truyền đạt thông điệp rõ ràng.',
   [['Thông điệp rõ ràng, đúng đối tượng mục tiêu', 2], ['Phân cấp thị giác: tiêu đề – hình ảnh – CTA', 2], ['Bố cục và lưới cân bằng', 1.5], ['Typography dễ đọc, kết hợp font hợp lý', 1.5], ['Xử lý ảnh và màu sắc đồng bộ nhận diện', 2], ['File PSD và file xuất đáp ứng yêu cầu', 1]],
   ['CTA nổi bật'], ['Chữ khó đọc', 'Quá nhiều thông tin']],
  ['Phục chế ảnh cũ',
   'Đánh giá khả năng phục hồi ảnh hư hỏng: vết rách, nấm mốc, phai màu và tái tạo chi tiết bị mất.',
   [['Xử lý vết rách, gấp, nấm mốc triệt để', 2], ['Tái tạo chi tiết bị mất hợp lý, có căn cứ', 2], ['Khôi phục dải tông và độ tương phản', 1.5], ['Tô màu/phục hồi màu tự nhiên (nếu yêu cầu)', 1.5], ['Giữ được tinh thần, chất liệu ảnh gốc', 2], ['File PSD và file xuất đáp ứng yêu cầu', 1]],
   ['Phục dựng tinh tế'], ['Chi tiết tái tạo giả']],
  ['Retouch chân dung chuyên sâu',
   'Đánh giá kỹ thuật Frequency Separation, Dodge & Burn và tạo khối gương mặt mà vẫn giữ nét tự nhiên.',
   [['Frequency Separation tách tông – kết cấu chuẩn', 2], ['Dodge & Burn tạo khối mềm, có chủ đích', 2], ['Giữ đặc điểm nhận dạng và texture da', 2], ['Xử lý mắt, tóc, răng tinh tế', 1.5], ['Màu da đồng đều, đúng tông', 1.5], ['File PSD và file xuất đáp ứng yêu cầu', 1]],
   ['D&B mềm mại'], ['Mất nhận dạng', 'Da bị nhựa hoá']],
  ['Photo manipulation – ghép ảnh siêu thực',
   'Đánh giá khả năng kết hợp nhiều nguồn ảnh thành một bối cảnh siêu thực thống nhất về ánh sáng, phối cảnh và câu chuyện.',
   [['Ý tưởng siêu thực độc đáo, có câu chuyện', 2], ['Phối cảnh, tỉ lệ các thành phần nhất quán', 2], ['Ánh sáng, bóng đổ, phản xạ thống nhất', 2], ['Hoà màu (color grading) toàn cảnh', 1.5], ['Kỹ thuật mask, blend sạch, non-destructive', 1.5], ['File PSD và file xuất đáp ứng yêu cầu', 1]],
   ['Ý tưởng mạnh'], ['Nguồn sáng mâu thuẫn']],
  ['Hiệu ứng chữ và Layer Style',
   'Đánh giá khả năng tạo hiệu ứng chữ bằng Layer Style, texture và ánh sáng mà vẫn giữ chữ có thể chỉnh sửa.',
   [['Hiệu ứng phù hợp nội dung/chủ đề', 2], ['Dùng Layer Style, Smart Object, chữ vẫn chỉnh được', 2], ['Chất liệu, ánh sáng, chiều sâu thuyết phục', 2], ['Khả năng đọc của chữ', 1.5], ['Bố cục và nền hỗ trợ chữ', 1.5], ['File PSD và file xuất đáp ứng yêu cầu', 1]],
   ['Chất liệu thật'], ['Chữ bị rasterize']],
  ['Thiết kế banner mạng xã hội',
   'Đánh giá khả năng thiết kế banner đúng kích thước nền tảng, thông điệp nhanh và thu hút trong luồng tin.',
   [['Đúng kích thước, vùng an toàn của nền tảng', 1.5], ['Thông điệp đọc được trong 3 giây', 2], ['Phân cấp thị giác và điểm nhấn', 2], ['Typography và tương phản (đọc trên điện thoại)', 2], ['Đồng bộ nhận diện thương hiệu', 1.5], ['File PSD và file xuất đáp ứng yêu cầu', 1]],
   ['Bắt mắt trên mobile'], ['Chữ quá nhỏ']],
  ['Mockup sản phẩm với Smart Object',
   'Đánh giá khả năng dựng mockup có Smart Object thay thế được, ánh sáng – bóng – phản chiếu chân thực.',
   [['Smart Object thay thiết kế được dễ dàng', 2], ['Biến dạng (warp/perspective) khớp bề mặt', 2], ['Ánh sáng, bóng, highlight chân thực', 2], ['Chất liệu bề mặt (giấy, vải, kim loại)', 1.5], ['Trình bày bối cảnh chuyên nghiệp', 1.5], ['File PSD và file xuất đáp ứng yêu cầu', 1]],
   ['Smart Object chuẩn'], ['Lệch phối cảnh nhãn']],
  ['Xử lý ảnh sản phẩm thương mại điện tử',
   'Đánh giá khả năng chuẩn hoá ảnh sản phẩm: tách nền trắng, màu đúng thực tế, đồng bộ bộ ảnh.',
   [['Tách nền trắng/thuần sạch, đúng chuẩn sàn', 2], ['Màu sản phẩm trung thực', 2], ['Căn giữa, tỉ lệ khung đồng bộ cả bộ ảnh', 1.5], ['Bóng đổ tự nhiên, sản phẩm có khối', 1.5], ['Làm sạch bụi, vết xước, chi tiết sắc nét', 2], ['File PSD và file xuất đáp ứng yêu cầu', 1]],
   ['Bộ ảnh đồng bộ'], ['Màu sai thực tế']],
  ['Thiết kế poster sự kiện',
   'Đánh giá khả năng thiết kế poster truyền đạt thông tin sự kiện với phân cấp thị giác, lưới và typography chặt chẽ.',
   [['Ý tưởng hình ảnh chủ đạo', 2], ['Phân cấp thị giác thông tin (tên, thời gian, địa điểm)', 2], ['Hệ thống lưới và căn chỉnh', 1.5], ['Typography: kết hợp font, nhịp dòng', 1.5], ['Màu sắc và tương phản', 2], ['File PSD và file xuất đáp ứng yêu cầu', 1]],
   ['Poster ấn tượng'], ['Thông tin rối']],
  ['Matte painting – mở rộng bối cảnh',
   'Đánh giá khả năng vẽ/ghép mở rộng bối cảnh với chiều sâu khí quyển, phối cảnh và ánh sáng thống nhất.',
   [['Phối cảnh và đường chân trời nhất quán', 2], ['Chiều sâu khí quyển (atmospheric perspective)', 2], ['Ánh sáng và màu thống nhất toàn cảnh', 2], ['Chi tiết vẽ tay/ghép ăn khớp, không đứt gãy', 1.5], ['Bố cục điện ảnh, điểm nhìn', 1.5], ['File PSD và file xuất đáp ứng yêu cầu', 1]],
   ['Chiều sâu tốt'], ['Đứt gãy chi tiết']],
  ['Đồ án cuối kỳ: Bộ ấn phẩm quảng cáo',
   'Đánh giá năng lực tổng hợp: ý tưởng chiến dịch, hệ thống hình ảnh nhất quán và kỹ thuật xử lý ảnh trên nhiều ấn phẩm.',
   [['Ý tưởng chiến dịch, insight rõ ràng', 2], ['Hệ thống hình ảnh nhất quán giữa các ấn phẩm', 2], ['Kỹ thuật xử lý ảnh (ghép, màu, retouch)', 2], ['Bố cục, lưới và typography', 1.5], ['Quy trình: phác thảo, bản trung gian, thuyết trình', 1.5], ['File nguồn và file xuất đáp ứng yêu cầu', 1]],
   ['Hệ thống đồng bộ'], ['Thiếu quy trình']]
];

const AI_LESSONS = [
  ['Đồ họa vector, môi trường Illustrator; hình cơ bản, biến đổi, căn chỉnh', 'Đánh giá khả năng làm chủ môi trường Illustrator, dựng hình từ khối cơ bản, biến đổi và căn chỉnh chính xác.',
   [['Thiết lập tài liệu, artboard, hệ màu đúng yêu cầu', 1.5], ['Dựng hình từ khối cơ bản đúng tỉ lệ', 2], ['Biến đổi (xoay, lật, co giãn, nhân bản) chính xác', 2], ['Căn chỉnh, phân bố bằng Align/Smart Guides', 2], ['Tổ chức Layer/Group rõ ràng', 1.5], ['File AI và file xuất đúng yêu cầu', 1]], [], []],
  ['Shape Builder, Pathfinder; Pen Tool, đường cong Bézier, Curvature, Pencil; vẽ lại phác thảo', 'Đánh giá khả năng cắt ghép mảng bằng Shape Builder/Pathfinder và vẽ lại phác thảo bằng Pen Tool với đường cong Bézier tối ưu.',
   [['Bám sát phác thảo, hình dáng chính xác', 2], ['Số điểm neo tối ưu, đặt ở điểm cực trị', 2], ['Đường cong Bézier mượt, không gãy khúc', 2], ['Shape Builder/Pathfinder cắt mảng sạch', 2], ['Tổ chức path, không có mảng thừa', 1], ['File AI và file xuất đúng yêu cầu', 1]], ['Bézier chuẩn'], ['Thừa điểm neo']],
  ['Màu sắc cho minh họa: Swatches, Global, Recolor, Gradient, Live Paint; giao A2', 'Đánh giá khả năng xây dựng và quản lý bảng màu cho minh họa bằng Swatches, Global Colors, Recolor Artwork, Gradient và Live Paint.',
   [['Bảng màu có chủ đích, hài hòa với nội dung', 2], ['Dùng Swatches, Global Colors, Color Group', 1.5], ['Recolor Artwork tạo phương án màu', 1.5], ['Gradient mượt, đúng công cụ (không chia mảng bệt)', 1.5], ['Live Paint tô vùng chính xác', 1.5], ['Tương phản và phân cấp màu', 1], ['File AI và file xuất đúng yêu cầu', 1]], [], ['Gradient bị chia mảng']],
  ['Nét vẽ, Brushes, Appearance; chữ, lettering tên truyện', 'Đánh giá khả năng dùng nét vẽ, Brushes, Appearance và thiết kế lettering tên truyện phù hợp tinh thần câu chuyện.',
   [['Nét vẽ có nhịp, độ dày biến thiên hợp lý (Brushes, Width)', 2], ['Appearance nhiều lớp fill/stroke, còn chỉnh sửa được', 1.5], ['Lettering tên truyện thể hiện tinh thần câu chuyện', 2.5], ['Bố cục chữ, kerning, độ dễ đọc', 2], ['Hài hòa giữa chữ và hình minh họa', 1], ['File AI (chữ, nét chưa expand) và file xuất', 1]], ['Lettering có cá tính'], ['Nét đều, thiếu nhịp']],
  ['Phong cách minh họa và nguyên lý thị giác; bộ quy tắc phong cách', 'Đánh giá khả năng xác định phong cách minh họa và xây dựng bộ quy tắc phong cách dựa trên nguyên lý thị giác.',
   [['Phong cách rõ ràng, nhất quán', 2], ['Vận dụng nguyên lý thị giác (cân bằng, nhịp điệu, tương phản, điểm nhấn)', 2], ['Bộ quy tắc mô tả cụ thể hình khối, nét, màu, chất liệu', 2.5], ['Ví dụ minh họa áp dụng đúng quy tắc', 1.5], ['Trình bày tài liệu phong cách', 1], ['File AI và file xuất đúng yêu cầu', 1]], [], []],
  ['Thiết kế nhân vật', 'Đánh giá khả năng thiết kế nhân vật có tính cách, tỉ lệ, biểu cảm và các góc nhìn nhất quán theo bộ quy tắc phong cách.',
   [['Tính cách nhân vật rõ, phù hợp câu chuyện', 2], ['Tỉ lệ và cấu trúc hình học', 2], ['Bảng góc quay và biểu cảm nhất quán', 2], ['Bảng màu, phong cách đúng bộ quy tắc', 1.5], ['Path tối ưu, Group theo bộ phận', 1.5], ['File AI và file xuất đúng yêu cầu', 1]], ['Nhân vật có hồn'], ['Tỉ lệ không nhất quán']],
  ['Bối cảnh, đồ vật, minh họa điểm; Perspective Grid; Symbols, Repeat, Pattern', 'Đánh giá khả năng dựng bối cảnh và đồ vật bằng Perspective Grid, dùng Symbols, Repeat, Pattern để tạo minh họa điểm có chiều sâu.',
   [['Bố cục bối cảnh, chiều sâu không gian', 2], ['Phối cảnh đúng Perspective Grid', 2], ['Đồ vật, minh họa điểm thống nhất phong cách', 1.5], ['Symbols, Repeat, Pattern dùng hợp lý, còn chỉnh sửa được', 2], ['Hài hòa với nhân vật và bộ quy tắc phong cách', 1.5], ['File AI và file xuất đúng yêu cầu', 1]], [], ['Lệch phối cảnh']],
  ['Ánh sáng, đổ bóng, chất liệu; Blend, Gradient Mesh, Mask, Image Trace; hiệu ứng và 3D', 'Đánh giá khả năng tạo ánh sáng, đổ bóng, chất liệu bằng Blend, Gradient Mesh, Mask, hiệu ứng và 3D mà vẫn giữ file vector sạch.',
   [['Ánh sáng, đổ bóng nhất quán nguồn sáng', 2], ['Chất liệu thuyết phục', 1.5], ['Blend, Gradient Mesh đúng kỹ thuật, lưới gọn', 2], ['Clipping/Opacity Mask chính xác', 1.5], ['Image Trace, hiệu ứng 3D dùng có chủ đích, đã tinh chỉnh', 2], ['File AI và file xuất đúng yêu cầu', 1]], ['Mesh mượt'], ['Image Trace chưa tinh chỉnh']],
  ['Đánh giá giữa học phần (A2)', 'Đánh giá năng lực tổng hợp giữa học phần qua bài A2: phong cách, nhân vật, bối cảnh, màu sắc và kỹ thuật vector.',
   [['Ý tưởng và câu chuyện của bài A2', 2], ['Bố cục và phân cấp thị giác', 2], ['Nhân vật, bối cảnh nhất quán bộ quy tắc phong cách', 2], ['Màu sắc, ánh sáng', 1.5], ['Kỹ thuật vector sạch (điểm neo, Pathfinder, layer)', 1.5], ['File và thuyết trình', 1]], [], []],
  ['Bản đồ minh họa, isometric, trang sách tư duy', 'Đánh giá khả năng thiết kế bản đồ minh họa, hình isometric và trang sách tư duy rõ thông tin, hấp dẫn người đọc.',
   [['Hệ lưới isometric, phép chiếu chính xác', 2], ['Bố cục bản đồ, luồng đọc', 2], ['Thông tin, chú thích, icon rõ ràng', 2], ['Trang sách tư duy có tính tương tác, phù hợp lứa tuổi', 1.5], ['Màu sắc, phong cách thống nhất', 1.5], ['File AI và file xuất đúng yêu cầu', 1]], [], ['Sai góc isometric']],
  ['Chuyên đề 1: kể chuyện bằng hình – storyboard, cỡ cảnh, khung truyện tranh, trang đôi, bóng thoại', 'Đánh giá khả năng kể chuyện bằng hình: storyboard, lựa chọn cỡ cảnh, chia khung truyện tranh, dàn trang đôi và bóng thoại.',
   [['Storyboard có mạch truyện rõ', 2], ['Cỡ cảnh, góc máy đa dạng, có chủ đích', 2], ['Chia khung, nhịp đọc truyện tranh', 2], ['Dàn trang đôi cân bằng', 1.5], ['Bóng thoại và chữ thoại dễ đọc', 1.5], ['File AI và file xuất đúng yêu cầu', 1]], [], ['Nhịp khung rời rạc']],
  ['Phản hồi A2; giao Bài tập lớn; sản xuất hàng loạt: Libraries, Variables, Actions', 'Đánh giá khả năng tiếp thu phản hồi A2 và tổ chức sản xuất hàng loạt bằng Libraries, Variables và Actions.',
   [['Chỉnh sửa A2 theo phản hồi', 2.5], ['Libraries quản lý màu, ký tự, đồ họa dùng chung', 2], ['Variables tạo phiên bản hàng loạt', 2], ['Actions tự động hóa thao tác lặp', 1.5], ['Kế hoạch Bài tập lớn rõ ràng', 1], ['File AI và file xuất đúng yêu cầu', 1]], [], []],
  ['Bài thi (1/3): khổ, dàn trang, tổ chức tệp; truyện tranh, truyện minh họa, tranh truyện; sách tô màu, sách tư duy trẻ em', 'Đánh giá phần 1 bài thi: chọn khổ, dàn trang, tổ chức tệp và phát triển truyện tranh, truyện minh họa, sách tô màu hoặc sách tư duy trẻ em.',
   [['Khổ và dàn trang phù hợp sản phẩm', 2], ['Tổ chức tệp, artboard, layer chuẩn', 1.5], ['Nội dung minh họa, kể chuyện', 2.5], ['Phù hợp đối tượng người đọc (trẻ em)', 2], ['Nhất quán phong cách', 1], ['Tiến độ và file nộp', 1]], [], []],
  ['Bài thi (2/3): gameboard, thẻ bài; ấn phẩm truyền thông 2D; giấy, in ấn, gia công, mockup', 'Đánh giá phần 2 bài thi: gameboard, thẻ bài, ấn phẩm truyền thông 2D, lựa chọn giấy, in ấn, gia công và mockup.',
   [['Gameboard, thẻ bài: luật chơi và hệ thống thiết kế', 2], ['Ấn phẩm truyền thông 2D đồng bộ', 2], ['Chất liệu giấy, kỹ thuật in và gia công phù hợp', 2], ['Mockup trình bày thuyết phục', 1.5], ['Nhất quán với sản phẩm phần 1', 1.5], ['File in đúng chuẩn', 1]], [], []],
  ['Bài thi (3/3): hoàn thiện, bình bản, tổng duyệt', 'Đánh giá phần 3 bài thi: hoàn thiện sản phẩm, bình bản in và tổng duyệt toàn bộ bộ sản phẩm.',
   [['Mức độ hoàn thiện, chi tiết', 2.5], ['Bình bản đúng kỹ thuật (bleed, dấu cắt, thứ tự trang)', 2], ['Hệ thống sản phẩm thống nhất', 2], ['Thuyết trình và bảo vệ', 1.5], ['Quy trình: phác thảo, bản trung gian', 1], ['File in và package', 1]], [], []]
];

function simpleLessons(names, template, objectiveFn) {
  return names.map(n => [n, objectiveFn(n), template, [], []]);
}
const ID_NAMES = ['Thiết lập tài liệu, Margin và Bleed', 'Hệ thống lưới (Grid) và cột', 'Typography: Character và Paragraph Styles', 'Hình ảnh và Text wrap', 'Parent pages (Master pages)', 'Tờ gấp (Brochure)', 'Thiết kế bìa tạp chí', 'Dàn trang nội dung tạp chí', 'Bảng biểu và Table Styles', 'Sách: mục lục, đánh số trang', 'Báo cáo thường niên', 'Catalogue sản phẩm', 'Ấn phẩm tương tác (Interactive PDF)', 'Preflight, Package và xuất file in', 'Đồ án cuối kỳ: Ấn phẩm xuất bản hoàn chỉnh'];
const ID_TPL = [['Hệ thống lưới, lề, bleed chuẩn', 2], ['Phân cấp thị giác và luồng đọc', 2], ['Nhịp điệu typography (leading, baseline grid)', 2], ['Dùng Styles/Parent page nhất quán', 1.5], ['Hình ảnh và khoảng trắng', 1.5], ['File INDD/PDF in đạt chuẩn', 1]];
const MM_NAMES = ['12 nguyên lý chuyển động', 'Keyframe và Easing', 'Motion typography', 'Animated icon', 'Logo animation', 'Shape layer và Masking', 'Storyboard và Animatic', 'Video quảng cáo ngắn', 'Âm thanh và nhịp dựng', 'Infographic động', 'Banner động HTML5', 'Micro-interaction cho UI', 'Nội dung dọc cho mạng xã hội', 'Trình chiếu tương tác', 'Đồ án cuối kỳ: Sản phẩm truyền thông đa phương tiện'];
const MM_TPL = [['Ý tưởng và kịch bản', 2], ['Chuyển động: timing, easing, nguyên lý', 2.5], ['Nhịp dựng và chuyển cảnh', 1.5], ['Hình ảnh, typography, màu', 1.5], ['Âm thanh khớp hình', 1.5], ['Project gốc và file xuất đúng thông số', 1]];
const UI_NAMES = ['Giao diện Figma, Frame và Layout grid', 'Auto Layout', 'Components và Variants', 'Typography, Color styles và Design tokens', 'Wireframe low-fidelity', 'UI mobile: Onboarding', 'UI mobile: Màn hình chính', 'Landing page responsive', 'Dashboard web', 'Hệ thống thiết kế (Design system)', 'Prototype và tương tác', 'Khả năng tiếp cận (WCAG)', 'Usability testing và cải tiến', 'Handoff cho lập trình', 'Đồ án cuối kỳ: Sản phẩm số hoàn chỉnh'];
const UI_TPL = [['Phân cấp thị giác và luồng người dùng', 2], ['Hệ thống lưới, khoảng cách (spacing scale)', 1.5], ['Tương phản và khả năng tiếp cận (WCAG)', 2], ['Typography: thang chữ, nhịp dòng', 1.5], ['Components, Auto Layout, tổ chức layer', 2], ['File Figma và prototype', 1]];

function mkLessons(prefix, arr) {
  return arr.map((l, i) => ({
    id: prefix + (i + 1), no: i + 1, name: l[0], objective: 'Mục tiêu: ' + l[1],
    criteria: l[2].map(c => ({ name: c[0], max: c[1], levels: '' })),
    goodExtra: l[3] || [], fixExtra: l[4] || []
  }));
}
const DEFAULT_COURSES = [
  { id: 'ps', name: 'Thiết kế và xử lý hình ảnh số', soft: 'Photoshop', kind: 'raster', hue: 'ps', good: RASTER_GOOD, fix: RASTER_FIX, lessons: mkLessons('ps', PS_LESSONS) },
  { id: 'ai', name: 'Thiết kế đồ họa vector', soft: 'Illustrator', kind: 'vector', hue: 'ai', good: VECTOR_GOOD, fix: VECTOR_FIX, lessons: mkLessons('ai', AI_LESSONS) },
  { id: 'id', name: 'Thiết kế dàn trang và xuất bản', soft: 'InDesign', kind: 'layout', hue: 'id', good: LAYOUT_GOOD, fix: LAYOUT_FIX,
    lessons: mkLessons('id', simpleLessons(ID_NAMES, ID_TPL, n => 'Đánh giá khả năng dàn trang “' + n + '”: lưới, phân cấp thị giác, nhịp typography và chuẩn file in.')) },
  { id: 'mm', name: 'Thiết kế tương tác đa phương tiện', soft: 'After Effects', kind: 'motion', hue: 'mm', good: MOTION_GOOD, fix: MOTION_FIX,
    lessons: mkLessons('mm', simpleLessons(MM_NAMES, MM_TPL, n => 'Đánh giá khả năng thực hiện “' + n + '”: ý tưởng, nguyên lý chuyển động, nhịp dựng và thông số xuất.')) },
  { id: 'ui', name: 'Thiết kế giao diện số', soft: 'Figma', kind: 'ui', hue: 'ui', good: UI_GOOD, fix: UI_FIX,
    lessons: mkLessons('ui', simpleLessons(UI_NAMES, UI_TPL, n => 'Đánh giá khả năng thiết kế “' + n + '”: phân cấp thị giác, lưới, tương phản WCAG và tổ chức component.')) }
];
const DEFAULT_CLASSES = [{ id: '524TKD', name: '524TKD', students: [], courseIds: ['ps'] }, { id: '525TKD', name: '525TKD', students: [], courseIds: ['ai'] }];
const AI_LEVELS = [
  { n: 1, name: 'Không dùng AI', desc: 'Toàn bộ bài do sinh viên tự làm.' },
  { n: 2, name: 'AI để lên ý tưởng', desc: 'Được dùng AI tìm ý tưởng, moodboard; sản phẩm cuối tự làm.' },
  { n: 3, name: 'AI hỗ trợ một phần', desc: 'Ví dụ Generative Fill nền, nhưng phải khai báo rõ vùng dùng AI.' },
  { n: 4, name: 'Dùng AI tự do', desc: 'Được dùng thoải mái nhưng phải giải trình quy trình.' },
  { n: 5, name: 'Bài tập về chính AI', desc: 'Đề bài nhằm khám phá công cụ AI.' }
];
const EVIDENCE = [
  { id: 'source', label: 'File gốc có layer (PSD/AI/INDD/Figma)' },
  { id: 'sketch', label: 'Phác thảo (sketch)' },
  { id: 'versions', label: 'Tối thiểu 2 bản trung gian' },
  { id: 'declare', label: 'Bản khai báo sử dụng AI' },
  { id: 'reflect', label: 'Bài viết phản tư ngắn' }
];
const DEFAULT_SETTINGS = {
  teacher: 'Tuan BT', unit: 'Khoa Thiết kế Đồ họa · Trường Đại học Victoria Hòa Bình', tier: 'default',
  ultimatum: 'Lưu ý về tính xác thực: Một số dấu hiệu kỹ thuật trong bài ({flags}) chưa phản ánh quy trình dựng hình của chính em. Thầy/cô tin rằng em có thể chứng minh điều ngược lại. Ở buổi học tới, em vui lòng mang theo file gốc đầy đủ layer và các bản trung gian, đồng thời {proof}. Nếu quy trình không được làm rõ, điểm bài này sẽ được xem xét lại theo quy định liêm chính học thuật của môn học.'
};
