/* ===== 1. Tổng quan ===== */
ROUTES.dashboard = (v) => {
  const subs = subsArr(), now = Date.now();
  const cho = subs.filter(s => s.status === 'cho'), nhap = subs.filter(s => s.status === 'nhap'), duyet = subs.filter(s => s.status === 'duyet');
  const flagged = subs.filter(s => s.status !== 'duyet' && ((s.flags || []).length || (s.ai?.percent ?? 0) >= 30));
  const prio = s => (s.ai?.percent ?? 0) / 3 + (s.flags || []).length * 5 + (s.late ? 8 : 0) + (s.status === 'nhap' ? 4 : 0) + Math.min(10, (now - (s.createdAt || now)) / 864e5);
  const todo = subs.filter(s => s.status !== 'duyet').sort((a, b) => prio(b) - prio(a)).slice(0, 8);
  const prog = classes().map(k => { const mine = subs.filter(s => s.classId === k.id); const ap = mine.filter(s => s.status === 'duyet'); const tot = Math.max(mine.length, (k.students || []).length); return { k, ap: ap.length, tot, avg: mean(ap.map(subTotal).filter(x => x != null)) }; });
  const feed = subs.slice(0, 8).map(s => {
    const l = lesson(s.courseId, s.lessonId); const nm = esc(s.name || s.mssv || 'Sinh viên');
    const txt = s.status === 'duyet' ? `Đã duyệt <b>${fmt(subTotal(s))}</b> điểm cho ${nm} — Bài ${l.no}` : s.status === 'nhap' ? `Claude đã chấm nháp bài của ${nm} — Bài ${l.no}` : `${nm} vừa nộp bài ${esc(l.name)}`;
    return `<div><time>${fmtTime(s.updatedAt)}</time><span>${txt}</span></div>`;
  }).join('');
  v.innerHTML = `<div class="page">
    <div class="stat-grid">
      <a class="stat" href="#queue"><b class="num">${cho.length}</b><span>Bài chờ chấm</span></a>
      <a class="stat" href="#queue"><b class="num">${nhap.length}</b><span>Claude đã chấm nháp, chờ duyệt</span></a>
      <a class="stat ${flagged.length ? 'attn' : ''}" href="#transparency"><b class="num">${flagged.length}</b><span>Bài có nghi vấn AI cần xem kỹ</span></a>
      <a class="stat" href="#stats"><b class="num">${duyet.length}</b><span>Bài đã duyệt điểm</span></a>
    </div>
    <div class="split">
      <section class="card"><div class="card-h"><h2>Cần xử lý hôm nay</h2><span class="chip">${todo.length} bài</span></div>
        ${todo.length ? `<div class="tbl-wrap" style="border:0;box-shadow:none"><table class="tbl"><thead><tr><th>Sinh viên</th><th>Bài</th><th>Trạng thái</th><th></th></tr></thead><tbody>${todo.map(s => {
          const l = lesson(s.courseId, s.lessonId), st = STATUS[s.status] || STATUS.cho;
          return `<tr><td><b>${esc(s.name || '—')}</b><div class="faint mono" style="font-size:.72rem">${esc(s.mssv || '')} · ${esc(s.className || '')}</div></td><td>Bài ${l.no}: ${esc(l.name)}</td>
          <td><span class="chip ${st[1]}">${st[0]}</span> ${s.ai?.percent != null ? `<span class="chip ${pctClass(s.ai.percent)}">AI ${s.ai.percent}%</span>` : ''}${s.late ? ' <span class="chip warn">Trễ</span>' : ''}</td>
          <td><button class="btn sm pri" onclick="openSub('${s.id}')">Chấm</button></td></tr>`; }).join('')}</tbody></table></div>`
          : `<div class="empty"><b>Không còn bài nào chờ xử lý</b>Nhận bài cả lớp ở Hàng chờ chấm, hoặc thả bài trực tiếp vào màn hình Chấm bài.</div>`}
      </section>
      <section class="card"><div class="card-h"><h2>Tiến độ theo lớp</h2></div>
        <div class="prog">${prog.map(o => `<div class="it"><b>${esc(o.k.name)}</b><div><div class="bar"><i style="width:${o.tot ? 100 * o.ap / o.tot : 0}%;background:var(--accent)"></i></div><div class="faint" style="font-size:.72rem;margin-top:4px">${o.ap}/${o.tot || 0} bài đã duyệt</div></div><span class="num" style="text-align:right">TB ${fmt(o.avg)}</span></div>`).join('')}</div>
        <p class="muted" style="font-size:.78rem;margin:14px 0 0">Thêm danh sách sinh viên ở <a href="#courses">Môn học &amp; Lớp</a> để theo dõi tiến độ đủ sĩ số.</p>
      </section>
    </div>
    <section class="card"><div class="card-h"><h2>Hoạt động gần đây</h2></div>${feed ? `<div class="feed">${feed}</div>` : `<div class="empty">Chưa có hoạt động. Mỗi lần nhận bài, Claude chấm nháp hay bạn duyệt điểm sẽ hiện ở đây.</div>`}</section>
  </div>`;
};

/* ===== 2. Môn học & Lớp ===== */
let courseTab = 'classes';
ROUTES.courses = (v, refresh) => {
  const param = (location.hash.split('.')[1] || '');
  if (refresh && v.querySelector('[data-editing]')) return;
  const cls = classes();
  if (!param) {
    v.innerHTML = `<div class="page"><div class="page-head"><div class="grow"><h1>Môn học &amp; Lớp</h1><p>Mỗi môn có 15 bài, mỗi bài có mục tiêu và tiêu chí chấm riêng. Bấm vào một môn để quản lý lớp, bài tập và rubric dùng chung.</p></div>
      <button class="btn" id="addClass">${icon('plus')}Thêm lớp</button></div>
      <div class="course-grid">${courses().map(c => {
        const ccls = cls.filter(k => (k.courseIds || []).includes(c.id));
        const nsv = sum(ccls.map(k => (k.students || []).length)), nas = Object.values(S.assignments).filter(a => a.courseId === c.id).length;
        return `<button class="course" onclick="go('courses.${c.id}')"><div class="sw sw-${esc(c.hue || 'ps')}">${esc(c.soft)}</div><div class="bd"><b>${esc(c.name)}</b>
        <div class="row" style="gap:6px"><span class="chip">${ccls.length} lớp</span><span class="chip">${nsv} SV</span><span class="chip">${c.lessons.length} bài học</span></div></div></button>`; }).join('')}</div>
      <section class="card"><div class="card-h"><h2>Tất cả lớp</h2></div><div class="tbl-wrap" style="border:0"><table class="tbl"><thead><tr><th>Lớp</th><th>Sĩ số</th><th>Môn đang học</th><th>Đã chấm</th></tr></thead><tbody>
      ${cls.map(k => `<tr class="click" onclick="editClass('${esc(k.id)}')"><td><b>${esc(k.name)}</b></td><td class="num">${(k.students || []).length}</td><td>${(k.courseIds || []).map(id => `<span class="chip">${esc(course(id).soft)}</span>`).join(' ') || '<span class="faint">—</span>'}</td><td class="num">${subsArr().filter(s => s.classId === k.id && s.status === 'duyet').length}</td></tr>`).join('')}
      </tbody></table></div></section></div>`;
    $('#addClass').onclick = () => editClass(null);
    return;
  }
  const c = course(param);
  const ccls = cls.filter(k => (k.courseIds || []).includes(c.id));
  const asg = Object.values(S.assignments).filter(a => a.courseId === c.id);
  v.innerHTML = `<div class="page"><div class="page-head"><div class="grow"><a href="#courses" class="muted" style="font-size:.8rem;text-decoration:none">← Môn học &amp; Lớp</a><h1>${esc(c.name)}</h1><p>Phần mềm chính: ${esc(c.soft)} · ${c.lessons.length} bài học</p></div></div>
    <div class="tabs" role="tablist">${[['classes', 'Danh sách lớp'], ['rubric', 'Rubric dùng chung']].map(([k, t]) => `<button role="tab" aria-selected="${courseTab === k}" data-t="${k}">${t}</button>`).join('')}</div>
    <div id="ctab"></div></div>`;
  $$('.tabs button', v).forEach(b => b.onclick = () => { courseTab = b.dataset.t; ROUTES.courses(v); });
  const t = $('#ctab', v);
  if (courseTab === 'classes') {
    t.innerHTML = `<div class="row" style="margin-bottom:10px"><button class="btn" id="linkCls">${icon('plus')}Gắn lớp vào môn</button></div>` + (ccls.length ? ccls.map(k => `<section class="card" style="margin-bottom:10px"><div class="card-h"><h3>Lớp ${esc(k.name)}</h3><span class="chip">${(k.students || []).length} SV</span><button class="btn sm" onclick="editClass('${esc(k.id)}')">Sửa / Import Excel</button></div>
      ${(k.students || []).length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>#</th><th>MSSV</th><th>Họ tên</th><th>Điểm TB môn</th></tr></thead><tbody>${k.students.map((s, i) => { const sc = subsArr().filter(x => x.classId === k.id && x.mssv === s.mssv && x.courseId === c.id && x.status === 'duyet').map(subTotal); return `<tr><td class="num faint">${i + 1}</td><td class="num">${esc(s.mssv)}</td><td>${esc(s.name)}</td><td class="num">${fmt(mean(sc))}</td></tr>`; }).join('')}</tbody></table></div>` : `<div class="empty"><b>Chưa có danh sách sinh viên</b>Import từ file Excel (cột MSSV, Họ tên) hoặc dán danh sách.</div>`}</section>`).join('') : `<div class="empty card"><b>Chưa có lớp nào học môn này</b>Gắn một lớp có sẵn hoặc tạo lớp mới.</div>`);
    $('#linkCls', t).onclick = () => {
      modal(`<h2>Gắn lớp vào môn ${esc(c.soft)}</h2><div class="field"><span>Chọn lớp</span><select class="inp" id="lc">${cls.map(k => `<option value="${esc(k.id)}">${esc(k.name)}</option>`).join('')}</select></div><div class="modal-f"><button class="btn" data-close>Huỷ</button><button class="btn pri" id="ok">Gắn lớp</button></div>`, (m, close) => {
        $('#ok', m).onclick = async () => { const k = klass($('#lc', m).value); const ids = new Set(k.courseIds || []); ids.add(c.id); await Store.put('classes', k.id, { ...k, courseIds: [...ids] }); close(); toast('Đã gắn lớp ' + k.name); };
      });
    };
  } else {
    t.innerHTML = `<div class="row" style="margin-bottom:10px"><a class="btn" href="#library.${c.id}">${icon('cog')}Sửa rubric trong Thư viện</a></div><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Bài</th><th>Mục tiêu</th><th>Tiêu chí (điểm tối đa)</th></tr></thead><tbody>${c.lessons.map(l => `<tr><td class="num"><b>${l.no}</b></td><td style="min-width:240px"><b>${esc(l.name)}</b><div class="muted" style="font-size:.78rem">${esc(l.objective)}</div></td><td style="font-size:.78rem;min-width:280px">${l.criteria.map(k => `${esc(k.name)} — <span class="num">${fmt(k.max, 1)}</span>`).join('<br>')}</td></tr>`).join('')}</tbody></table></div>`;
  }
};
function editClass(id) {
  const k = id ? klass(id) : { id: '', name: '', students: [], courseIds: [] };
  const txt = (k.students || []).map(s => s.mssv + '\t' + s.name).join('\n');
  modal(`<h2>${id ? 'Lớp ' + esc(k.name) : 'Thêm lớp'}</h2>
    <div class="grid2"><label class="field"><span>Tên lớp</span><input class="inp" id="cn" value="${esc(k.name)}" placeholder="VD: 523TKD"></label>
    <div class="field"><span>Môn học</span><div class="tags">${courses().map(c => `<label class="chk"><input type="checkbox" value="${c.id}" ${(k.courseIds || []).includes(c.id) ? 'checked' : ''}>${esc(c.soft)}</label>`).join('')}</div></div></div>
    <label class="field"><span>Danh sách sinh viên — mỗi dòng: MSSV [Tab hoặc dấu phẩy] Họ tên</span><textarea class="inp mono" id="cs" rows="9" placeholder="2251010001	Nguyễn Văn A">${esc(txt)}</textarea></label>
    <div class="row"><label class="btn">${icon('upload')}Import từ Excel/CSV<input type="file" id="cx" accept=".xlsx,.xls,.csv" hidden></label><span class="muted" style="font-size:.78rem">Tự nhận cột có tên “MSSV/Mã SV” và “Họ tên/Tên”.</span></div>
    <div class="modal-f">${id && !DEFAULT_CLASSES.find(d => d.id === id) ? `<button class="btn danger" id="del" style="margin-right:auto">Xoá lớp</button>` : ''}<button class="btn" data-close>Huỷ</button><button class="btn pri" id="ok">Lưu lớp</button></div>`, (m, close) => {
    $('#cx', m).onchange = async e => {
      const f = e.target.files[0]; if (!f) return;
      try {
        await loadScript(LIB.xlsx);
        const wb = XLSX.read(await f.arrayBuffer()); const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, defval: '' });
        let hi = rows.findIndex(r => r.some(c => /mssv|mã\s*s/i.test(String(c))));
        let ci = 0, ni = 1;
        if (hi >= 0) { ci = rows[hi].findIndex(c => /mssv|mã\s*s/i.test(String(c))); const nn = rows[hi].findIndex(c => /họ.*tên|^tên|ho ten|họ và tên/i.test(String(c))); ni = nn >= 0 ? nn : ci + 1; }
        const out = rows.slice(hi + 1).filter(r => String(r[ci]).trim()).map(r => String(r[ci]).trim() + '\t' + String(r[ni]).trim());
        $('#cs', m).value = out.join('\n'); toast('Đã đọc ' + out.length + ' sinh viên');
      } catch (er) { toast('Không đọc được file: ' + er.message, true); }
    };
    $('#ok', m).onclick = async () => {
      const name = $('#cn', m).value.trim(); if (!name) { $('#cn', m).classList.add('err'); return; }
      const students = $('#cs', m).value.split('\n').map(l => l.trim()).filter(Boolean).map(l => { const p = l.split(/\t|,|;/); return { mssv: p[0].trim(), name: p.slice(1).join(' ').trim() }; });
      const cid = id || name.replace(/[^A-Za-z0-9_-]/g, '') || uid('L');
      await Store.put('classes', cid, { id: cid, name, students, courseIds: $$('.tags input:checked', m).map(i => i.value) });
      logHistory({ type: 'class', title: (id ? 'Sửa lớp ' : 'Tạo lớp ') + name, changes: [['Sĩ số', id ? String((k.students || []).length) : '', String(students.length)]] });
      close(); toast('Đã lưu lớp ' + name);
    };
    const del = $('#del', m); if (del) del.onclick = async () => { await Store.del('classes', id); close(); toast('Đã xoá lớp'); };
  });
}

/* ===== 3. Bài tập (wizard 4 bước) ===== */
let W = null;
function asgTable(list) {
  if (!list.length) return `<div class="empty card"><b>Chưa có bài tập</b>Tạo bài tập để có deadline, rubric riêng và chính sách AI áp dụng khi chấm.</div>`;
  return `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Bài tập</th><th>Lớp</th><th>Deadline</th><th>Chính sách AI</th><th>Đã nộp</th><th>Trạng thái</th></tr></thead><tbody>${list.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)).map(a => {
    const n = subsArr().filter(s => s.classId === a.classId && s.lessonId === a.lessonId).length;
    return `<tr class="click" onclick="editAssignment('${a.id}')"><td><b>${esc(a.title)}</b><div class="faint" style="font-size:.74rem">${esc(course(a.courseId).soft)} · Bài ${lesson(a.courseId, a.lessonId).no}</div></td><td>${esc(klass(a.classId)?.name || a.classId)}</td><td class="num">${fmtDate(a.deadline)}</td><td><span class="chip acc">Mức ${a.aiLevel}</span></td><td class="num">${n}</td><td><span class="chip ${a.status === 'published' ? 'ok' : ''}">${a.status === 'published' ? 'Đã công bố' : 'Bản nháp'}</span></td></tr>`; }).join('')}</tbody></table></div>`;
}
ROUTES.assignments = (v, refresh) => {
  if (refresh && W) return;
  if (W) return renderWizard(v);
  v.innerHTML = `<div class="page"><div class="page-head"><div class="grow"><h1>Bài tập</h1><p>Tạo đề, rubric và chính sách AI cho từng bài. Khi chấm, màn hình Chấm bài tự lấy rubric và mức AI của bài tập tương ứng.</p></div><button class="btn pri" onclick="newAssignment()">${icon('plus')}Tạo bài tập</button></div>${asgTable(Object.values(S.assignments))}</div>`;
};
function newAssignment(cid) {
  const c = course(cid || (window.G && G.courseId) || 'ps'), l = c.lessons[0];
  W = { step: 1, a: { id: uid('A'), courseId: c.id, lessonId: l.id, classId: classes()[0]?.id || '', title: 'Bài ' + l.no + ': ' + l.name, description: '', deadline: '', formats: c.kind === 'raster' ? 'PSD + JPG' : c.kind === 'vector' ? 'AI + PDF' : 'PDF', ref: '', objective: l.objective, criteria: JSON.parse(JSON.stringify(l.criteria)), aiLevel: 2, evidence: ['source', 'versions', 'declare'], status: 'draft' } };
  go('assignments'); ROUTES.assignments($('#view'));
}
function editAssignment(id) { W = { step: 1, a: JSON.parse(JSON.stringify(S.assignments[id])) }; go('assignments'); ROUTES.assignments($('#view')); }
function renderWizard(v) {
  const a = W.a, c = course(a.courseId);
  const steps = ['Thông tin đề bài', 'Rubric', 'Chính sách AI', 'Xem lại & Công bố'];
  const tot = round2(sum(a.criteria.map(k => k.max || 0)));
  let body = '';
  if (W.step === 1) body = `<div class="grid2">
    <label class="field"><span>Môn học</span><select class="inp" id="wC">${courses().map(x => `<option value="${x.id}" ${x.id === a.courseId ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>
    <label class="field"><span>Bài học (rubric gốc)</span><select class="inp" id="wL">${c.lessons.map(l => `<option value="${l.id}" ${l.id === a.lessonId ? 'selected' : ''}>Bài ${l.no}: ${esc(l.name)}</option>`).join('')}</select></label>
    <label class="field"><span>Lớp</span><select class="inp" id="wK">${classes().map(k => `<option value="${esc(k.id)}" ${k.id === a.classId ? 'selected' : ''}>${esc(k.name)}</option>`).join('')}</select></label>
    <label class="field"><span>Deadline</span><input class="inp" type="datetime-local" id="wD" value="${esc(a.deadline)}"></label>
    <label class="field" style="grid-column:1/-1"><span>Tên bài tập</span><input class="inp" id="wT" value="${esc(a.title)}"></label>
    <label class="field" style="grid-column:1/-1"><span>Mô tả đề bài</span><textarea class="inp" id="wM" rows="4" placeholder="Yêu cầu, kích thước, chủ đề…">${esc(a.description)}</textarea></label>
    <label class="field"><span>Định dạng file yêu cầu</span><input class="inp" id="wF" value="${esc(a.formats)}"></label>
    <div class="field"><span>Ảnh tham khảo minh hoạ đề</span><div class="row"><label class="btn">${icon('upload')}Chọn ảnh<input type="file" id="wR" accept="image/*" hidden></label>${a.ref ? `<img src="${a.ref}" alt="Ảnh tham khảo" style="height:48px;border-radius:4px">` : ''}</div></div></div>`;
  if (W.step === 2) body = `<div class="split" style="grid-template-columns:minmax(0,2fr) minmax(0,1fr)"><div class="sec" style="border:0;padding:0">
    <label class="field"><span>Mục tiêu</span><textarea class="inp" id="wO" rows="2">${esc(a.objective)}</textarea></label>
    <div class="tbl-wrap"><table class="tbl"><thead><tr><th>Tiêu chí</th><th style="width:80px">Điểm tối đa</th><th>Mô tả 4 mức (Xuất sắc / Khá / Đạt / Chưa đạt)</th><th></th></tr></thead><tbody>${a.criteria.map((k, i) => `<tr><td><input class="inp" data-i="${i}" data-f="name" value="${esc(k.name)}"></td><td><input class="inp num" data-i="${i}" data-f="max" value="${fmt(k.max, 2)}" style="text-align:center"></td><td><input class="inp" data-i="${i}" data-f="levels" value="${esc(k.levels || '')}" placeholder="Xuất sắc: … / Khá: … / Đạt: … / Chưa đạt: …"></td><td><button class="btn ghost sm" data-rm="${i}" aria-label="Xoá tiêu chí">${icon('x')}</button></td></tr>`).join('')}</tbody></table></div>
    <div class="row"><button class="btn sm" id="wAdd">${icon('plus')}Thêm tiêu chí</button><button class="btn sm claude" id="wSug">${icon('spark')}Claude gợi ý rubric</button><span id="wSugS" class="thinking" hidden><i></i>Claude đang đọc đề bài…</span></div></div>
    <aside class="card"><div class="eyebrow">Tổng điểm</div><div class="tot ${Math.abs(tot - 10) < .001 ? 'ok' : 'bad'}"><b class="num">${fmt(tot)}</b><small>/ 10</small></div>
    ${Math.abs(tot - 10) < .001 ? '<p class="muted" style="font-size:.8rem">Tổng điểm đúng thang 10.</p>' : `<p style="color:var(--bad);font-size:.8rem;font-weight:600">Tổng đang ${tot > 10 ? 'vượt' : 'thiếu'} ${fmt(Math.abs(10 - tot))} điểm so với thang 10.</p>`}
    <p class="muted" style="font-size:.78rem">Mẹo: mô tả 4 mức giúp Claude chấm nháp sát ý bạn hơn.</p></aside></div>`;
  if (W.step === 3) body = `<div class="split"><div class="lvl">${AI_LEVELS.map(L => `<label><input type="radio" name="lv" value="${L.n}" ${a.aiLevel === L.n ? 'checked' : ''}><div><b>Mức ${L.n} · ${L.name}</b><span class="muted" style="font-size:.82rem">${L.desc}</span></div></label>`).join('')}</div>
    <div class="card"><h3>Bằng chứng bắt buộc khi nộp</h3><div style="margin-top:8px">${EVIDENCE.map(e => `<label class="chk"><input type="checkbox" value="${e.id}" ${a.evidence.includes(e.id) ? 'checked' : ''}>${e.label}</label>`).join('')}</div>
    <p class="muted" style="font-size:.78rem">Khung 5 mức dựa trên AI Assessment Scale. Mức và bằng chứng sẽ hiện trong báo cáo Minh bạch AI của từng bài.</p></div></div>`;
  if (W.step === 4) { const L = AI_LEVELS[a.aiLevel - 1]; body = `<div class="card" style="max-width:760px"><div class="eyebrow">Sinh viên sẽ thấy</div><h2 style="margin:4px 0">${esc(a.title)}</h2>
    <p class="muted" style="margin:0 0 8px">${esc(c.name)} · Lớp ${esc(klass(a.classId)?.name || '')} · Hạn nộp: <b>${a.deadline ? new Date(a.deadline).toLocaleString('vi-VN') : 'chưa đặt'}</b> · File: ${esc(a.formats)}</p>
    ${a.ref ? `<img src="${a.ref}" alt="Ảnh tham khảo" style="max-height:200px;border-radius:6px">` : ''}
    <p style="white-space:pre-wrap">${esc(a.description || 'Chưa có mô tả.')}</p><p><b>${esc(a.objective)}</b></p>
    <div class="tbl-wrap"><table class="tbl"><thead><tr><th>Tiêu chí</th><th>Điểm</th></tr></thead><tbody>${a.criteria.map(k => `<tr><td>${esc(k.name)}${k.levels ? `<div class="faint" style="font-size:.74rem">${esc(k.levels)}</div>` : ''}</td><td class="num">${fmt(k.max)}</td></tr>`).join('')}<tr><td><b>Tổng</b></td><td class="num"><b>${fmt(tot)}</b></td></tr></tbody></table></div>
    <p style="margin-top:12px"><span class="chip acc">Chính sách AI · Mức ${L.n}: ${L.name}</span> ${L.desc}</p>
    <p class="muted" style="font-size:.84rem">Cần nộp kèm: ${a.evidence.map(id => EVIDENCE.find(e => e.id === id).label).join('; ') || 'không yêu cầu'}.</p></div>`; }
  v.innerHTML = `<div class="page" data-editing><div class="page-head"><div class="grow"><a href="#assignments" id="wBack" class="muted" style="font-size:.8rem;text-decoration:none">← Danh sách bài tập</a><h1>${S.assignments[a.id] ? 'Sửa bài tập' : 'Tạo bài tập'}</h1></div></div>
    <div class="steps">${steps.map((s, i) => `${i ? '<span class="ln"></span>' : ''}<span class="st ${W.step === i + 1 ? 'on' : W.step > i + 1 ? 'done' : ''}"><i>${i + 1}</i>${s}</span>`).join('')}</div>
    <section class="card">${body}</section>
    <div class="row" style="justify-content:space-between"><div class="row">${S.assignments[a.id] ? `<button class="btn danger" id="wDel">Xoá bài tập</button>` : ''}</div><div class="row"><button class="btn" id="wPrev" ${W.step === 1 ? 'disabled' : ''}>Quay lại</button>
    ${W.step < 4 ? `<button class="btn pri" id="wNext">Tiếp</button>` : `<button class="btn" id="wDraft">Lưu nháp</button><button class="btn pri" id="wPub">Công bố</button>`}</div></div></div>`;
  const collect = () => {
    if (W.step === 1) {
      const nc = $('#wC').value; if (nc !== a.courseId) { a.courseId = nc; const l = course(nc).lessons[0]; a.lessonId = l.id; a.objective = l.objective; a.criteria = JSON.parse(JSON.stringify(l.criteria)); a.title = 'Bài ' + l.no + ': ' + l.name; return; }
      const nl = $('#wL').value; if (nl !== a.lessonId) { a.lessonId = nl; const l = lesson(a.courseId, nl); a.objective = l.objective; a.criteria = JSON.parse(JSON.stringify(l.criteria)); a.title = 'Bài ' + l.no + ': ' + l.name; return; }
      a.classId = $('#wK').value; a.deadline = $('#wD').value; a.title = $('#wT').value; a.description = $('#wM').value; a.formats = $('#wF').value;
    }
    if (W.step === 2) { a.objective = $('#wO').value; $$('[data-i]').forEach(inp => { const k = a.criteria[+inp.dataset.i]; if (inp.dataset.f === 'max') k.max = parseNum(inp.value) || 0; else k[inp.dataset.f] = inp.value; }); }
    if (W.step === 3) { a.aiLevel = +($('input[name=lv]:checked')?.value || 1); a.evidence = $$('.card input[type=checkbox]:checked').map(i => i.value); }
  };
  if (W.step === 1) { ['#wC', '#wL'].forEach(s => $(s).onchange = () => { collect(); renderWizard(v); }); $('#wR').onchange = async e => { const f = e.target.files[0]; if (f) { a.ref = await thumbDataUrl(f, 640); collect(); renderWizard(v); } }; }
  if (W.step === 2) {
    $$('[data-i]').forEach(i => i.onchange = () => { collect(); renderWizard(v); });
    $$('[data-rm]').forEach(b => b.onclick = () => { collect(); a.criteria.splice(+b.dataset.rm, 1); renderWizard(v); });
    $('#wAdd').onclick = () => { collect(); a.criteria.push({ name: 'Tiêu chí mới', max: 1, levels: '' }); renderWizard(v); };
    $('#wSug').onclick = async () => { collect(); $('#wSugS').hidden = false; $('#wSug').disabled = true; const r = await claudeRubric(c, lesson(a.courseId, a.lessonId), a.description, true); if (r) { a.objective = r.objective || a.objective; a.criteria = r.criteria; } renderWizard(v); };
  }
  $('#wBack').onclick = e => { e.preventDefault(); W = null; ROUTES.assignments(v); };
  $('#wPrev').onclick = () => { collect(); W.step--; renderWizard(v); };
  const nx = $('#wNext'); if (nx) nx.onclick = () => { collect(); W.step++; renderWizard(v); };
  const save = async st => { a.status = st; a.createdAt ||= Date.now(); await Store.put('assignments', a.id, a); toast(st === 'published' ? 'Đã công bố bài tập' : 'Đã lưu nháp'); W = null; ROUTES.assignments(v); };
  const d = $('#wDraft'); if (d) d.onclick = () => save('draft');
  const p = $('#wPub'); if (p) p.onclick = () => save('published');
  const del = $('#wDel'); if (del) del.onclick = () => confirmBox('Xoá bài tập “' + a.title + '”? Điểm đã chấm vẫn được giữ.', 'Xoá', async () => { await Store.del('assignments', a.id); W = null; ROUTES.assignments(v); }, true);
}

/* ===== 4. Hàng chờ chấm ===== */
const QF = { cls: '', les: '', st: 'open', flag: false };
let QSEL = new Set(), BATCH = null;
function evidencePct(s) {
  const a = findAssignment(s.classId, s.lessonId); const req = a?.evidence || ['source', 'versions', 'declare'];
  if (!req.length) return 100;
  const have = evidenceHave(s);
  return Math.round(100 * req.filter(r => have[r]).length / req.length);
}
function evidenceHave(s) {
  const files = s.files || [];
  return { source: files.some(f => /\.(psd|psb|ai|indd|fig|aep|sketch)$/i.test(f.name) || f.kind === 'source'), sketch: files.some(f => f.kind === 'sketch'), versions: files.filter(f => f.kind === 'version').length >= 2, declare: !!(s.ai?.declaration || '').trim(), reflect: !!(s.ai?.reflection || '').trim() };
}
ROUTES.queue = (v, refresh) => {
  if (refresh && BATCH) { paintBatch(); }
  let list = subsArr();
  if (QF.cls) list = list.filter(s => s.classId === QF.cls);
  if (QF.les) list = list.filter(s => s.lessonId === QF.les);
  if (QF.st === 'open') list = list.filter(s => s.status !== 'duyet'); else if (QF.st) list = list.filter(s => s.status === QF.st);
  if (QF.flag) list = list.filter(s => (s.flags || []).length || ['vang', 'do'].includes(s.ai?.level));
  const allLessons = courses().flatMap(c => c.lessons.map(l => ({ id: l.id, t: c.soft + ' · Bài ' + l.no + ': ' + l.name })));
  v.innerHTML = `<div class="page"><div class="page-head"><div class="grow"><h1>Hàng chờ chấm</h1><p>Nhận bài nộp của cả lớp, cho Claude chấm nháp hàng loạt, rồi mở từng bài để duyệt.</p></div>
    <button class="btn" id="qIn">${icon('upload')}Nhận bài nộp</button><button class="btn claude" id="qBatch">${icon('spark')}Chấm hàng loạt bằng Claude</button></div>
    <div class="row" data-keep>
      <label class="field"><span>Lớp</span><select class="inp" id="fC"><option value="">Tất cả</option>${classes().map(k => `<option value="${esc(k.id)}" ${QF.cls === k.id ? 'selected' : ''}>${esc(k.name)}</option>`).join('')}</select></label>
      <label class="field" style="min-width:240px"><span>Bài tập</span><select class="inp" id="fL"><option value="">Tất cả</option>${allLessons.map(l => `<option value="${l.id}" ${QF.les === l.id ? 'selected' : ''}>${esc(l.t)}</option>`).join('')}</select></label>
      <label class="field"><span>Trạng thái</span><select class="inp" id="fS">${[['open', 'Chưa duyệt'], ['', 'Tất cả'], ['cho', 'Chưa chấm'], ['nhap', 'Nháp Claude'], ['duyet', 'Đã duyệt']].map(([k, t]) => `<option value="${k}" ${QF.st === k ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
      <label class="chk" style="height:34px;align-items:center"><input type="checkbox" id="fF" ${QF.flag ? 'checked' : ''}>Chỉ bài có cờ</label>
    </div>
    <div id="batchBox"></div>
    ${list.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th><input type="checkbox" id="qAll" aria-label="Chọn tất cả"></th><th>Sinh viên</th><th>Nộp lúc</th><th>Bằng chứng</th><th>Điểm Claude</th><th>Điểm GV</th><th>Cờ cần xem kỹ</th><th>Trạng thái</th></tr></thead><tbody>${list.map(s => {
      const l = lesson(s.courseId, s.lessonId), st = STATUS[s.status] || STATUS.cho, ev = evidencePct(s);
      const why = [...(s.flagNotes || []), ...(s.flags || []).map(id => flagsFor(s.courseId).find(f => f.id === id)?.label).filter(Boolean)].slice(0, 2).join('; ');
      return `<tr class="click" data-id="${s.id}"><td onclick="event.stopPropagation()"><input type="checkbox" data-sel="${s.id}" ${QSEL.has(s.id) ? 'checked' : ''} aria-label="Chọn"></td>
      <td><div class="row" style="gap:10px;flex-wrap:nowrap">${s.thumb ? `<img src="${s.thumb}" alt="" style="width:44px;height:44px;object-fit:cover;border-radius:4px;background:var(--surface-2)">` : '<span style="width:44px;height:44px;background:var(--surface-2);border-radius:4px;display:inline-block"></span>'}<div><b>${esc(s.name || '—')}</b>${s.sample ? ' <span class="chip">mẫu</span>' : ''}<div class="faint" style="font-size:.74rem">${esc(s.mssv || '')} · ${esc(s.className || '')} · Bài ${l.no}</div></div></div></td>
      <td class="num" style="font-size:.78rem">${fmtTime(s.createdAt)} ${s.late ? '<span class="chip warn">Trễ</span>' : ''}</td>
      <td><div class="row" style="gap:6px;flex-wrap:nowrap;align-items:center"><div class="bar" style="width:70px"><i style="width:${ev}%;background:${ev < 50 ? 'var(--bad)' : ev < 100 ? 'var(--warn)' : 'var(--ok)'}"></i></div><span class="num faint" style="font-size:.74rem">${ev}%</span></div></td>
      <td class="num" style="color:var(--claude)">${fmt(s.claudeTotal)}</td><td class="num"><b>${s.status === 'duyet' ? fmt(subTotal(s)) : '–'}</b></td>
      <td style="max-width:260px;font-size:.78rem">${s.ai?.percent != null ? `<span class="chip ${pctClass(s.ai.percent)}">AI ${s.ai.percent}%</span> ` : ''}${why ? `<span style="color:var(--bad)">⚑ ${esc(why)}</span>` : (s.ai?.percent == null ? '<span class="faint">—</span>' : '')}</td>
      <td><span class="chip ${st[1]}">${st[0]}</span></td></tr>`; }).join('')}</tbody></table></div>`
      : `<div class="empty card"><b>Hàng chờ trống</b>Bấm “Nhận bài nộp” để thêm bài của cả lớp. Tên file chứa MSSV (VD: 2251010001_NguyenVanA.jpg) sẽ được tự khớp với danh sách lớp.</div>`}
  </div>`;
  $('#fC').onchange = e => { QF.cls = e.target.value; ROUTES.queue(v); };
  $('#fL').onchange = e => { QF.les = e.target.value; ROUTES.queue(v); };
  $('#fS').onchange = e => { QF.st = e.target.value; ROUTES.queue(v); };
  $('#fF').onchange = e => { QF.flag = e.target.checked; ROUTES.queue(v); };
  $$('tr[data-id]', v).forEach(tr => tr.onclick = () => openSub(tr.dataset.id));
  $$('[data-sel]', v).forEach(c => c.onchange = () => { c.checked ? QSEL.add(c.dataset.sel) : QSEL.delete(c.dataset.sel); });
  const all = $('#qAll'); if (all) all.onchange = () => { $$('[data-sel]', v).forEach(c => { c.checked = all.checked; all.checked ? QSEL.add(c.dataset.sel) : QSEL.delete(c.dataset.sel); }); };
  $('#qIn').onclick = intakeModal;
  $('#qBatch').onclick = () => startBatch(list);
  paintBatch();
};
function paintBatch() {
  const b = $('#batchBox'); if (!b) return;
  if (!BATCH) { b.innerHTML = ''; return; }
  b.innerHTML = `<div class="card row" style="align-items:center"><span class="thinking"><i></i>Claude đang chấm nháp ${BATCH.done + 1}/${BATCH.ids.length}: ${esc(BATCH.cur || '')}</span><div class="bar" style="flex:1;min-width:120px"><i style="width:${100 * BATCH.done / BATCH.ids.length}%"></i></div><button class="btn sm" id="bStop">Dừng</button></div>`;
  $('#bStop').onclick = () => { BATCH.stop = true; BATCH.ctl?.abort(); };
}
async function startBatch(list) {
  if (BATCH) return;
  if (!CAP.sample) { toast('Claude chưa sẵn sàng trong chế độ xem này.', true); return; }
  let ids = [...QSEL].filter(id => S.subs[id] && S.subs[id].status !== 'duyet');
  if (!ids.length) ids = list.filter(s => s.status === 'cho').map(s => s.id);
  if (!ids.length) { toast('Không có bài “Chưa chấm” nào để chạy nháp.'); return; }
  BATCH = { ids, done: 0, stop: false }; paintBatch();
  let ok = 0;
  for (const id of ids) {
    if (BATCH.stop) break;
    const s = S.subs[id]; BATCH.cur = s.name || s.mssv; paintBatch();
    try {
      const pages = await loadSubPages(s);
      if (!pages.length) throw { code: 'nofile' };
      BATCH.ctl = new AbortController();
      const res = await claudeGrade(ctxFromSub(s), pages, BATCH.ctl.signal);
      const merged = applyClaudeToSub(s, res);
      await Store.put('subs', id, merged); ok++;
    } catch (e) { if (e.code === 'cancelled') break; if (e.code === 'not_granted' || e.code === 'sampling_disabled') { toast('Claude không được phép chạy ở đây.', true); break; } if (e.code === 'rate_limited') { toast('Claude đang quá tải giới hạn sử dụng — hãy thử lại sau.', true); break; } console.warn(e); toast('Bỏ qua bài của ' + (s.name || s.mssv) + ': ' + (e.code === 'nofile' ? 'không mở được file' : (e.message || e.code)), true); }
    BATCH.done++;
  }
  BATCH = null; paintBatch(); if (ok) logHistory({ type: 'claude', title: 'Claude chấm nháp hàng loạt ' + ok + ' bài' }); toast('Claude đã chấm nháp ' + ok + ' bài'); if (curRoute === 'queue') ROUTES.queue($('#view'));
}
function intakeModal() {
  const g = window.G || {};
  let files = [];
  modal(`<h2>Nhận bài nộp</h2>
    <div class="grid3"><label class="field"><span>Lớp</span><select class="inp" id="iK">${classes().map(k => `<option value="${esc(k.id)}" ${g.classId === k.id ? 'selected' : ''}>${esc(k.name)}</option>`).join('')}</select></label>
    <label class="field"><span>Môn</span><select class="inp" id="iC">${courses().map(c => `<option value="${c.id}" ${g.courseId === c.id ? 'selected' : ''}>${esc(c.soft)}</option>`).join('')}</select></label>
    <label class="field"><span>Bài học</span><select class="inp" id="iL"></select></label></div>
    <label class="btn" style="align-self:flex-start">${icon('upload')}Chọn file (ảnh, PDF, PSD, AI — tối đa 20 MB/file)<input type="file" id="iF" multiple hidden accept=".jpg,.jpeg,.png,.webp,.gif,.pdf,.ai,.psd,.psb,.svg"></label>
    <div id="iMap"></div><div id="iProg" class="thinking" hidden><i></i><span>Đang xử lý…</span></div>
    <div class="modal-f"><button class="btn" data-close>Huỷ</button><button class="btn pri" id="iOk" disabled>Nhận bài</button></div>`, (m, close) => {
    const fillL = () => { const c = course($('#iC', m).value); $('#iL', m).innerHTML = c.lessons.map(l => `<option value="${l.id}" ${g.lessonId === l.id ? 'selected' : ''}>Bài ${l.no}: ${esc(l.name)}</option>`).join(''); };
    fillL(); $('#iC', m).onchange = fillL;
    const roster = () => klass($('#iK', m).value)?.students || [];
    const draw = () => {
      $('#iOk', m).disabled = !files.length;
      $('#iMap', m).innerHTML = files.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>File</th><th>MSSV</th><th>Họ tên</th><th>Loại</th></tr></thead><tbody>${files.map((f, i) => `<tr><td style="font-size:.78rem;max-width:180px;overflow:hidden;text-overflow:ellipsis">${esc(f.file.name)}<div class="faint">${(f.file.size / 1048576).toFixed(1)} MB</div></td><td><input class="inp num" data-k="mssv" data-i="${i}" value="${esc(f.mssv)}" style="width:120px"></td><td><input class="inp" data-k="name" data-i="${i}" value="${esc(f.name)}"></td><td><select class="inp" data-k="kind" data-i="${i}">${KINDS.map(([k, t]) => `<option value="${k}" ${f.kind === k ? 'selected' : ''}>${t}</option>`).join('')}</select></td></tr>`).join('')}</tbody></table></div><p class="muted" style="font-size:.76rem;margin:6px 0 0">Các file cùng MSSV được gộp thành một bài nộp.</p>` : '';
      $$('[data-k]', m).forEach(inp => inp.onchange = () => { files[+inp.dataset.i][inp.dataset.k] = inp.value; if (inp.dataset.k === 'mssv') { const st = roster().find(s => s.mssv === inp.value.trim()); if (st) { files[+inp.dataset.i].name = st.name; draw(); } } });
    };
    $('#iF', m).onchange = e => {
      const r = roster();
      for (const file of e.target.files) {
        if (file.size > 20 * 1048576) { toast(file.name + ' vượt quá 20 MB — bỏ qua.', true); continue; }
        const base = file.name.replace(/\.[^.]+$/, ''); const mm = base.match(/\d{6,}/); const mssv = mm ? mm[0] : '';
        const st = r.find(s => s.mssv === mssv) || r.find(s => base.toLowerCase().includes(s.name.toLowerCase().replace(/\s+/g, '')));
        const kind = /sketch|phac/i.test(base) ? 'sketch' : /v\d|ban\s?\d|draft|nhap/i.test(base) ? 'version' : /\.(psd|psb|ai)$/i.test(file.name) ? 'source' : 'final';
        files.push({ file, mssv: st?.mssv || mssv, name: st?.name || base.replace(/[_-]+/g, ' ').replace(/\d{6,}/, '').trim(), kind });
      }
      draw();
    };
    $('#iOk', m).onclick = async () => {
      $('#iOk', m).disabled = true; $('#iProg', m).hidden = false;
      const groups = {}; files.forEach(f => { const k = f.mssv || f.name || uid(); (groups[k] ||= []).push(f); });
      const cid = $('#iC', m).value, lid = $('#iL', m).value, kid = $('#iK', m).value; const asg = findAssignment(kid, lid);
      let n = 0;
      for (const key in groups) {
        const gfs = groups[key]; $('#iProg span', m).textContent = `Đang xử lý ${++n}/${Object.keys(groups).length}: ${gfs[0].name}`;
        const recs = []; let thumb = '', signals = [];
        for (const f of gfs) {
          const rec = { id: uid('F'), name: f.file.name, type: f.file.type, size: f.file.size, kind: f.kind };
          FILE_CACHE[rec.id] = f.file;
          try { const pr = await processFile(f.file, { quick: true }); if (!thumb && pr.pages[0]) thumb = canvasThumb(pr.pages[0].canvas, 200); rec.signals = pr.signals; signals.push(pr.signals); } catch (e) { console.warn(e); }
          await uploadAsset(rec, f.file);
          recs.push(rec);
        }
        const id = uid('S'); const created = Date.now();
        await Store.put('subs', id, { id, classId: kid, className: klass(kid)?.name || kid, courseId: cid, lessonId: lid, mssv: gfs[0].mssv, name: gfs[0].name, files: recs, thumb, status: 'cho', createdAt: created, late: !!(asg?.deadline && created > new Date(asg.deadline).getTime()), flagNotes: autoFlagNotes(signals), ai: { level: '', declaration: '', reflection: '' } });
      }
      close(); toast('Đã nhận ' + Object.keys(groups).length + ' bài nộp'); if (curRoute === 'queue') ROUTES.queue($('#view'));
    };
  });
}
const KINDS = [['final', 'Bản cuối'], ['source', 'File gốc'], ['version', 'Bản trung gian'], ['sketch', 'Phác thảo']];

/* ===== 6. Minh bạch AI (tổng quan) ===== */
ROUTES.transparency = (v) => {
  const list = subsArr().filter(s => s.ai?.level || (s.flags || []).length || (s.flagNotes || []).length);
  const cnt = k => list.filter(s => s.ai?.level === k).length;
  v.innerHTML = `<div class="page"><div class="page-head"><div class="grow"><h1>Báo cáo minh bạch AI</h1><p>Tổng hợp bằng chứng và tín hiệu kỹ thuật của từng bài. Báo cáo chỉ đưa ra gợi ý mức cần xem xét, không kết luận gian lận.</p></div></div>
  <div class="row"><span class="chip ok">Xanh: ${cnt('xanh')}</span><span class="chip warn">Vàng: ${cnt('vang')}</span><span class="chip bad">Đỏ: ${cnt('do')}</span></div>
  ${list.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Sinh viên</th><th>Bài</th><th>Chính sách</th><th>Bằng chứng</th><th>Tín hiệu kỹ thuật</th><th>Chỉ số nghi vấn</th></tr></thead><tbody>${list.map(s => {
    const l = lesson(s.courseId, s.lessonId), a = findAssignment(s.classId, s.lessonId), lv = LEVEL[s.ai?.level], h = evidenceHave(s);
    return `<tr class="click" onclick="openSub('${s.id}','ai')"><td><b>${esc(s.name)}</b><div class="faint" style="font-size:.74rem">${esc(s.mssv)} · ${esc(s.className)}</div></td><td>Bài ${l.no}</td><td><span class="chip acc">Mức ${s.ai?.policy || a?.aiLevel || '?'}</span></td>
    <td style="font-size:.76rem">${EVIDENCE.slice(0, 3).map(e => `${h[e.id] ? '✓' : '✗'} ${e.label.split(' (')[0]}`).join('<br>')}</td><td style="font-size:.76rem;max-width:280px">${esc([...(s.flagNotes || []), ...(s.flags || []).map(id => flagsFor(s.courseId).find(f => f.id === id)?.label)].filter(Boolean).join('; ') || '—')}</td>
    <td>${lv ? `<span class="chip ${lv[1]}">${lv[0]}${s.ai?.percent != null ? ' · ' + s.ai.percent + '%' : ''}</span>` : '<span class="faint">chưa đánh giá</span>'}</td></tr>`; }).join('')}</tbody></table></div>` : `<div class="empty card"><b>Chưa có báo cáo nào</b>Báo cáo được tạo khi Claude phân tích bài hoặc khi bạn đánh dấu “Nghi vấn lạm dụng AI” trong màn hình chấm.</div>`}
  <p class="disclaim">Đây là gợi ý, không phải kết luận.</p></div>`;
};

/* ===== 7. Vấn đáp (tổng quan) ===== */
ROUTES.viva = (v) => {
  const list = subsArr().filter(s => (s.flags || []).length || ['vang', 'do'].includes(s.ai?.level) || (s.viva?.items || []).length);
  const OUT = { '': ['Chưa vấn đáp', ''], ok: ['Xác nhận tự làm', 'ok'], more: ['Cần nộp bổ sung', 'warn'], board: ['Chuyển hội đồng', 'bad'] };
  v.innerHTML = `<div class="page"><div class="page-head"><div class="grow"><h1>Vấn đáp</h1><p>Danh sách sinh viên cần chứng minh quy trình. Mỗi bài có bộ câu hỏi do Claude soạn từ cờ nghi vấn và tín hiệu kỹ thuật, kèm thao tác kiểm tra trực tiếp.</p></div></div>
  ${list.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Sinh viên</th><th>Bài</th><th>Lý do</th><th>Câu hỏi</th><th>Kết quả</th></tr></thead><tbody>${list.map(s => {
    const l = lesson(s.courseId, s.lessonId), o = OUT[s.viva?.outcome || ''];
    return `<tr class="click" onclick="openSub('${s.id}','viva')"><td><b>${esc(s.name)}</b><div class="faint" style="font-size:.74rem">${esc(s.mssv)} · ${esc(s.className)}</div></td><td>Bài ${l.no}: ${esc(l.name)}</td>
    <td style="font-size:.78rem;max-width:300px">${esc((s.flags || []).map(id => flagsFor(s.courseId).find(f => f.id === id)?.label).filter(Boolean).join('; ') || (s.ai?.level ? 'Mức ' + LEVEL[s.ai.level][0] : ''))}</td>
    <td class="num">${(s.viva?.items || []).length}</td><td><span class="chip ${o[1]}">${o[0]}</span></td></tr>`; }).join('')}</tbody></table></div>` : `<div class="empty card"><b>Chưa có sinh viên nào cần vấn đáp</b>Khi bạn tick “Nghi vấn lạm dụng AI” hoặc Claude đánh giá mức Vàng/Đỏ, sinh viên sẽ xuất hiện ở đây.</div>`}</div>`;
};

/* ===== 8. Thống kê & Xuất điểm ===== */
const SF = { cls: '524TKD', course: 'ps', les: '', st: 'duyet' };
ROUTES.stats = (v) => {
  const c = course(SF.course);
  let list = subsArr().filter(s => s.courseId === c.id);
  if (SF.cls) list = list.filter(s => s.classId === SF.cls);
  if (SF.les) list = list.filter(s => s.lessonId === SF.les);
  if (SF.st) list = list.filter(s => s.status === SF.st);
  const tots = list.map(subTotal).filter(x => x != null);
  const bins = Array(10).fill(0); tots.forEach(t => bins[Math.min(9, Math.floor(t))]++);
  let crit = '', dev = '';
  if (SF.les) {
    const l = lesson(c.id, SF.les);
    const avgPct = l.criteria.map((k, i) => { const xs = list.map(s => s.criteria?.[i]?.score ?? null).filter(x => x != null); return xs.length ? 100 * mean(xs) / k.max : 0; });
    const devs = l.criteria.map((k, i) => { const xs = list.filter(s => s.criteria?.[i]?.claude != null && s.criteria?.[i]?.score != null).map(s => Math.abs(s.criteria[i].score - s.criteria[i].claude)); return xs.length ? mean(xs) : 0; });
    const lbl = l.criteria.map((k, i) => 'TC' + (i + 1));
    crit = `<section class="card"><div class="card-h"><h2>Điểm trung bình theo tiêu chí</h2><span class="muted" style="font-size:.78rem">% so với điểm tối đa</span></div>${barChart({ labels: lbl, values: avgPct, max: 100, unit: '%', fmtV: v => fmt(v, 0) })}<ol style="font-size:.78rem;color:var(--muted);margin:6px 0 0;padding-left:20px">${l.criteria.map((k, i) => `<li>${esc(k.name)} — <b class="num">${fmt(avgPct[i], 0)}%</b></li>`).join('')}</ol></section>`;
    dev = `<section class="card"><div class="card-h"><h2>Độ lệch điểm Claude so với giảng viên</h2><span class="muted" style="font-size:.78rem">trung bình |GV − Claude|</span></div>${barChart({ labels: lbl, values: devs, max: Math.max(.5, ...devs), color: 'bc' })}<p class="muted" style="font-size:.8rem;margin:6px 0 0">${devs.some(d => d > .5) ? 'Tiêu chí ' + devs.map((d, i) => d > .5 ? 'TC' + (i + 1) : null).filter(Boolean).join(', ') + ' lệch trên 0,5 điểm — nên bổ sung “Mô tả 4 mức” cho tiêu chí này trong Thư viện rubric để Claude chấm sát hơn.' : 'Claude đang chấm khá sát với bạn ở mọi tiêu chí.'}</p></section>`;
  } else {
    const per = c.lessons.map(l => mean(list.filter(s => s.lessonId === l.id).map(subTotal).filter(x => x != null)) || 0);
    crit = `<section class="card"><div class="card-h"><h2>Điểm trung bình theo bài</h2><span class="muted" style="font-size:.78rem">chọn một bài để xem theo tiêu chí</span></div>${barChart({ labels: c.lessons.map(l => 'B' + l.no), values: per, max: 10 })}</section>`;
  }
  v.innerHTML = `<div class="page"><div class="page-head"><div class="grow"><h1>Thống kê &amp; Xuất điểm</h1><p>Phân bố điểm của lớp, điểm yếu chung theo tiêu chí và độ lệch giữa Claude với bạn để hiệu chỉnh hướng dẫn chấm.</p></div>
    <button class="btn pri" id="xls">${icon('down')}Xuất Excel bảng điểm</button></div>
    <div class="row"><label class="field"><span>Lớp</span><select class="inp" id="sK"><option value="">Tất cả</option>${classes().map(k => `<option value="${esc(k.id)}" ${SF.cls === k.id ? 'selected' : ''}>${esc(k.name)}</option>`).join('')}</select></label>
    <label class="field"><span>Môn</span><select class="inp" id="sC">${courses().map(x => `<option value="${x.id}" ${x.id === c.id ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>
    <label class="field" style="min-width:220px"><span>Bài</span><select class="inp" id="sL"><option value="">Cả môn</option>${c.lessons.map(l => `<option value="${l.id}" ${SF.les === l.id ? 'selected' : ''}>Bài ${l.no}: ${esc(l.name)}</option>`).join('')}</select></label>
    <label class="field"><span>Trạng thái</span><select class="inp" id="sS"><option value="duyet" ${SF.st === 'duyet' ? 'selected' : ''}>Đã duyệt</option><option value="" ${SF.st === '' ? 'selected' : ''}>Tất cả</option></select></label></div>
    <div class="stat-grid"><div class="stat"><b class="num">${tots.length}</b><span>Bài trong bộ lọc</span></div><div class="stat"><b class="num">${fmt(mean(tots))}</b><span>Điểm trung bình</span></div><div class="stat"><b class="num">${tots.length ? fmt(Math.max(...tots)) : '–'}</b><span>Cao nhất</span></div><div class="stat"><b class="num">${tots.filter(t => t < 5).length}</b><span>Dưới 5 điểm</span></div></div>
    <div class="split" style="grid-template-columns:repeat(2,minmax(0,1fr))"><section class="card"><div class="card-h"><h2>Phân bố điểm của lớp</h2><span class="muted" style="font-size:.78rem">số bài theo khoảng điểm</span></div>${tots.length ? barChart({ labels: bins.map((_, i) => i + '–' + (i + 1)), values: bins, max: Math.max(4, Math.ceil(Math.max(...bins) / 4) * 4), fmtV: v => v + ' bài' }) : '<div class="empty">Chưa có điểm trong bộ lọc này.</div>'}</section>${crit}</div>
    ${dev}
    ${syncHtml(c)}</div>`;
  $('#sK').onchange = e => { SF.cls = e.target.value; ROUTES.stats(v); };
  $('#sC').onchange = e => { SF.course = e.target.value; SF.les = ''; ROUTES.stats(v); };
  $('#sL').onchange = e => { SF.les = e.target.value; ROUTES.stats(v); };
  $('#sS').onchange = e => { SF.st = e.target.value; ROUTES.stats(v); };
  $('#xls').onclick = () => exportExcel(list, c);
  bindSync(v, c);
};
async function exportExcel(list, c) {
  try { await loadScript(LIB.xlsx); } catch { toast('Không tải được thư viện Excel.', true); return; }
  const wb = XLSX.utils.book_new();
  const byLesson = {}; list.forEach(s => (byLesson[s.lessonId] ||= []).push(s));
  const roster = {}; list.forEach(s => { roster[s.mssv + '|' + s.classId] = { mssv: s.mssv, name: s.name, cls: s.className }; });
  const lessonsUsed = c.lessons.filter(l => byLesson[l.id]);
  const head = ['STT', 'MSSV', 'Họ và tên', 'Lớp', ...lessonsUsed.map(l => 'Bài ' + l.no), 'Trung bình'];
  const rows = Object.values(roster).sort((a, b) => a.mssv.localeCompare(b.mssv)).map((r, i) => {
    const sc = lessonsUsed.map(l => { const s = (byLesson[l.id] || []).find(x => x.mssv === r.mssv && x.className === r.cls); return s ? subTotal(s) : ''; });
    const nums = sc.filter(x => x !== ''); return [i + 1, r.mssv, r.name, r.cls, ...sc, nums.length ? round2(mean(nums)) : ''];
  });
  const ws = XLSX.utils.aoa_to_sheet([[S.settings.unit], ['BẢNG ĐIỂM — ' + c.name.toUpperCase()], ['Giảng viên: ' + S.settings.teacher + ' · Xuất ngày ' + fmtDate(Date.now())], [], head, ...rows]);
  ws['!cols'] = [{ wch: 5 }, { wch: 14 }, { wch: 26 }, { wch: 10 }, ...lessonsUsed.map(() => ({ wch: 8 })), { wch: 11 }];
  XLSX.utils.book_append_sheet(wb, ws, 'Bảng điểm tổng hợp');
  lessonsUsed.forEach(l => {
    const h = ['STT', 'MSSV', 'Họ và tên', 'Lớp', ...l.criteria.map((k, i) => 'TC' + (i + 1) + ' (' + k.max + ')'), 'Tổng GV', 'Tổng Claude', 'Mức AI', 'Cờ nghi vấn', 'Nhận xét'];
    const r = (byLesson[l.id] || []).sort((a, b) => (a.mssv || '').localeCompare(b.mssv || '')).map((s, i) => [i + 1, s.mssv, s.name, s.className, ...l.criteria.map((k, j) => s.criteria?.[j]?.score ?? ''), subTotal(s), s.claudeTotal ?? '', s.ai?.level ? LEVEL[s.ai.level][0] : '', (s.flags || []).map(id => flagsFor(s.courseId).find(f => f.id === id)?.label).join('; '), (s.comment || '') + (s.ultimatum ? '\n' + s.ultimatum : '')]);
    const w = XLSX.utils.aoa_to_sheet([['Bài ' + l.no + ': ' + l.name], l.criteria.map((k, i) => 'TC' + (i + 1) + ': ' + k.name), [], h, ...r]);
    w['!cols'] = [{ wch: 5 }, { wch: 14 }, { wch: 24 }, { wch: 9 }, ...l.criteria.map(() => ({ wch: 9 })), { wch: 9 }, { wch: 11 }, { wch: 8 }, { wch: 30 }, { wch: 60 }];
    XLSX.utils.book_append_sheet(wb, w, ('Bai ' + l.no).slice(0, 31));
  });
  const buf = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
  await saveFile('BangDiem_' + (SF.cls || 'TatCa') + '_' + c.soft + '.xlsx', new Blob([buf]));
}

/* ===== 9. Thư viện rubric & Cài đặt ===== */
let LIBE = null;
ROUTES.library = (v, refresh) => {
  if (refresh && LIBE?.dirty) return;
  const cid = location.hash.split('.')[1] || LIBE?.cid || 'ps';
  if (!LIBE || LIBE.cid !== cid || !LIBE.dirty) LIBE = { cid, c: JSON.parse(JSON.stringify(course(cid))), open: LIBE?.open ?? 0, dirty: false };
  const c = LIBE.c, st = S.settings;
  v.innerHTML = `<div class="page" data-editing><div class="page-head"><div class="grow"><h1>Thư viện rubric &amp; Cài đặt</h1><p>Mục tiêu, tiêu chí và nhận xét nhanh của từng bài. Chỉnh ở đây sẽ áp dụng cho các lần chấm sau.</p></div></div>
  <div class="tabs">${courses().map(x => `<button aria-selected="${x.id === cid}" data-c="${x.id}">${esc(x.soft)}</button>`).join('')}</div>
  <div class="row" style="justify-content:space-between"><div><h2>${esc(c.name)}</h2><span class="muted" style="font-size:.8rem">${S.dbCourses[c.id] ? 'Đã tuỳ chỉnh' : 'Đang dùng bản mẫu'}</span></div>
  <div class="row">${S.dbCourses[c.id] ? `<button class="btn ghost" id="lReset">Khôi phục bản mẫu</button>` : ''}<button class="btn pri" id="lSave" ${LIBE.dirty ? '' : 'disabled'}>${icon('save')}Lưu thư viện môn</button></div></div>
  <section class="card"><div class="grid2"><label class="field"><span>Nhận xét nhanh “Tốt” (cả môn, phân cách bằng dấu phẩy)</span><textarea class="inp" id="cG" rows="2">${esc(c.good.join(', '))}</textarea></label>
  <label class="field"><span>Nhận xét nhanh “Khắc phục”</span><textarea class="inp" id="cF" rows="2">${esc(c.fix.join(', '))}</textarea></label></div></section>
  <div style="display:flex;flex-direction:column;gap:8px">${c.lessons.map((l, li) => { const tot = round2(sum(l.criteria.map(k => k.max || 0))); return `<section class="card" style="padding:0">
    <button class="row" data-open="${li}" style="width:100%;border:0;background:none;padding:12px 16px;cursor:pointer;align-items:center;flex-wrap:nowrap;text-align:left"><span class="num faint" style="width:28px">${String(l.no).padStart(2, '0')}</span><b style="flex:1">${esc(l.name)}</b><span class="chip ${Math.abs(tot - 10) < .001 ? '' : 'bad'}">${l.criteria.length} tiêu chí · ${fmt(tot)} đ</span></button>
    ${LIBE.open === li ? `<div style="padding:0 16px 16px;display:flex;flex-direction:column;gap:10px">
      <label class="field"><span>Tên bài</span><input class="inp" data-l="name" value="${esc(l.name)}"></label>
      <label class="field"><span>Mục tiêu</span><textarea class="inp" data-l="objective" rows="2">${esc(l.objective)}</textarea></label>
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>Tiêu chí</th><th style="width:80px">Điểm</th><th>Mô tả 4 mức (tuỳ chọn)</th><th></th></tr></thead><tbody>${l.criteria.map((k, i) => `<tr><td><input class="inp" data-k="${i}" data-f="name" value="${esc(k.name)}"></td><td><input class="inp num" data-k="${i}" data-f="max" value="${fmt(k.max)}" style="text-align:center"></td><td><input class="inp" data-k="${i}" data-f="levels" value="${esc(k.levels || '')}"></td><td><button class="btn ghost sm" data-rm="${i}" aria-label="Xoá">${icon('x')}</button></td></tr>`).join('')}
      <tr><td><b>Tổng</b></td><td class="num" style="text-align:center;${Math.abs(tot - 10) < .001 ? '' : 'color:var(--bad);font-weight:700'}">${fmt(tot)}</td><td colspan="2"></td></tr></tbody></table></div>
      <div class="grid2"><label class="field"><span>“Tốt” riêng của bài</span><input class="inp" data-l="goodExtra" value="${esc((l.goodExtra || []).join(', '))}"></label><label class="field"><span>“Khắc phục” riêng của bài</span><input class="inp" data-l="fixExtra" value="${esc((l.fixExtra || []).join(', '))}"></label></div>
      <div class="row"><button class="btn sm" id="kAdd">${icon('plus')}Thêm tiêu chí</button><button class="btn sm claude" id="kSug">${icon('spark')}Claude gợi ý rubric cho bài này</button><span class="thinking" id="kSugS" hidden><i></i>Claude đang soạn…</span></div></div>` : ''}</section>`; }).join('')}</div>
  </div>`;
  const dirty = () => { LIBE.dirty = true; const b = $('#lSave'); if (b) b.disabled = false; };
  $$('[data-c]', v).forEach(b => b.onclick = () => { if (LIBE.dirty) { confirmBox('Bỏ các thay đổi chưa lưu của môn này?', 'Bỏ thay đổi', () => { LIBE = null; location.hash = 'library.' + b.dataset.c; }); return; } LIBE = null; location.hash = 'library.' + b.dataset.c; });
  $('#cG').onchange = e => { c.good = e.target.value.split(',').map(s => s.trim()).filter(Boolean); dirty(); };
  $('#cF').onchange = e => { c.fix = e.target.value.split(',').map(s => s.trim()).filter(Boolean); dirty(); };
  $$('[data-open]', v).forEach(b => b.onclick = () => { LIBE.open = LIBE.open === +b.dataset.open ? -1 : +b.dataset.open; ROUTES.library(v); });
  const l = c.lessons[LIBE.open];
  if (l) {
    $$('[data-l]', v).forEach(i => i.onchange = () => { const f = i.dataset.l; l[f] = /Extra$/.test(f) ? i.value.split(',').map(s => s.trim()).filter(Boolean) : i.value; dirty(); });
    $$('[data-k]', v).forEach(i => i.onchange = () => { const k = l.criteria[+i.dataset.k]; k[i.dataset.f] = i.dataset.f === 'max' ? (parseNum(i.value) || 0) : i.value; dirty(); ROUTES.library(v); });
    $$('[data-rm]', v).forEach(b => b.onclick = () => { l.criteria.splice(+b.dataset.rm, 1); dirty(); ROUTES.library(v); });
    $('#kAdd').onclick = () => { l.criteria.push({ name: 'Tiêu chí mới', max: 1, levels: '' }); dirty(); ROUTES.library(v); };
    $('#kSug').onclick = async () => { $('#kSugS').hidden = false; const r = await claudeRubric(c, l, '', true); if (r) { l.objective = r.objective || l.objective; l.criteria = r.criteria; if (r.good) l.goodExtra = r.good; if (r.fix) l.fixExtra = r.fix; dirty(); } ROUTES.library(v); };
  }
  $('#lSave').onclick = async () => {
    const prev = course(c.id); const changed = c.lessons.filter((l, i) => JSON.stringify(l) !== JSON.stringify(prev.lessons[i])).map(l => 'Bài ' + l.no);
    await Store.put('courses', c.id, c); LIBE.dirty = false; logHistory({ type: 'rubric', title: 'Sửa thư viện rubric ' + c.soft, changes: changed.length ? [['Bài đã sửa', '', changed.join(', ')]] : [['Nhận xét nhanh', '', 'đã sửa']] }); toast('Đã lưu thư viện ' + c.soft); ROUTES.library(v); };
  const rs = $('#lReset'); if (rs) rs.onclick = () => confirmBox('Khôi phục 15 bài mẫu của môn ' + c.soft + '? Các chỉnh sửa trong thư viện sẽ mất (điểm đã chấm vẫn giữ).', 'Khôi phục', async () => { await Store.del('courses', c.id); logHistory({ type: 'rubric', title: 'Khôi phục bản mẫu thư viện ' + c.soft }); LIBE = null; ROUTES.library(v); }, true);
};
function settingsModal() {
  const st = S.settings;
  modal(`<h2>Cài đặt</h2><div class="grid2"><label class="field"><span>Tên giảng viên</span><input class="inp" id="sT" value="${esc(st.teacher)}"></label>
  <label class="field"><span>Mức Claude khi chấm</span><select class="inp" id="sM">${[['quick', 'Nhanh'], ['default', 'Cân bằng (khuyên dùng)'], ['complex', 'Kỹ nhất (chậm hơn)']].map(([k, t]) => `<option value="${k}" ${st.tier === k ? 'selected' : ''}>${t}</option>`).join('')}</select></label></div>
  <label class="field"><span>Đơn vị (hiện ở đầu trang, chân trang và file nhận xét)</span><input class="inp" id="sU" value="${esc(st.unit)}"></label>
  <label class="field"><span>Mẫu “Tối hậu thư” khi không dùng Claude — {flags}: các nghi vấn, {proof}: thao tác chứng minh</span><textarea class="inp" id="sX" rows="5">${esc(st.ultimatum)}</textarea></label>
  <div class="row"><button class="btn sm" id="sExp">${icon('down')}Xuất thư viện (JSON)</button><label class="btn sm">${icon('upload')}Nhập thư viện<input type="file" id="sImp" accept=".json" hidden></label>${Object.values(S.subs).some(s => s.sample) ? `<button class="btn sm danger" id="sDelS">Xoá dữ liệu mẫu</button>` : ''}</div>
  <p class="muted" style="font-size:.78rem;margin:0">Lưu trữ: ${S.mode === 'db' ? 'kho dữ liệu dùng chung của trang (mọi thiết bị của bạn thấy cùng dữ liệu).' : 'trình duyệt này. Hãy xuất Excel định kỳ.'}</p>
  <div class="modal-f"><button class="btn" data-close>Huỷ</button><button class="btn pri" id="sOk">Lưu cài đặt</button></div>`, (m, close) => {
    $('#sOk', m).onclick = async () => { await Store.put('settings', 'app', { teacher: $('#sT', m).value, unit: $('#sU', m).value, tier: $('#sM', m).value, ultimatum: $('#sX', m).value }); close(); toast('Đã lưu cài đặt'); };
    $('#sExp', m).onclick = () => saveFile('ThuVienRubric.json', JSON.stringify({ courses: courses(), classes: classes() }, null, 2));
    $('#sImp', m).onchange = async e => { try { const j = JSON.parse(await e.target.files[0].text()); for (const c of j.courses || []) await Store.put('courses', c.id, c); for (const k of j.classes || []) await Store.put('classes', k.id, k); toast('Đã nhập thư viện'); close(); } catch { toast('File JSON không hợp lệ.', true); } };
    const ds = $('#sDelS', m); if (ds) ds.onclick = async () => { for (const s of Object.values(S.subs).filter(s => s.sample)) await Store.del('subs', s.id); toast('Đã xoá dữ liệu mẫu'); close(); };
  });
}
$('#btnHelp').onclick = () => modal(`<h2>Hướng dẫn nhanh</h2><ol style="margin:0;padding-left:20px;display:flex;flex-direction:column;gap:6px;font-size:.88rem">
  <li>Vào mục <b>Chấm bài</b>, chọn Lớp, Môn, Bài học — mục tiêu và tiêu chí của giảng viên tự đổi theo bài.</li>
  <li>Kéo thả ảnh/PDF/PSD/AI (≤ 20 MB/file) vào khung bên trái. <b>Claude chấm tự động</b> theo từng tiêu chí, điền điểm, viết các ý Tốt / Khắc phục và tính <b>chỉ số nghi vấn AI (%)</b>.</li>
  <li>Sửa trực tiếp ô điểm nếu chưa đồng ý. Sửa, thêm, xoá từng gạch đầu dòng nhận xét.</li>
  <li>Vẽ lên bài bằng bút, mũi tên, khung, elip — sau mỗi nét, ô <b>ghi chú lỗi</b> hiện ra. Di chuột vào vùng vẽ để xem lại ghi chú; bấm vào để sửa.</li>
  <li>Tick <b>Nghi vấn lạm dụng AI</b> khi thấy dấu hiệu — Claude tính lại chỉ số % và chèn đoạn “tối hậu thư” vào cuối nhận xét.</li>
  <li><b>Lưu &amp; duyệt</b>, rồi <b>Tải nhận xét về máy</b> (trang web có ghi chú khi di chuột, hoặc Word) và <b>Chấm bài tiếp theo</b>.</li></ol>
  <h3>Phím tắt</h3><div class="sig" style="grid-template-columns:120px 1fr"><dt>V / B / A / R / E / T</dt><dd>Di chuyển · Bút · Mũi tên · Khung · Elip · Chữ</dd><dt>C</dt><dd>Đo tương phản (bấm 2 điểm màu)</dd><dt>G</dt><dd>Đổi lưới phủ</dd><dt>+ / − / 0</dt><dd>Phóng to · Thu nhỏ · Vừa khung</dd><dt>Ctrl + Z</dt><dd>Hoàn tác nét vẽ</dd><dt>Ctrl + S</dt><dd>Lưu &amp; duyệt</dd><dt>Alt + N</dt><dd>Chấm bài tiếp theo</dd></div>
  <div class="modal-f"><button class="btn pri" data-close>Đã hiểu</button></div>`);

delete ROUTES.assignments; delete ROUTES.viva;

/* ===== Đồng bộ với phần mềm nhập điểm của trường (qua file mẫu) ===== */
const SY = { name: '', wb: null, sheet: '', rows: [], hdr: -1, idCol: -1, nameCol: -1, target: -1, source: 'avg', round: '0.1', ext: 'xlsx' };
function syncScore(mssv, c) {
  const mine = subsArr().filter(s => s.courseId === c.id && s.status === 'duyet' && String(s.mssv).trim() === mssv && (!SF.cls || s.classId === SF.cls));
  let v = null;
  if (SY.source === 'avg') { const xs = mine.map(subTotal).filter(x => x != null); v = xs.length ? mean(xs) : null; }
  else { const s = mine.filter(x => x.lessonId === SY.source).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0))[0]; v = s ? subTotal(s) : null; }
  if (v == null) return null;
  const st = parseFloat(SY.round); return st ? Math.round(v / st) * st : v;
}
function syncPlan(c) {
  if (!SY.rows.length || SY.hdr < 0 || SY.idCol < 0) return [];
  return SY.rows.slice(SY.hdr + 1).map((r, i) => ({ r: SY.hdr + 1 + i, id: String(r[SY.idCol] ?? '').trim(), name: SY.nameCol >= 0 ? String(r[SY.nameCol] ?? '') : '', old: SY.target >= 0 ? r[SY.target] : '' }))
    .filter(x => x.id).map(x => ({ ...x, v: syncScore(x.id, c) }));
}
function syncHtml(c) {
  const head = SY.hdr >= 0 ? SY.rows[SY.hdr] : [], plan = syncPlan(c), hit = plan.filter(x => x.v != null);
  const inFile = new Set(plan.map(x => x.id));
  const missing = [...new Set(subsArr().filter(s => s.courseId === c.id && s.status === 'duyet' && (!SF.cls || s.classId === SF.cls)).map(s => String(s.mssv).trim()))].filter(id => id && !inFile.has(id));
  const opt = (arr, cur) => arr.map((h, i) => `<option value="${i}" ${i === cur ? 'selected' : ''}>${esc(String(h ?? '').trim() || 'Cột ' + XLSX_col(i))}</option>`).join('');
  const log = (S.settings.syncLog || []).slice(-6).reverse();
  return `<section class="card" id="syncCard"><div class="card-h"><h2>Đồng bộ với phần mềm nhập điểm của trường</h2><span class="chip acc">Qua file mẫu Excel / CSV</span></div>
  <p class="muted" style="margin:0 0 14px;font-size:.86rem;max-width:80ch">Phần mềm quản lý đào tạo của trường cho xuất bảng điểm lớp ra Excel/CSV và nhập lại từ file đó. Chấm.Design điền điểm đã duyệt vào đúng cột theo MSSV, giữ nguyên các cột còn lại — bạn chỉ việc tải lên lại hệ thống của trường, hoặc dán cột điểm vào ô nhập trên web.</p>
  <ol class="sync-steps">
    <li><div><h3>Tải file mẫu bảng điểm của lớp từ phần mềm của trường</h3>
      <div class="drop-sm"><label class="btn">${icon('upload')}Chọn file mẫu (.xlsx, .xls, .csv)<input type="file" id="syF" accept=".xlsx,.xls,.csv" hidden></label><span class="muted" style="font-size:.82rem">${SY.name ? `<b>${esc(SY.name)}</b> · trang “${esc(SY.sheet)}” · ${Math.max(0, SY.rows.length - SY.hdr - 1)} dòng` : 'Chưa có file. Thường ở mục “Nhập điểm” → “Xuất Excel/Tải mẫu”.'}</span></div></div></li>
    ${SY.rows.length ? `<li><div><h3>Ghép cột</h3><div class="grid3">
      <label class="field"><span>Cột MSSV trong file</span><select class="inp" id="syId">${opt(head, SY.idCol)}</select></label>
      <label class="field"><span>Cột họ tên (để đối chiếu)</span><select class="inp" id="syNm"><option value="-1">Không dùng</option>${opt(head, SY.nameCol)}</select></label>
      <label class="field"><span>Cột cần điền điểm</span><select class="inp" id="syT"><option value="-1">Chọn cột…</option>${opt(head, SY.target)}<option value="${head.length}" ${SY.target === head.length ? 'selected' : ''}>＋ Thêm cột mới ở cuối</option></select></label></div></div></li>
    <li><div><h3>Chọn điểm cần đồng bộ</h3><div class="grid3">
      <label class="field"><span>Lấy điểm từ</span><select class="inp" id="sySrc"><option value="avg" ${SY.source === 'avg' ? 'selected' : ''}>Trung bình các bài đã duyệt của môn</option>${c.lessons.map(l => `<option value="${l.id}" ${SY.source === l.id ? 'selected' : ''}>Bài ${l.no}: ${esc(l.name)}</option>`).join('')}</select></label>
      <label class="field"><span>Làm tròn</span><select class="inp" id="syR">${[['0.1', '0,1 điểm'], ['0.25', '0,25 điểm'], ['0.5', '0,5 điểm'], ['1', '1 điểm'], ['0', 'Không làm tròn']].map(([k, t]) => `<option value="${k}" ${SY.round === k ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
      <div class="field"><span>Phạm vi</span><div class="muted" style="font-size:.84rem;padding-top:8px">Lớp ${esc(SF.cls ? klass(SF.cls)?.name || SF.cls : 'tất cả')} · ${esc(c.soft)} · chỉ bài <b>đã duyệt</b></div></div></div></div></li>
    <li><div><h3>Kiểm tra và đồng bộ</h3>
      <div class="row" style="margin-bottom:10px"><span class="chip ok">${hit.length} SV có điểm</span><span class="chip ${plan.length - hit.length ? 'warn' : ''}">${plan.length - hit.length} SV chưa có điểm đã duyệt</span>${missing.length ? `<span class="chip bad" title="${esc(missing.join(', '))}">${missing.length} MSSV đã chấm nhưng không có trong file</span>` : ''}</div>
      <div class="tbl-wrap" style="max-height:280px;overflow:auto;box-shadow:none"><table class="tbl"><thead><tr><th>Dòng</th><th>MSSV</th><th>Họ tên trong file</th><th>Điểm hiện tại</th><th>Điểm sẽ điền</th></tr></thead><tbody>${plan.map(x => `<tr><td class="num faint">${x.r + 1}</td><td class="num">${esc(x.id)}</td><td>${esc(x.name)}</td><td class="num faint">${esc(x.old ?? '')}</td><td class="num"><b style="color:${x.v == null ? 'var(--faint)' : 'var(--ok)'}">${x.v == null ? '—' : fmt(x.v)}</b></td></tr>`).join('')}</tbody></table></div>
      <div class="row" style="margin-top:12px"><button class="btn pri" id="syGo" ${SY.target >= 0 && hit.length ? '' : 'disabled'}>${icon('down')}Tải file đã điền điểm để nhập vào hệ thống trường</button><button class="btn" id="syCopy" ${hit.length ? '' : 'disabled'}>${icon('copy')}Sao chép cột điểm (theo thứ tự file)</button></div></div></li>` : ''}
  </ol>
  ${log.length ? `<div style="margin-top:16px"><div class="eyebrow" style="margin-bottom:6px">Lịch sử đồng bộ</div><div class="feed">${log.map(x => `<div><time>${fmtTime(x.at)}</time><span>${esc(x.file)} → cột “${esc(x.col)}”: <b>${x.n}</b> SV · ${esc(x.src)}</span></div>`).join('')}</div></div>` : ''}
  </section>`;
}
function XLSX_col(i) { let s = ''; i++; while (i) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = (i - m - 1) / 26; } return s; }
function bindSync(v, c) {
  const rer = () => { const y = window.scrollY; ROUTES.stats(v); window.scrollTo(0, y); };
  const f = $('#syF', v); if (f) f.onchange = async e => {
    const file = e.target.files[0]; if (!file) return;
    try {
      await loadScript(LIB.xlsx);
      const wb = XLSX.read(await file.arrayBuffer(), { cellDates: false });
      const sheet = wb.SheetNames[0], rows = XLSX.utils.sheet_to_json(wb.Sheets[sheet], { header: 1, defval: '', blankrows: true });
      let hdr = rows.findIndex((r, i) => i < 30 && r.some(x => /mssv|mã\s*(số\s*)?(sv|sinh\s*viên)|ma\s*sv|student\s*id/i.test(String(x))));
      if (hdr < 0) hdr = 0;
      const H = rows[hdr] || [];
      const idCol = Math.max(0, H.findIndex(x => /mssv|mã\s*(số\s*)?(sv|sinh\s*viên)|ma\s*sv|student\s*id/i.test(String(x))));
      const nameCol = H.findIndex(x => /họ\s*(và)?\s*tên|ho\s*ten|^tên$|full\s*name/i.test(String(x).trim()));
      const remembered = S.settings.syncCol ? H.findIndex(x => String(x).trim() === S.settings.syncCol) : -1;
      const pick = re => H.findIndex((x, i) => i !== idCol && re.test(String(x)));
      let target = remembered >= 0 ? remembered : pick(/thực\s*hành|thuc\s*hanh/i); if (target < 0) target = pick(/điểm|diem|quá\s*trình|score/i);
      Object.assign(SY, { name: file.name, wb, sheet, rows, hdr, idCol, nameCol, target, ext: /\.csv$/i.test(file.name) ? 'csv' : 'xlsx' });
      toast('Đã đọc file mẫu: ' + Math.max(0, rows.length - hdr - 1) + ' dòng'); rer();
    } catch (er) { toast('Không đọc được file: ' + (er.message || er), true); }
  };
  const bind = (id, fn) => { const el = $(id, v); if (el) el.onchange = e => { fn(e.target.value); rer(); }; };
  bind('#syId', x => SY.idCol = +x); bind('#syNm', x => SY.nameCol = +x); bind('#syT', x => SY.target = +x); bind('#sySrc', x => SY.source = x); bind('#syR', x => SY.round = x);
  const plan = () => syncPlan(c);
  const cp = $('#syCopy', v); if (cp) cp.onclick = async () => {
    const t = plan().map(x => x.v == null ? '' : String(round2(x.v)).replace('.', ',')).join('\n');
    try { await navigator.clipboard.writeText(t); toast('Đã sao chép ' + plan().length + ' ô điểm — dán vào cột điểm trên phần mềm của trường'); }
    catch { modal(`<h2>Cột điểm</h2><p class="muted" style="margin:0">Bôi đen và nhấn Ctrl+C, rồi dán vào ô đầu tiên của cột điểm trên hệ thống trường.</p><textarea class="inp mono" id="cpT" rows="14">${esc(t)}</textarea><div class="modal-f"><button class="btn pri" data-close>Xong</button></div>`, m => { $('#cpT', m).select(); }); }
  };
  const go2 = $('#syGo', v); if (go2) go2.onclick = async () => {
    const ws = SY.wb.Sheets[SY.sheet], pl = plan(); let n = 0;
    const tcol = SY.target;
    if (tcol >= (SY.rows[SY.hdr] || []).length) { ws[XLSX.utils.encode_cell({ r: SY.hdr, c: tcol })] = { t: 's', v: 'Điểm ' + (SY.source === 'avg' ? 'TB ' + c.soft : 'Bài ' + lesson(c.id, SY.source).no) }; }
    pl.forEach(x => { if (x.v == null) return; ws[XLSX.utils.encode_cell({ r: x.r, c: tcol })] = { t: 'n', v: round2(x.v) }; n++; });
    const rg = XLSX.utils.decode_range(ws['!ref'] || 'A1'); rg.e.c = Math.max(rg.e.c, tcol); rg.e.r = Math.max(rg.e.r, ...pl.map(x => x.r)); ws['!ref'] = XLSX.utils.encode_range(rg);
    const base = SY.name.replace(/\.[^.]+$/, '');
    const data = SY.ext === 'csv' ? '﻿' + XLSX.utils.sheet_to_csv(ws) : new Blob([XLSX.write(SY.wb, { type: 'array', bookType: 'xlsx' })]);
    const ok = await saveFile(base + '_DaDienDiem.' + SY.ext, data);
    if (ok) {
      const col = String((SY.rows[SY.hdr] || [])[tcol] ?? 'cột mới').trim();
      const logs = [...(S.settings.syncLog || []), { at: Date.now(), file: SY.name, col, n, src: SY.source === 'avg' ? 'TB môn ' + c.soft : 'Bài ' + lesson(c.id, SY.source).no }].slice(-20);
      await Store.put('settings', 'app', { syncLog: logs, syncCol: col }); logHistory({ type: 'sync', title: 'Đồng bộ điểm vào file ' + SY.name, changes: [['Cột', '', col], ['Số sinh viên', '', String(n)], ['Nguồn điểm', '', logs[logs.length - 1].src]] }); rer();
    }
  };
}
