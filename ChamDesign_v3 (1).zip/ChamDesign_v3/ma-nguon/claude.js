/* ===== Claude: chấm nháp, phản biện, gợi ý rubric ===== */
function claudeErr(e) {
  const m = { bad_key: 'Khoá API Claude không hợp lệ hoặc đã bị thu hồi — kiểm tra ở Cài đặt chung.', bad_model: 'Mô hình Claude đã chọn không dùng được — chọn lại ở Cài đặt chung.', not_granted: 'Bạn chưa cho phép trang dùng Claude.', sampling_disabled: 'Claude không khả dụng cho tài khoản này.', rate_limited: 'Đã chạm giới hạn sử dụng Claude — thử lại sau ít phút.', images_unavailable: 'Chế độ xem này không gửi được ảnh cho Claude.', image_rejected: 'Ảnh không hợp lệ (định dạng hoặc quá lớn).', invalid_json: 'Claude trả lời sai định dạng — bấm phân tích lại.', refused: 'Claude từ chối xử lý nội dung này.', session_expired: 'Phiên đăng nhập đã hết — hãy đăng nhập lại.', prompt_too_large: 'Dữ liệu gửi quá lớn.' };
  return m[e?.code] || ('Claude gặp lỗi (' + (e?.code || e?.message || 'không rõ') + ').');
}
function buildUltimatum(flagIds, courseId) {
  if (!flagIds?.length) return '';
  const fl = flagsFor(courseId).filter(f => flagIds.includes(f.id));
  return S.settings.ultimatum.replace('{flags}', fl.map(f => f.label.replace(/\s*\((Photoshop|Illustrator)\)/, '').toLowerCase()).join('; ')).replace('{proof}', fl.map(f => f.proof).join('; '));
}
function classContext(classId, lessonId, exceptId) {
  const xs = subsArr().filter(s => s.classId === classId && s.lessonId === lessonId && s.id !== exceptId && s.status === 'duyet').map(s => ({ n: s.name, t: subTotal(s) })).filter(x => x.t != null);
  if (!xs.length) return 'Chưa có bài nào của lớp được duyệt cho bài này — chấm theo chuẩn đầu ra của môn.';
  const ts = xs.map(x => x.t);
  return `Đã duyệt ${xs.length} bài: trung bình ${fmt(mean(ts))}, cao nhất ${fmt(Math.max(...ts))}, thấp nhất ${fmt(Math.min(...ts))}. Điểm từng bạn: ${xs.slice(0, 40).map(x => fmt(x.t)).join(', ')}. Hãy chấm nhất quán, tương đối với mặt bằng này (bài tương đương thì điểm tương đương).`;
}
function ctxFromSub(s) {
  const l = lesson(s.courseId, s.lessonId), a = findAssignment(s.classId, s.lessonId);
  return { id: s.id, courseId: s.courseId, lessonId: s.lessonId, classId: s.classId, objective: s.objective || a?.objective || l.objective, criteria: (s.criteria || a?.criteria || l.criteria).map(k => ({ name: k.name, max: k.max, levels: k.levels || '' })), flags: s.flags || [], files: s.files || [], declaration: s.ai?.declaration || '', policy: s.ai?.policy || a?.aiLevel || 2, note: s.note || '', title: s.title || '' };
}
function gradePrompt(ctx, pageLabels) {
  const c = course(ctx.courseId), l = lesson(ctx.courseId, ctx.lessonId), L = AI_LEVELS[(ctx.policy || 2) - 1];
  const good = [...c.good, ...(l.goodExtra || [])], fix = [...c.fix, ...(l.fixExtra || [])];
  const fl = flagsFor(ctx.courseId).filter(f => ctx.flags.includes(f.id));
  return `Bạn là giảng viên phản biện ngành Thiết kế Đồ họa ở một trường đại học Việt Nam. Hãy chấm tự động bài sinh viên trong ảnh đính kèm theo đúng các tiêu chí giảng viên đã đặt, viết bằng tiếng Việt, giọng sư phạm: tôn trọng, cụ thể, dùng đúng từ vựng chuyên môn (phân cấp thị giác, lưới, tương phản WCAG, kerning, leading, non-destructive, mask, Bezier…) để sinh viên học cách lập luận thị giác thay vì nhận xét cảm tính.

MÔN: ${c.name} (phần mềm chính: ${c.soft})
BÀI ${l.no}: ${l.name}${ctx.title ? '\nTÊN BÀI NỘP: ' + ctx.title : ''}
${ctx.objective}
ẢNH ĐÍNH KÈM (theo thứ tự): ${pageLabels.join(' | ')}

TIÊU CHÍ CHẤM (thang 10, bước 0,25):
${ctx.criteria.map((k, i) => `${i}. ${k.name} — tối đa ${k.max}${k.levels ? ' (mô tả mức: ' + k.levels + ')' : ''}`).join('\n')}

BỐI CẢNH LỚP: ${classContext(ctx.classId, ctx.lessonId, ctx.id)}

TÍN HIỆU KỸ THUẬT ĐỌC TỪ FILE:
${signalText(ctx.files) || '(chỉ có ảnh xuất, không có file gốc)'}

CHÍNH SÁCH AI CỦA BÀI: Mức ${L.n} – ${L.name}: ${L.desc}
BẢN KHAI BÁO CỦA SINH VIÊN: ${ctx.declaration ? '"' + ctx.declaration + '"' : '(không có)'}
${ctx.note ? 'GHI CHÚ CỦA GIẢNG VIÊN: ' + ctx.note + '\n' : ''}
NGHI VẤN LẠM DỤNG AI GIẢNG VIÊN ĐÃ ĐÁNH DẤU: ${fl.length ? fl.map(f => f.label + ' → thao tác chứng minh: ' + f.proof).join('; ') : 'không có'}
${fl.length ? `Vì có nghi vấn, hãy viết "ultimatum": một đoạn "tối hậu thư" tinh tế 3–5 câu đặt cuối bảng nhận xét — lịch sự, không buộc tội, ghi nhận điểm tốt của bài; nêu rõ các dấu hiệu kỹ thuật cụ thể cần làm rõ; yêu cầu sinh viên chứng minh quy trình bằng đúng các thao tác trên ở buổi học tới (mang file gốc đủ layer và bản trung gian); nói rõ nếu không làm rõ được thì điểm sẽ được xem xét lại theo quy định liêm chính học thuật.` : 'Không có nghi vấn: để "ultimatum" là chuỗi rỗng.'}

Gợi ý từ vựng nhận xét của môn — Tốt: ${good.join(', ')}. Khắc phục: ${fix.join(', ')}.

Trả lời CHỈ một đối tượng JSON đúng dạng:
{"scores":[{"i":0,"score":1.75,"reason":"1 câu căn cứ quan sát cụ thể"}],
"good":["1 câu cụ thể về điểm tốt, nêu vị trí/kỹ thuật"],
"fix":["1 câu cụ thể về lỗi cần khắc phục và cách sửa"],
"comment":"nhận xét chung 3–5 câu, giọng sư phạm",
"ultimatum":"",
"ai":{"percent":35,"level":"xanh|vang|do","observations":["quan sát kỹ thuật cụ thể, vị trí trên ảnh"],"assessment":"nhận định thận trọng 2–3 câu, không kết luận gian lận","questions":["câu hỏi vấn đáp cụ thể để sinh viên chứng minh quy trình"]}}
Quy tắc: "scores" có đủ ${ctx.criteria.length} phần tử, mỗi score từ 0 đến điểm tối đa của tiêu chí, chấm bám sát từng tiêu chí giảng viên đặt; "good" và "fix" mỗi mảng 2–5 gạch đầu dòng, mỗi dòng là một câu hoàn chỉnh (không đánh số, không gạch đầu dòng trong chuỗi); "ai.percent" là chỉ số nghi vấn lạm dụng AI từ 0 đến 100, tính từ dấu hiệu trên ảnh (pixel hoà trộn bất thường, nhiễu hạt/độ nét không đồng nhất, chi tiết phi logic), tín hiệu kỹ thuật của file, độ khớp với bản khai báo và chính sách, và các nghi vấn giảng viên đã đánh dấu (mỗi dấu hiệu được xác nhận làm tăng đáng kể chỉ số); level: xanh < 30, vàng 30–64, đỏ ≥ 65; "questions" 3–5 câu.`;
}
async function claudeGrade(ctx, pages, signal, onText) {
  if (!CAP.sample) throw { code: 'sampling_disabled' };
  const lim = await CAP.sample.limits().catch(() => null);
  if (!lim?.images) throw { code: 'images_unavailable' };
  const pick = pages.slice(0, Math.min(lim.images.maxCount || 1, 6));
  const blobs = await Promise.all(pick.map(p => canvasBlob(p.canvas)));
  const prompt = gradePrompt(ctx, pick.map((p, i) => (i + 1) + ') ' + (KINDS.find(k => k[0] === p.kind)?.[1] || 'Bản cuối') + ' – ' + p.label));
  const res = await CAP.sample.json(prompt, { images: blobs, signal, modelTier: S.settings.tier || 'default', cache: false, onText });
  if (!res || !Array.isArray(res.scores)) throw { code: 'invalid_json' };
  const q = v => Math.round(v * 4) / 4;
  res.scores = ctx.criteria.map((k, i) => { const r = res.scores.find(s => +s.i === i) || res.scores[i] || {}; return { score: clamp(q(+r.score || 0), 0, k.max), reason: String(r.reason || '') }; });
  const clean = a => (Array.isArray(a) ? a : String(a || '').split('\n')).map(x => String(x).replace(/^\s*[-–•*\d.)]+\s*/, '').trim()).filter(Boolean);
  res.good = clean(res.good); res.fix = clean(res.fix);
  res.ai = res.ai || {}; res.ai.percent = clamp(Math.round(+res.ai.percent || 0), 0, 100);
  res.ai.level = res.ai.percent >= 65 ? 'do' : res.ai.percent >= 30 ? 'vang' : 'xanh';
  if (ctx.flags.length && !String(res.ultimatum || '').trim()) res.ultimatum = buildUltimatum(ctx.flags, ctx.courseId);
  if (!ctx.flags.length) res.ultimatum = '';
  return res;
}
function applyClaudeToSub(s, res) {
  const ctx = ctxFromSub(s);
  const criteria = ctx.criteria.map((k, i) => ({ ...k, claude: res.scores[i].score, reason: res.scores[i].reason, score: null }));
  criteria.forEach(k => k.score = k.claude);
  return { ...s, objective: ctx.objective, criteria, claudeTotal: round2(sum(res.scores.map(x => x.score))), total: round2(sum(res.scores.map(x => x.score))), good: res.good, fix: res.fix, comment: res.comment || '', ultimatum: res.ultimatum || '', status: 'nhap',
    ai: { ...(s.ai || {}), policy: ctx.policy, percent: res.ai.percent, level: res.ai.level, observations: res.ai.observations || [], assessment: res.ai.assessment || '' },
    viva: { ...(s.viva || {}), items: (res.ai.questions || []).map(q => ({ q: String(q), res: '', note: '' })) } };
}
async function claudeRubric(c, l, desc, showErr) {
  if (!CAP.sample) { toast('Claude chưa sẵn sàng trong chế độ xem này.', true); return null; }
  try {
    const r = await CAP.sample.json(`Bạn là giảng viên Thiết kế Đồ họa đại học tại Việt Nam. Đề xuất rubric chấm cho bài tập sau, tiếng Việt.
MÔN: ${c.name} (${c.soft}). BÀI ${l.no}: ${l.name}.
${desc ? 'MÔ TẢ ĐỀ: ' + desc : ''}
Rubric hiện có để tham khảo: ${l.criteria.map(k => k.name + ' (' + k.max + ')').join('; ')}
Yêu cầu: 5–7 tiêu chí, tổng đúng 10 điểm, điểm mỗi tiêu chí là bội số của 0,5; bao quát bố cục/phân cấp thị giác, kỹ thuật công cụ đặc thù ${c.soft}, màu sắc, typography (nếu có), ý tưởng – sáng tạo, và một tiêu chí về file nộp đúng chuẩn (tối đa 1 điểm). Mỗi tiêu chí kèm mô tả 4 mức ngắn.
Trả lời CHỈ JSON: {"objective":"Mục tiêu: Đánh giá khả năng …","criteria":[{"name":"…","max":2,"levels":"Xuất sắc: … / Khá: … / Đạt: … / Chưa đạt: …"}],"good":["nhãn Tốt ngắn"],"fix":["nhãn Khắc phục ngắn"]}`, { modelTier: 'default' });
    if (!r?.criteria?.length) throw { code: 'invalid_json' };
    r.criteria = r.criteria.map(k => ({ name: String(k.name), max: +k.max || 1, levels: String(k.levels || '') }));
    const t = sum(r.criteria.map(k => k.max)); if (Math.abs(t - 10) > .01) toast('Claude đề xuất tổng ' + fmt(t) + ' điểm — hãy chỉnh lại cho đủ 10.', true);
    return r;
  } catch (e) { if (showErr) toast(claudeErr(e), true); return null; }
}

/* Tính lại chỉ số nghi vấn AI khi giảng viên đổi cờ (chỉ gửi văn bản, nhanh) */
async function claudeAiIndex(g, signal) {
  if (!CAP.sample) throw { code: 'sampling_disabled' };
  const c = course(g.courseId), l = lesson(g.courseId, g.lessonId), L = AI_LEVELS[(g.ai.policy || 2) - 1];
  const fl = flagsFor(g.courseId).filter(f => g.flags.includes(f.id));
  const r = await CAP.sample.json(`Bạn hỗ trợ giảng viên Thiết kế Đồ họa đánh giá nguy cơ sinh viên lạm dụng AI. Tính "chỉ số nghi vấn lạm dụng AI" (0–100) cho bài sau và viết đoạn tối hậu thư nếu có nghi vấn. Tiếng Việt.
MÔN: ${c.name} (${c.soft}). BÀI ${l.no}: ${l.name}.
CHÍNH SÁCH: Mức ${L.n} – ${L.name}: ${L.desc}
BẢN KHAI BÁO SV: ${g.ai.declaration ? '"' + g.ai.declaration + '"' : '(không có)'}
QUAN SÁT TRƯỚC ĐÓ TRÊN ẢNH: ${(g.ai.observations || []).join('; ') || '(chưa có)'}
TÍN HIỆU KỸ THUẬT FILE:
${signalText(g.files) || '(chỉ có ảnh xuất)'}
DẤU HIỆU GIẢNG VIÊN XÁC NHẬN: ${fl.length ? fl.map(f => f.label).join('; ') : 'không có'}
Quy tắc: mỗi dấu hiệu giảng viên xác nhận làm tăng đáng kể chỉ số; tín hiệu file (C2PA/nhãn AI không khai báo, file gốc phẳng, rác điểm neo) cũng làm tăng; khai báo trung thực phù hợp chính sách làm giảm. Nếu có dấu hiệu giảng viên xác nhận, "ultimatum" là đoạn tối hậu thư tinh tế 3–5 câu: lịch sự, không buộc tội, nêu dấu hiệu cụ thể, yêu cầu ở buổi tới mang file gốc đủ layer và ${fl.map(f => f.proof).join('; ') || 'chứng minh quy trình'}, nêu rõ điểm sẽ được xem xét lại theo quy định liêm chính học thuật nếu không làm rõ. Không có dấu hiệu thì "ultimatum" rỗng.
Trả lời CHỈ JSON: {"percent":0,"reason":"1–2 câu giải thích chỉ số","ultimatum":""}`, { modelTier: 'quick', signal, cache: false });
  const percent = clamp(Math.round(+r?.percent || 0), 0, 100);
  return { percent, level: percent >= 65 ? 'do' : percent >= 30 ? 'vang' : 'xanh', reason: String(r?.reason || ''), ultimatum: fl.length ? String(r?.ultimatum || '') || buildUltimatum(g.flags, g.courseId) : '' };
}
function localAiIndex(g) {
  let p = 8 + 18 * g.flags.length;
  (g.files || []).forEach(f => { const s = f.signals || {}; if (s.ai?.length) p += 25; else if (s.c2pa) p += 10; if (s.psd && s.psd.layers <= 1) p += 15; if (s.psd?.generative) p += 15; if (s.vec?.avg >= 25) p += 12; });
  if ((g.ai.policy || 2) >= 4) p -= 10;
  return clamp(Math.round(p), 0, 100);
}
