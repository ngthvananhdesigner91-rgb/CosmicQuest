/* ===== Đọc file: ảnh, PDF, AI, PSD, SVG + tín hiệu kỹ thuật ===== */
const FILE_CACHE = {};
const MAX_SIDE = 2400;
function fitCanvas(src, w, h, max = MAX_SIDE) {
  const k = Math.min(1, max / Math.max(w, h)); const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(w * k)); c.height = Math.max(1, Math.round(h * k));
  const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(src, 0, 0, c.width, c.height); c.scale = k; return c;
}
function canvasThumb(cv, size = 200, q = .72) { const t = fitCanvas(cv, cv.width, cv.height, size); return t.toDataURL('image/jpeg', q); }
async function thumbDataUrl(file, size) { const b = await createImageBitmap(file); const c = fitCanvas(b, b.width, b.height, size); return c.toDataURL('image/jpeg', .8); }
const extOf = n => (n.match(/\.([^.]+)$/) || [, ''])[1].toLowerCase();

async function scanBytes(buf) {
  const u8 = new Uint8Array(buf), out = { c2pa: false, ai: [], software: '', saves: 0, first: '', last: '', history: [] };
  const CH = 4 * 1048576; let txt = '';
  const dec = new TextDecoder('latin1');
  // đọc đầu + cuối file (XMP/C2PA thường nằm ở đây) để nhanh với file lớn
  if (u8.length <= 3 * CH) txt = dec.decode(u8); else txt = dec.decode(u8.subarray(0, CH)) + dec.decode(u8.subarray(u8.length - CH));
  const low = txt.toLowerCase();
  if (low.includes('c2pa') || low.includes('jumbf') || low.includes('contentcredentials')) out.c2pa = true;
  const marks = [['trainedalgorithmicmedia', 'Nhãn IPTC “trainedAlgorithmicMedia” (ảnh do AI tạo)'], ['compositewithtrainedalgorithmicmedia', 'Nhãn IPTC “compositeWithTrainedAlgorithmicMedia” (ghép có AI)'], ['firefly', 'Adobe Firefly'], ['generative fill', 'Generative Fill'], ['generative expand', 'Generative Expand'], ['text to vector', 'Text to Vector Graphic'], ['midjourney', 'Midjourney'], ['dall-e', 'DALL·E'], ['dall·e', 'DALL·E'], ['openai', 'OpenAI'], ['stable diffusion', 'Stable Diffusion'], ['ideogram', 'Ideogram'], ['leonardo.ai', 'Leonardo AI'], ['chatgpt', 'ChatGPT'], ['imagen', 'Google Imagen'], ['canva ai', 'Canva AI']];
  marks.forEach(([k, l]) => { if (low.includes(k) && !out.ai.includes(l)) out.ai.push(l); });
  const sw = txt.match(/CreatorTool(?:="|>)([^"<]{3,80})/) || txt.match(/(Adobe (?:Photoshop|Illustrator|InDesign)[^\x00"<]{0,40})/) || txt.match(/(Figma|Canva|Procreate|Affinity [A-Za-z]+|GIMP[^\x00]{0,10}|Krita)/);
  if (sw) out.software = sw[1].trim();
  out.saves = (txt.match(/stEvt:action(?:="|>)saved/g) || []).length;
  const whens = [...txt.matchAll(/stEvt:when(?:="|>)([0-9T:+\-.Z]{10,})/g)].map(m => m[1]).sort();
  if (whens.length) { out.first = whens[0]; out.last = whens[whens.length - 1]; }
  const agents = [...new Set([...txt.matchAll(/stEvt:softwareAgent(?:="|>)([^"<]{3,60})/g)].map(m => m[1].trim()))].slice(0, 4);
  out.history = agents;
  return out;
}

async function processFile(file, opt = {}) {
  const ext = extOf(file.name), buf = await file.arrayBuffer();
  const sig = { ext, size: file.size, ...(await scanBytes(buf)) };
  const pages = [];
  const max = opt.max || (opt.quick ? 1200 : MAX_SIDE);
  if (['jpg', 'jpeg', 'png', 'webp', 'gif'].includes(ext) || /^image\/(jpeg|png|webp|gif)/.test(file.type)) {
    const b = await createImageBitmap(new Blob([buf], { type: file.type || 'image/' + ext }));
    sig.w = b.width; sig.h = b.height; sig.kind = 'raster';
    pages.push({ canvas: fitCanvas(b, b.width, b.height, max), label: file.name });
  } else if (ext === 'svg') {
    const txt = new TextDecoder().decode(buf);
    const ds = [...txt.matchAll(/\sd="([^"]+)"/g)].map(m => m[1]);
    const anchors = ds.map(d => (d.match(/[MLCSQTAHVmlcsqtahv]/g) || []).length);
    sig.kind = 'vector'; sig.vec = { paths: ds.length, anchors: sum(anchors), avg: ds.length ? round2(sum(anchors) / ds.length) : 0, max: Math.max(0, ...anchors), clips: (txt.match(/<clipPath/g) || []).length, fills: (txt.match(/fill="#/g) || []).length, shadings: (txt.match(/Gradient/g) || []).length / 2 | 0 };
    const url = URL.createObjectURL(new Blob([buf], { type: 'image/svg+xml' }));
    const img = new Image(); await new Promise((r, j) => { img.onload = r; img.onerror = j; img.src = url; });
    const w = img.naturalWidth || 1600, h = img.naturalHeight || 1200; sig.w = w; sig.h = h;
    pages.push({ canvas: fitCanvas(img, w, h, max), label: file.name }); URL.revokeObjectURL(url);
  } else if (ext === 'pdf' || ext === 'ai') {
    const pdfjs = await needPdf();
    let doc;
    try { doc = await pdfjs.getDocument({ data: new Uint8Array(buf), isEvalSupported: false }).promise; }
    catch (e) { throw { code: 'pdf', message: ext === 'ai' ? 'File .ai chưa lưu kèm “Create PDF Compatible File” nên không xem trước được.' : 'Không đọc được PDF.' }; }
    sig.pages = doc.numPages; sig.kind = ext === 'ai' ? 'vector' : 'pdf';
    try { const md = await doc.getMetadata(); const inf = md.info || {}; sig.software = sig.software || inf.Creator || inf.Producer || ''; sig.producer = inf.Producer || ''; } catch { }
    const n = Math.min(doc.numPages, opt.pages || (opt.quick ? 1 : 24));
    for (let i = 1; i <= n; i++) {
      const p = await doc.getPage(i); const vp0 = p.getViewport({ scale: 1 });
      const sc = Math.min(4, max / Math.max(vp0.width, vp0.height)); const vp = p.getViewport({ scale: sc });
      const c = document.createElement('canvas'); c.width = Math.round(vp.width); c.height = Math.round(vp.height);
      const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
      await p.render({ canvasContext: x, viewport: vp }).promise;
      if (i === 1) { sig.w = Math.round(vp0.width); sig.h = Math.round(vp0.height); }
      if (i === 1 && (ext === 'ai' || opt.vector)) { try { sig.vec = await vectorStats(p, pdfjs); } catch (e) { console.warn(e); } }
      pages.push({ canvas: c, label: doc.numPages > 1 ? file.name + ' · tr.' + i : file.name });
    }
    if (ext === 'pdf' && !opt.quick && !opt.silent && doc.numPages > n) toast('PDF có ' + doc.numPages + ' trang — hiển thị ' + n + ' trang đầu.');
  } else if (ext === 'psd' || ext === 'psb') {
    await loadScript(LIB.psd);
    let psd;
    try { psd = agPsd.readPsd(buf, { skipLayerImageData: true, skipThumbnail: false, throwForMissingFeatures: false, logMissingFeatures: false }); }
    catch (e) { throw { code: 'psd', message: 'Không đọc được PSD: ' + (e.message || e) }; }
    sig.kind = 'raster'; sig.w = psd.width; sig.h = psd.height;
    sig.psd = psdStats(psd);
    const comp = psd.canvas || psd.imageResources?.thumbnail;
    if (comp) pages.push({ canvas: fitCanvas(comp, comp.width, comp.height, max), label: file.name + (psd.canvas ? '' : ' (ảnh xem trước)') });
    else { const c = document.createElement('canvas'); c.width = 800; c.height = 500; const x = c.getContext('2d'); x.fillStyle = '#eee'; x.fillRect(0, 0, 800, 500); x.fillStyle = '#555'; x.font = '22px sans-serif'; x.fillText('PSD không có ảnh tổng hợp (Maximize Compatibility tắt)', 40, 250); pages.push({ canvas: c, label: file.name }); }
  } else throw { code: 'type', message: 'Định dạng .' + ext + ' chưa hỗ trợ xem trước.' };
  return { pages, signals: sig };
}

async function vectorStats(page, pdfjs) {
  const ops = await page.getOperatorList(); const O = pdfjs.OPS;
  let paths = 0, anchors = 0, max = 0, clips = 0, fills = 0, shadings = 0; const colors = new Set(); const per = [];
  for (let i = 0; i < ops.fnArray.length; i++) {
    const fn = ops.fnArray[i], a = ops.argsArray[i];
    if (fn === O.constructPath) {
      const sub = a[0] || []; let cur = 0;
      for (const op of sub) {
        if (op === O.moveTo) { if (cur) { per.push(cur); } cur = 1; paths++; }
        else if (op === O.lineTo || op === O.curveTo || op === O.curveTo2 || op === O.curveTo3) cur++;
        else if (op === O.rectangle) { paths++; per.push(4); }
      }
      if (cur) per.push(cur);
    } else if (fn === O.clip || fn === O.eoClip) clips++;
    else if (fn === O.fill || fn === O.eoFill || fn === O.fillStroke || fn === O.eoFillStroke) fills++;
    else if (fn === O.shadingFill) shadings++;
    else if (fn === O.setFillRGBColor) colors.add(String(a));
  }
  anchors = sum(per); max = Math.max(0, ...per);
  return { paths, anchors, avg: per.length ? round2(anchors / per.length) : 0, max, clips, fills, shadings, colors: colors.size, dense: per.filter(n => n >= 30).length };
}

function psdStats(psd) {
  const st = { layers: 0, groups: 0, masks: 0, adjust: 0, smart: 0, text: 0, clipped: 0, generic: 0, generative: 0, styles: 0, tree: [] };
  const walk = (arr, depth) => (arr || []).forEach(l => {
    const isG = !!l.children; if (isG) st.groups++; else st.layers++;
    if (l.mask || l.vectorMask) st.masks++;
    if (l.adjustment) st.adjust++;
    if (l.placedLayer) st.smart++;
    if (l.text) st.text++;
    if (l.clipping) st.clipped++;
    if (l.effects) st.styles++;
    if (/^(layer|lớp|layer copy|group)\s*\d*( copy)?\s*\d*$/i.test((l.name || '').trim())) st.generic++;
    if (/generative|tạo sinh|firefly/i.test(l.name || '')) st.generative++;
    if (st.tree.length < 120) st.tree.push('  '.repeat(depth) + (isG ? '▸ ' : '· ') + (l.name || '(không tên)') + [l.mask ? ' [mask]' : '', l.adjustment ? ' [adj:' + l.adjustment.type + ']' : '', l.placedLayer ? ' [smart]' : '', l.text ? ' [chữ]' : '', l.clipping ? ' [clip]' : '', l.hidden ? ' (ẩn)' : ''].join(''));
    if (isG) walk(l.children, depth + 1);
  });
  walk(psd.children, 0);
  st.tree = st.tree.join('\n');
  return st;
}

function autoFlagNotes(sigs) {
  const n = [];
  sigs.filter(Boolean).forEach(s => {
    if (s.psd) {
      if (s.psd.layers <= 1) n.push('File gốc chỉ ' + s.psd.layers + ' layer');
      else if (!s.psd.masks && !s.psd.adjust) n.push('PSD không có Mask/Adjustment Layer');
      if (s.psd.generative) n.push('Có ' + s.psd.generative + ' layer Generative');
    }
    if (s.vec) {
      if (s.vec.avg >= 25) n.push('Trung bình ' + fmt(s.vec.avg, 0) + ' điểm neo/path');
      if (s.vec.dense >= 20) n.push(s.vec.dense + ' path có ≥ 30 điểm neo');
      if (s.vec.clips >= 40) n.push(s.vec.clips + ' vùng Clip lồng nhau');
    }
    if (s.ai?.length) n.push('Dấu AI trong file: ' + s.ai.join(', '));
    else if (s.c2pa) n.push('Có nhãn Content Credentials (C2PA)');
  });
  return [...new Set(n)];
}
function signalLines(s) {
  if (!s) return [];
  const L = [];
  if (s.w) L.push(['Kích thước', s.w + ' × ' + s.h + (s.ext === 'pdf' || s.ext === 'ai' ? ' pt' : ' px') + (s.pages > 1 ? ' · ' + s.pages + ' trang' : '')]);
  L.push(['Phần mềm tạo file', s.software || 'không ghi trong metadata']);
  if (s.history?.length) L.push(['Phần mềm trong lịch sử', s.history.join(', ')]);
  if (s.saves) L.push(['Lịch sử lưu (XMP)', s.saves + ' lần lưu' + (s.first ? ' · từ ' + s.first.slice(0, 16).replace('T', ' ') + ' đến ' + s.last.slice(0, 16).replace('T', ' ') : '')]);
  L.push(['Content Credentials (C2PA)', s.c2pa ? 'Có nhãn' : 'Không thấy']);
  L.push(['Dấu vết công cụ AI', s.ai?.length ? s.ai.join(', ') : 'Không thấy']);
  if (s.psd) L.push(['Cấu trúc PSD', `${s.psd.layers} layer · ${s.psd.groups} group · ${s.psd.masks} mask · ${s.psd.adjust} adjustment · ${s.psd.smart} smart object · ${s.psd.text} chữ · ${s.psd.generic} layer tên mặc định`]);
  if (s.vec) L.push(['Cấu trúc vector', `${s.vec.paths} path · ${s.vec.anchors} điểm neo (TB ${fmt(s.vec.avg, 1)}/path, nhiều nhất ${s.vec.max}) · ${s.vec.clips} clip · ${s.vec.shadings} gradient thật · ${s.vec.fills} lệnh tô` + (s.vec.colors ? ' · ' + s.vec.colors + ' màu bệt' : '')]);
  return L;
}
function signalText(files) {
  return (files || []).map(f => { const L = signalLines(f.signals); return L.length ? `- ${f.name} (${KINDS.find(k => k[0] === f.kind)?.[1] || ''}): ` + L.map(([a, b]) => a + ': ' + b).join('; ') : ''; }).filter(Boolean).join('\n');
}

let assetWarned = false;
async function uploadAsset(rec, file) {
  if (!CAP.assets) return;
  try { const r = await CAP.assets.upload(file); rec.assetId = r.id; rec.url = r.url; }
  catch (e) { if (!assetWarned) { assetWarned = true; toast('Không lưu được file gốc lên kho (' + (e.code || 'lỗi') + ') — điểm vẫn được lưu.', true); } }
}
async function fileFromRec(rec) {
  if (FILE_CACHE[rec.id]) return FILE_CACHE[rec.id];
  const url = rec.url || (rec.assetId ? '/_blob/' + rec.assetId : '');
  if (!url) return null;
  try { const r = await fetch(url); if (!r.ok) return null; const b = await r.blob(); const f = new File([b], rec.name, { type: rec.type || b.type }); FILE_CACHE[rec.id] = f; return f; }
  catch { return null; }
}
async function loadSubPages(sub) {
  const order = { final: 0, source: 1, version: 2, sketch: 3 };
  const out = [];
  for (const rec of [...(sub.files || [])].sort((a, b) => (order[a.kind] ?? 9) - (order[b.kind] ?? 9))) {
    const f = await fileFromRec(rec); if (!f) continue;
    try { const pr = await processFile(f, { max: 1600, pages: 6, silent: true }); rec.signals ||= pr.signals; pr.pages.forEach(p => out.push({ ...p, kind: rec.kind, fileId: rec.id })); } catch (e) { console.warn(e); }
  }
  return out;
}
function canvasBlob(cv, max = 1600, q = .86) { const c = fitCanvas(cv, cv.width, cv.height, max); return new Promise(r => c.toBlob(r, 'image/jpeg', q)); }
