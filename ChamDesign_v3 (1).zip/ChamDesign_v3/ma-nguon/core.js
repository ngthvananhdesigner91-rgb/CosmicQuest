/* ===== Tiện ích ===== */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = (p = '') => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const parseNum = v => { if (v === '' || v == null) return null; const n = parseFloat(String(v).replace(',', '.')); return isNaN(n) ? null : n; };
const fmt = (n, d = 2) => n == null || isNaN(n) ? '–' : Number(n).toLocaleString('vi-VN', { minimumFractionDigits: 1, maximumFractionDigits: d });
const round2 = n => Math.round(n * 100) / 100;
const icon = (id, cls = 'ico') => `<svg class="${cls}"><use href="#i-${id}"/></svg>`;
const fmtDate = t => t ? new Date(t).toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '–';
const fmtTime = t => { if (!t) return ''; const d = new Date(t), now = new Date(); const same = d.toDateString() === now.toDateString(); return same ? d.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) : d.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' }); };
const sum = a => a.reduce((x, y) => x + (y || 0), 0);
const mean = a => a.length ? sum(a) / a.length : null;

function toast(msg, bad) {
  const t = document.createElement('div'); t.className = 'toast' + (bad ? ' bad' : ''); t.textContent = msg;
  $('#toasts').appendChild(t); setTimeout(() => t.remove(), bad ? 4800 : 2600);
}
function modal(html, onMount) {
  const root = $('#modalRoot');
  root.innerHTML = `<div class="modal-bg"><div class="modal" role="dialog" aria-modal="true">${html}</div></div>`;
  const bg = root.firstElementChild;
  const close = () => { root.innerHTML = ''; document.removeEventListener('keydown', onKey); };
  const onKey = e => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', onKey);
  bg.addEventListener('mousedown', e => { if (e.target === bg) close(); });
  $$('[data-close]', bg).forEach(b => b.onclick = close);
  onMount && onMount(bg.firstElementChild, close);
  return close;
}
function confirmBox(text, okLabel, fn, danger) {
  modal(`<h2>Xác nhận</h2><p style="margin:0">${esc(text)}</p><div class="modal-f"><button class="btn" data-close>Huỷ</button><button class="btn ${danger ? 'danger' : 'pri'}" id="cfOk">${esc(okLabel)}</button></div>`,
    (m, close) => { $('#cfOk', m).onclick = () => { close(); fn(); }; });
}
function scoreClass(t) { if (t == null) return ''; return t >= 8 ? 'ok' : t >= 5 ? 'warn' : 'bad'; }
function loadScript(src) {
  return new Promise((res, rej) => {
    if ($(`script[src="${src}"]`)) { const s = $(`script[src="${src}"]`); if (s.dataset.ok) return res(); s.addEventListener('load', () => res()); s.addEventListener('error', rej); return; }
    const s = document.createElement('script'); s.src = src; s.onload = () => { s.dataset.ok = 1; res(); }; s.onerror = () => { s.remove(); rej(new Error('Không tải được thư viện — kiểm tra kết nối mạng rồi thử lại.')); }; document.head.appendChild(s);
  });
}
const LIB = {
  pdf: 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js',
  pdfw: 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js',
  xlsx: 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js',
  psd: 'https://cdn.jsdelivr.net/npm/ag-psd@22.0.2/dist/bundle.js',
  docx: 'https://cdn.jsdelivr.net/npm/docx@8.5.0/build/index.umd.js'
};
async function needPdf() { await loadScript(LIB.pdfw); await loadScript(LIB.pdf); return window.pdfjsLib; }

/* ===== Lưu trữ: db dùng chung → localStorage → bộ nhớ ===== */
const CAP = { db: null, sample: null, assets: null, downloads: null, user: null };
const S = { dbCourses: {}, dbClasses: {}, assignments: {}, subs: {}, history: {}, settings: { ...DEFAULT_SETTINGS }, mode: 'mem', ready: false };
const ME = { id: null, name: '', avatar: '', role: '' };
const LS_KEY = 'banCham.v1';
function lsGet() { try { return JSON.parse(localStorage.getItem(LS_KEY) || 'null'); } catch { return null; } }
function lsSave() {
  if (S.mode !== 'local') return;
  try { localStorage.setItem(LS_KEY, JSON.stringify({ dbCourses: S.dbCourses, dbClasses: S.dbClasses, assignments: S.assignments, subs: S.subs, history: S.history, settings: S.settings })); }
  catch { toast('Bộ nhớ trình duyệt đã đầy — hãy xuất Excel để lưu điểm.', true); }
}
const COLS = { courses: 'dbCourses', classes: 'dbClasses', assignments: 'assignments', subs: 'subs', history: 'history' };
const Store = {
  listeners: [],
  on(fn) { this.listeners.push(fn); },
  emit(col) { this.listeners.forEach(f => { try { f(col); } catch (e) { console.error(e); } }); },
  async put(col, id, data) {
    data = { ...data, updatedAt: Date.now() };
    if (col === 'settings') { S.settings = { ...S.settings, ...data }; data = { ...S.settings }; } else S[COLS[col]][id] = data;
    this.emit(col);
    if (S.mode === 'db') {
      const json = JSON.stringify(data);
      if (json.length > 250000) throw { code: 'too_big', message: 'Bản ghi quá lớn' };
      await CAP.db.doc(col + '/' + id).set(JSON.parse(json));
    } else lsSave();
    return data;
  },
  async del(col, id) {
    delete S[COLS[col]][id]; this.emit(col);
    if (S.mode === 'db') await CAP.db.doc(col + '/' + id).delete(); else lsSave();
  }
};
function courses() {
  const out = DEFAULT_COURSES.map(c => S.dbCourses[c.id] || c);
  Object.values(S.dbCourses).forEach(c => { if (!DEFAULT_COURSES.find(d => d.id === c.id)) out.push(c); });
  return out;
}
const course = id => courses().find(c => c.id === id) || courses()[0];
const lesson = (cid, lid) => { const c = course(cid); return c.lessons.find(l => l.id === lid) || c.lessons[0]; };
function classes() {
  const m = {}; DEFAULT_CLASSES.forEach(c => m[c.id] = c); Object.values(S.dbClasses).forEach(c => m[c.id] = c);
  return Object.values(m).sort((a, b) => a.name.localeCompare(b.name));
}
const klass = id => classes().find(c => c.id === id);
const subsArr = () => Object.values(S.subs).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
function flagsFor(cid) { const c = course(cid); return AI_FLAGS_CORE.concat(AI_FLAGS_EXTRA[c.kind] || []); }
function findAssignment(classId, lessonId) {
  return Object.values(S.assignments).filter(a => a.classId === classId && a.lessonId === lessonId && a.status === 'published').sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0))[0];
}
function subTotal(s) { return s.total ?? (s.criteria ? round2(sum(s.criteria.map(c => c.score ?? c.claude ?? 0))) : null); }
const STATUS = { cho: ['Chưa chấm', ''], nhap: ['Nháp Claude', 'cl'], duyet: ['Đã duyệt', 'ok'] };
const LEVEL = { xanh: ['Xanh', 'ok'], vang: ['Vàng', 'warn'], do: ['Đỏ', 'bad'] };

async function initCaps() {
  const c = window.claude;
  const tryUse = n => c && c.use ? c.use(n).catch(() => null) : Promise.resolve(null);
  const [db, sample, assets, downloads, user] = await Promise.all(['db', 'sample', 'assets', 'downloads', 'user'].map(tryUse));
  Object.assign(CAP, { db, sample, assets, downloads, user });
  if (!c && !CAP.sample && apiKeyGet()) CAP.sample = makeApiSample();
  if (db) {
    S.mode = 'db';
    const sub = (col, key) => db.collection(col).limit(1000).onSnapshot(snap => {
      const m = {}; snap.docs.forEach(d => { if (d.exists) m[d.id] = d.data(); });
      S[key] = m; Store.emit(col);
    }, e => { console.warn(col, e); });
    sub('courses', 'dbCourses'); sub('classes', 'dbClasses'); sub('subs', 'subs');
    db.collection('history').orderBy('at', 'desc').limit(500).onSnapshot(snap => { const m = {}; snap.docs.forEach(d => { if (d.exists) m[d.id] = d.data(); }); S.history = m; Store.emit('history'); }, e => console.warn('history', e));
    db.doc('settings/app').onSnapshot(d => { if (d.exists) { S.settings = { ...DEFAULT_SETTINGS, ...d.data() }; Store.emit('settings'); } });
  } else {
    const saved = lsGet();
    S.mode = 'local';
    try { localStorage.setItem('banCham.probe', '1'); } catch { S.mode = 'mem'; }
    if (saved) { Object.assign(S, { dbCourses: saved.dbCourses || {}, dbClasses: saved.dbClasses || {}, assignments: saved.assignments || {}, subs: saved.subs || {}, history: saved.history || {}, settings: { ...DEFAULT_SETTINGS, ...(saved.settings || {}) } }); }
    Store.emit('all');
  }
  if (user) {
    try { const me = await user.me(); Object.assign(ME, { id: me.id || null, name: me.name || '', avatar: me.avatarUrl || '', role: me.isOwner ? 'Chủ sở hữu' : me.canEdit ? 'Biên tập' : 'Người dùng' }); } catch { }
  }
  S.ready = true; paintSync(); checkLock();
}
/* ===== Lịch sử sửa ===== */
function logHistory(ev) {
  const id = uid('H');
  Store.put('history', id, { id, at: Date.now(), by: ME.id || '', ...ev }).catch(e => console.warn('history', e));
}
const NAME_CACHE = {};
async function resolveNames(ids) {
  ids = [...new Set(ids.filter(x => x && !(x in NAME_CACHE)))];
  if (!ids.length || !CAP.user?.profiles) return;
  try { const ps = await CAP.user.profiles(ids); ids.forEach(id => NAME_CACHE[id] = ps?.[id]?.name || ''); } catch { }
}
const whoName = id => (id && NAME_CACHE[id]) || (id && id === ME.id && ME.name) || S.settings.teacher;
/* ===== Khoá màn hình bằng mã PIN ===== */
async function pinHash(pin) { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('cham.design:' + pin)); return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join(''); }
const ssGet = k => { try { return sessionStorage.getItem(k); } catch { return null; } };
const ssSet = (k, v) => { try { v == null ? sessionStorage.removeItem(k) : sessionStorage.setItem(k, v); } catch { } };
function checkLock() { if (S.settings.pinHash && ssGet('cd.unlocked') !== S.settings.pinHash) showLock(); }
function showLock() {
  const root = $('#lockRoot'); if (root.firstChild) return;
  root.innerHTML = `<div class="lock" role="dialog" aria-modal="true" aria-label="Đăng nhập Chấm.Design"><div class="lock-art">${blockArt('lock')}<span class="logo"><span class="lt">Chấm</span><span class="bd"><i>.</i>Design</span></span></div>
    <form class="lock-form" id="lockF"><div class="eyebrow">Đăng nhập</div><h1>Chào ${esc(ME.name || S.settings.teacher)}</h1>
    <p class="muted" style="margin:0">Nhập mã PIN để mở bàn chấm. Mã PIN do bạn đặt trong mục Đăng nhập &amp; Tài khoản.</p>
    <input class="inp pin" id="lockPin" type="password" inputmode="numeric" autocomplete="current-password" maxlength="8" aria-label="Mã PIN">
    <div id="lockErr" style="color:var(--bad);font-size:.86rem;min-height:1.3em"></div>
    <button class="btn pri" type="submit" style="height:46px;font-size:1rem">${icon('lock')}Mở khoá</button>
    <p class="faint" style="font-size:.78rem;margin:0">Đang dùng tài khoản Claude${ME.name ? ' của ' + esc(ME.name) : ''}. Quên mã PIN? Chủ sở hữu trang có thể xoá mã trong kho dữ liệu của trang.</p></form></div>`;
  setTimeout(() => $('#lockPin')?.focus(), 50);
  $('#lockF').onsubmit = async e => {
    e.preventDefault(); const h = await pinHash($('#lockPin').value.trim());
    if (h === S.settings.pinHash) { ssSet('cd.unlocked', h); root.innerHTML = ''; logHistory({ type: 'login', title: 'Đăng nhập bằng mã PIN' }); toast('Đã mở khoá'); }
    else { $('#lockErr').textContent = 'Mã PIN chưa đúng — thử lại.'; $('#lockPin').select(); }
  };
}
function paintSync() {
  const dot = $('#syncDot'), t = $('#syncTxt');
  dot.className = 'status-dot ' + (S.mode === 'db' ? 'on' : 'off');
  t.textContent = S.mode === 'db' ? 'Đã đồng bộ' : S.mode === 'local' ? 'Lưu cục bộ' : 'Chỉ trong phiên';
  dot.title = S.mode === 'db' ? 'Dữ liệu lưu trong kho dùng chung của trang' : 'Kho dùng chung chưa sẵn sàng — dữ liệu lưu cục bộ';
  $('#sbTeacher').textContent = S.settings.teacher; $('#sbAv').textContent = S.settings.teacher.split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase(); $('#unitName').textContent = S.settings.unit; $('#ftrUnitName').textContent = S.settings.unit; $('#ftrUnit').textContent = '© ' + new Date().getFullYear() + ' ' + S.settings.unit;
}

/* ===== Điều hướng ===== */
const ROUTES = {};
let curRoute = null;
function route() {
  const r = (location.hash || '#dashboard').slice(1).split('.')[0] || 'dashboard';
  const fn = ROUTES[r] ? r : 'dashboard';
  curRoute = fn;
  $$('#nav a').forEach(a => a.classList.toggle('on', a.dataset.r === fn));
  const v = $('#view');
  window.scrollTo(0, 0);
  ROUTES[fn](v);
  paintHdr();
}
function go(r) { if (location.hash === '#' + r) route(); else location.hash = r; }
const HERO = {
  dashboard: ['Xin chào', '<span class="logo"><span class="lt">Chấm</span><span class="bd"><i>.</i>Design</span></span>', 'Studio chấm bài thiết kế đồ họa: Claude chấm theo tiêu chí của bạn, bạn ghi chú lỗi trên bài và chốt điểm.'],
  grade: ['Chấm bài', '', ''],
  queue: ['Làm việc', 'Hàng chờ chấm', 'Nhận bài nộp của cả lớp, cho Claude chấm nháp hàng loạt, rồi mở từng bài để duyệt.'],
  courses: ['Quản lý', 'Môn học &amp; Lớp', 'Mỗi môn có 15 bài, mỗi bài có mục tiêu và tiêu chí chấm riêng. Quản lý danh sách lớp và rubric dùng chung.'],
  transparency: ['Quản lý', 'Minh bạch AI', 'Bằng chứng, tín hiệu kỹ thuật và chỉ số nghi vấn của từng bài. Báo cáo chỉ là gợi ý, không phải kết luận.'],
  stats: ['Quản lý', 'Thống kê &amp; Xuất điểm', 'Phân bố điểm, điểm yếu chung theo tiêu chí, xuất Excel và đồng bộ với phần mềm nhập điểm của trường.'],
  library: ['Hệ thống', 'Thư viện rubric', 'Mục tiêu, tiêu chí và nhận xét nhanh của từng bài. Chỉnh ở đây sẽ áp dụng cho các lần chấm sau.'],
  settings: ['Hệ thống', 'Cài đặt chung', 'Thông tin giảng viên, cách Claude chấm, mẫu tối hậu thư, giao diện và dữ liệu.'],
  history: ['Quản lý', 'Lịch sử sửa', 'Mọi lần lưu điểm, sửa nhận xét, đổi rubric, cài đặt và đồng bộ — ai sửa, sửa lúc nào, đổi từ gì sang gì.'],
  account: ['Hệ thống', 'Đăng nhập &amp; Tài khoản', 'Tài khoản đang dùng, mã PIN khoá màn hình khi rời máy và lịch sử đăng nhập.']
};
function blockArt(kind, score) {
  const pid = 'ht' + kind;
  const halftone = `<defs><pattern id="${pid}" width="10" height="10" patternUnits="userSpaceOnUse"><circle cx="5" cy="5" r="2.2" fill="rgba(255,255,255,.55)"/></pattern></defs>`;
  const pen = (d, pts) => `<path d="${d}" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/>` + pts.map(([x, y, hx, hy]) => `<line x1="${x}" y1="${y}" x2="${hx}" y2="${hy}" stroke="#fff" stroke-width="1.2" opacity=".8"/><circle cx="${hx}" cy="${hy}" r="4" fill="#fff"/><rect x="${x - 5}" y="${y - 5}" width="10" height="10" fill="#1B2350" stroke="#fff" stroke-width="2"/>`).join('');
  if (kind === 'hero') return `<svg viewBox="0 0 520 250" preserveAspectRatio="xMaxYMid slice" aria-hidden="true">${halftone}
    <rect x="300" y="0" width="120" height="250" fill="#E6007E"/>
    <path d="M60 250 A190 190 0 0 1 250 60 L250 250 Z" fill="#00A3E0"/>
    <rect x="300" y="0" width="120" height="250" fill="url(#${pid})" opacity=".35"/>
    <circle cx="452" cy="70" r="46" fill="#FFD400"/>
    <rect x="420" y="160" width="100" height="90" fill="#fff" opacity=".08"/>
    <g transform="translate(218 52) rotate(-6)"><rect width="132" height="160" rx="4" fill="#fff"/><rect x="12" y="14" width="60" height="6" rx="3" fill="#1B2350" opacity=".25"/><rect x="12" y="26" width="40" height="6" rx="3" fill="#1B2350" opacity=".15"/>
      <text x="66" y="112" text-anchor="middle" font-family="Lexend, sans-serif" font-weight="800" font-size="50" fill="#121838" letter-spacing="-3">${esc(score)}</text>
      <path d="M18 92c-2-26 30-40 60-36s44 22 36 40-46 26-74 18c-18-5-24-16-18-28" fill="none" stroke="#E0352B" stroke-width="3.4" stroke-linecap="round"/>
      <g transform="translate(12 140)"><rect width="16" height="8" fill="#00A3E0"/><rect x="18" width="16" height="8" fill="#E6007E"/><rect x="36" width="16" height="8" fill="#FFD400"/><rect x="54" width="16" height="8" fill="#121838"/></g></g>
    ${pen('M120 40 C 200 0, 260 140, 360 110 S 480 200, 510 150', [[120, 40, 170, 8], [360, 110, 300, 128], [510, 150, 490, 190]])}
    <g fill="none" stroke="rgba(255,255,255,.8)" stroke-width="1.4"><circle cx="480" cy="216" r="12"/><path d="M480 198v36M462 216h36"/></g>
  </svg>`;
  if (kind === 'foot') return `<svg viewBox="0 0 360 240" preserveAspectRatio="xMidYMid slice" aria-hidden="true">${halftone}
    <rect width="360" height="240" fill="#1B2350"/>
    <rect x="0" y="150" width="140" height="90" fill="#FFD400"/>
    <path d="M140 240 A120 120 0 0 1 260 120 L260 240 Z" fill="#E6007E"/>
    <rect x="260" y="0" width="100" height="240" fill="#00A3E0"/>
    <rect x="260" y="0" width="100" height="240" fill="url(#${pid})" opacity=".35"/>
    <circle cx="80" cy="70" r="38" fill="none" stroke="#fff" stroke-width="2"/><circle cx="80" cy="70" r="14" fill="#E6007E"/>
    ${pen('M20 130 C 90 90, 150 200, 230 120 S 330 60, 350 100', [[20, 130, 60, 96], [230, 120, 190, 150], [350, 100, 330, 70]])}
  </svg>`;
  return `<svg viewBox="0 0 600 700" preserveAspectRatio="xMidYMid slice" aria-hidden="true">${halftone}
    <rect width="600" height="700" fill="#1B2350"/>
    <rect x="380" y="0" width="220" height="430" fill="#E6007E"/><rect x="380" y="0" width="220" height="430" fill="url(#${pid})" opacity=".3"/>
    <path d="M0 700 A330 330 0 0 1 330 370 L330 700 Z" fill="#00A3E0"/>
    <circle cx="470" cy="560" r="90" fill="#FFD400"/>
    <rect x="330" y="430" width="50" height="270" fill="#fff" opacity=".1"/>
    ${pen('M40 300 C 170 180, 300 420, 420 300 S 560 160, 590 260', [[40, 300, 110, 220], [420, 300, 350, 360], [590, 260, 560, 200]])}
    <g fill="none" stroke="#fff" stroke-width="2"><circle cx="520" cy="80" r="22"/><path d="M520 46v68M486 80h68"/></g>
  </svg>`;
}
function renderHero() {
  const h = $('#hero'), fn = curRoute; if (!h) return;
  let [eb, title, desc] = HERO[fn] || HERO.dashboard, chips = '', actions = '', score = '10';
  const appr = subsArr().filter(s => s.status === 'duyet').map(subTotal).filter(x => x != null);
  if (fn === 'dashboard') {
    eb = 'Xin chào, ' + esc(S.settings.teacher);
    const q = subsArr().filter(s => s.status !== 'duyet').length;
    chips = `<span class="chip">Chờ duyệt <b>${q}</b></span><span class="chip">Đã duyệt <b>${appr.length}</b></span><span class="chip">Điểm TB <b>${fmt(mean(appr))}</b></span>`;
    actions = `<a class="btn" href="#queue">${icon('queue')}Hàng chờ</a><a class="btn pri" href="#grade">${icon('pen')}Vào chấm bài</a>`;
    if (appr.length) score = fmt(mean(appr), 1);
  }
  if (fn === 'grade' && window.G) {
    const c = course(G.courseId), l = lesson(G.courseId, G.lessonId);
    eb = 'Chấm bài · ' + esc(c.soft) + ' · Bài ' + l.no; title = esc(l.name); desc = esc(c.name);
    chips = `<span class="chip">Lớp <b>${esc(klass(G.classId)?.name || G.className || '—')}</b></span><span class="chip">${esc(G.name || G.mssv || 'Chưa chọn sinh viên')}</span>${gHasScores() ? `<span class="chip">Điểm <b>${fmt(gTotal())}</b></span>` : ''}`;
    actions = `<button class="btn" type="button" onclick="$('#btnHelp').click()">${icon('help')}Hướng dẫn</button><button class="btn pri" type="button" onclick="nextG()">${icon('next')}Chấm bài tiếp theo</button>`;
    if (gHasScores()) score = fmt(gTotal(), 1);
  }
  if (fn === 'courses') { const p = location.hash.split('.')[1]; if (p) { const c = course(p); eb = '<a href="#courses" style="color:inherit">← Môn học &amp; Lớp</a>'; title = esc(c.name); desc = 'Phần mềm chính: ' + esc(c.soft) + ' · ' + c.lessons.length + ' bài học'; } }
  if (fn === 'stats' && appr.length) score = fmt(mean(appr), 1);
  h.className = 'hero' + (fn === 'dashboard' ? ' big' : '');
  h.innerHTML = `<span class="crop c1"></span><span class="crop c2"></span><span class="crop c3"></span><span class="crop c4"></span>
    <div class="hero-txt"><div class="hero-eb">${eb}</div><h1>${title}</h1>${desc ? `<p>${desc}</p>` : ''}${chips ? `<div class="hero-chips">${chips}</div>` : ''}</div>
    ${actions ? `<div class="hero-actions">${actions}</div>` : ''}<div class="hero-art">${blockArt('hero', score)}</div>`;
}
function paintHdr() {
  const q = subsArr().filter(s => s.status !== 'duyet').length;
  $('#cntQueue').textContent = q || '';
  renderHero();
}
window.addEventListener('hashchange', route);
Store.on(col => {
  paintHdr(); paintSync();
  if (curRoute && curRoute !== 'grade' && !document.activeElement?.closest?.('.page [data-keep]')) {
    if (!$('#modalRoot').firstChild) ROUTES[curRoute]($('#view'), true);
  }
  if (curRoute === 'grade' && window.onGradeStoreChange) onGradeStoreChange(col);
  if (col === 'settings' || col === 'all') checkLock();
});

/* ===== Tải file về máy ===== */
async function saveFile(filename, data) {
  if (!CAP.downloads) {
    if (window.claude) { toast('Trang này chưa được phép tải file về trong chế độ xem hiện tại.', true); return false; }
    try { const blob = data instanceof Blob ? data : new Blob([data]); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500); toast('Đã tải ' + filename); return true; }
    catch { toast('Trình duyệt không cho tải file.', true); return false; }
  }
  try { await CAP.downloads.save({ filename, data }); toast('Đã tạo file ' + filename); return true; }
  catch (e) { if (e.code !== 'declined') toast('Không tải được file (' + (e.code || 'lỗi') + ').', true); return false; }
}

/* ===== Biểu đồ cột SVG ===== */
function barChart({ labels, values, max, color = 'bx', unit = '', h = 200, fmtV = v => fmt(v) }) {
  const W = 640, pad = { l: 36, r: 8, t: 12, b: 42 }, iw = W - pad.l - pad.r, ih = h - pad.t - pad.b;
  const top = max ?? Math.max(1, ...values.map(v => v || 0));
  const n = values.length, bw = Math.min(46, iw / n - 6);
  let g = '';
  for (let k = 0; k <= 4; k++) { const y = pad.t + ih - ih * k / 4; g += `<line class="gl" x1="${pad.l}" x2="${W - pad.r}" y1="${y}" y2="${y}"/><text x="${pad.l - 6}" y="${y + 4}" text-anchor="end">${fmt(top * k / 4, 1)}</text>`; }
  values.forEach((v, i) => {
    const cx = pad.l + iw * (i + .5) / n, bh = v ? Math.max(2, ih * v / top) : 0, x = cx - bw / 2, y = pad.t + ih - bh;
    if (bh) g += `<path class="${color}" data-tip="${esc(labels[i])}: ${esc(fmtV(v))}${unit}" d="M${x},${pad.t + ih} V${y + 4} q0,-4 4,-4 h${bw - 8} q4,0 4,4 V${pad.t + ih} Z"/>`;
    const lb = String(labels[i]); g += `<text x="${cx}" y="${pad.t + ih + 16}" text-anchor="middle">${esc(lb.length > 12 ? lb.slice(0, 11) + '…' : lb)}</text>`;
  });
  return `<svg class="chart" viewBox="0 0 ${W} ${h}" role="img">${g}</svg>`;
}
document.addEventListener('mousemove', e => {
  if (e.target.closest?.('#vw')) return;
  const t = e.target.closest?.('[data-tip]'), tip = $('#tip');
  if (!t) { tip.hidden = true; return; }
  tip.style.maxWidth = ''; tip.style.whiteSpace = ''; tip.style.fontFamily = '';
  tip.textContent = t.dataset.tip; tip.hidden = false;
  tip.style.left = Math.min(e.clientX + 12, innerWidth - tip.offsetWidth - 8) + 'px'; tip.style.top = (e.clientY - 34) + 'px';
});

/* ===== Bản ngoại tuyến: gọi Claude qua khoá API của giảng viên (chỉ lưu trên trình duyệt này) ===== */
const apiKeyGet = () => { try { return localStorage.getItem('cd.apiKey') || ''; } catch { return ''; } };
const apiModelGet = () => { try { return localStorage.getItem('cd.model') || ''; } catch { return ''; } };
const blobToB64 = b => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = rej; r.readAsDataURL(b); });
const API_HEAD = key => ({ 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' });
async function apiListModels(key) {
  const r = await fetch('https://api.anthropic.com/v1/models?limit=100', { headers: API_HEAD(key) });
  if (!r.ok) throw { code: r.status === 401 ? 'bad_key' : 'upstream_error', message: await r.text() };
  return ((await r.json()).data || []).map(m => ({ id: m.id, name: m.display_name || m.id }));
}
function parseLooseJson(t) {
  try { return JSON.parse(t); } catch { }
  const f = t.match(/```(?:json)?\s*([\s\S]*?)```/); if (f) { try { return JSON.parse(f[1]); } catch { } }
  const a = Math.min(...['{', '['].map(ch => { const i = t.indexOf(ch); return i < 0 ? Infinity : i; })), b = Math.max(t.lastIndexOf('}'), t.lastIndexOf(']'));
  if (a < b) { try { return JSON.parse(t.slice(a, b + 1)); } catch { } }
  throw { code: 'invalid_json', text: t };
}
function makeApiSample() {
  const call = async (input, opt = {}) => {
    const key = apiKeyGet(), model = apiModelGet();
    if (!key || !model) throw { code: 'not_granted', message: 'Chưa có khoá API' };
    const content = [];
    for (const b of [].concat(opt.images ? Array.from(opt.images.length != null && !(opt.images instanceof Blob) ? opt.images : [opt.images]) : [])) content.push({ type: 'image', source: { type: 'base64', media_type: b.type || 'image/jpeg', data: await blobToB64(b) } });
    content.push({ type: 'text', text: (typeof input === 'string' ? input : input.map(m => m.content).join('\n\n')) + (opt.__json ? '\n\nChỉ trả lời bằng JSON hợp lệ, không thêm chữ nào khác.' : '') });
    let r;
    try { r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', signal: opt.signal, headers: API_HEAD(key), body: JSON.stringify({ model, max_tokens: 4096, messages: [{ role: 'user', content }] }) }); }
    catch (e) { throw { code: e.name === 'AbortError' ? 'cancelled' : 'upstream_error', message: 'Không kết nối được tới Claude — kiểm tra mạng.' }; }
    if (!r.ok) { const t = await r.text(); throw { code: r.status === 401 || r.status === 403 ? 'bad_key' : r.status === 429 ? 'rate_limited' : r.status === 400 && /model/i.test(t) ? 'bad_model' : 'upstream_error', message: t }; }
    const j = await r.json(), text = (j.content || []).filter(x => x.type === 'text').map(x => x.text).join('');
    if (opt.onText) try { opt.onText({ text, delta: text }); } catch { }
    return { text, truncated: j.stop_reason === 'max_tokens' };
  };
  const f = (i, o) => call(i, o);
  f.json = async (i, o = {}) => parseLooseJson((await call(i, { ...o, __json: true })).text);
  f.limits = async () => ({ maxPromptBytes: 262144, images: { maxCount: 6, maxInputBytes: 2e7, mediaTypes: ['image/jpeg', 'image/png', 'image/webp', 'image/gif'] } });
  f.viaApi = true;
  return f;
}
